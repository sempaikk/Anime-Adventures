package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestSignedMetadataValidation(t *testing.T) {
	public, private, _ := ed25519.GenerateKey(rand.Reader)
	r, _ := packageFor(sampleFiles("2.0.2"), "2.0.2")
	cases := map[string]func(*Release){
		"invalid app":         func(r *Release) { r.App = "another app" },
		"unknown schema":      func(r *Release) { r.Schema = 2 },
		"empty size":          func(r *Release) { r.Size = 0 },
		"oversize":            func(r *Release) { r.Size = maxArchive + 1 },
		"wrong hash":          func(r *Release) { r.SHA256 = "00" },
		"foreign origin":      func(r *Release) { r.URL = "https://example.test/editor.zip" },
		"wrong release path":  func(r *Release) { r.URL = downloadBase + "other.zip" },
		"invalid version":     func(r *Release) { r.Version = "2.0.beta" },
		"reserved path":       func(r *Release) { r.Files["NUL.js"] = digest(nil) },
		"path case collision": func(r *Release) { r.Files["Content.js"] = digest(nil) },
	}
	for name, change := range cases {
		t.Run(name, func(t *testing.T) {
			raw, _ := json.Marshal(r)
			var bad Release
			json.Unmarshal(raw, &bad)
			change(&bad)
			if _, e := verifyRelease(signed(bad, private), public); e == nil {
				t.Fatal("accepted invalid metadata")
			}
		})
	}
}
func TestArchiveRejectsCaseDuplicatesAndSymlinks(t *testing.T) {
	for _, kind := range []string{"duplicate", "symlink"} {
		t.Run(kind, func(t *testing.T) {
			files := sampleFiles("2.0.2")
			r, _ := packageFor(files, "2.0.2")
			var raw bytes.Buffer
			writer := zip.NewWriter(&raw)
			for _, name := range orderedNames(files) {
				entry, _ := writer.Create("AA-Visual-Editor/" + name)
				entry.Write(files[name])
			}
			if kind == "duplicate" {
				entry, _ := writer.Create("AA-Visual-Editor/CONTENT.js")
				entry.Write([]byte("duplicate"))
			} else {
				header := zip.FileHeader{Name: "AA-Visual-Editor/link.js"}
				header.SetMode(os.ModeSymlink | 0700)
				entry, _ := writer.CreateHeader(&header)
				entry.Write([]byte("../outside"))
			}
			writer.Close()
			r.Size = int64(raw.Len())
			r.SHA256 = digest(raw.Bytes())
			if _, e := unpack(r, raw.Bytes()); e == nil {
				t.Fatal("accepted unsafe archive")
			}
		})
	}
}
func TestSymlinkInTargetNeverRedirectsAnUpdate(t *testing.T) {
	m, _, _, _ := prepare(t)
	outside := t.TempDir()
	sentinel := filepath.Join(outside, "icon16.png")
	os.WriteFile(sentinel, []byte("keep outside"), 0600)
	os.Remove(filepath.Join(m.Target, "icons", "icon16.png"))
	os.Remove(filepath.Join(m.Target, "icons"))
	if e := os.Symlink(outside, filepath.Join(m.Target, "icons")); e != nil {
		t.Skip("symlinks unavailable")
	}
	if _, e := m.Check(context.Background()); e == nil {
		t.Fatal("accepted symlink in destination")
	}
	b, _ := os.ReadFile(sentinel)
	if string(b) != "keep outside" {
		t.Fatal("updated outside the configured folder")
	}
	current, _ := targetManifest(m.Target)
	if current.Version != "2.0.1" {
		t.Fatal("partial update before preflight completed")
	}
}
func TestProductionReleasePackage(t *testing.T) {
	dist := os.Getenv("AAVE_TEST_DISTRIBUTION")
	if dist == "" {
		t.Skip("set AAVE_TEST_DISTRIBUTION for the real release contract")
	}
	envelope, e := os.ReadFile(filepath.Join(dist, "aa-editor-stable.json"))
	if e != nil {
		t.Fatal(e)
	}
	key, _ := hex.DecodeString(releasePublicKeyHex)
	r, e := verifyRelease(envelope, key)
	if e != nil {
		t.Fatal(e)
	}
	archive, e := os.ReadFile(filepath.Join(dist, "AA-Visual-Editor-v"+r.Version+".zip"))
	if e != nil {
		t.Fatal(e)
	}
	files, e := unpack(r, archive)
	if e != nil {
		t.Fatal(e)
	}
	target := filepath.Join(t.TempDir(), "AA-Visual-Editor")
	os.Mkdir(target, 0700)
	for name, b := range files {
		if name == "manifest.json" {
			var m map[string]any
			json.Unmarshal(b, &m)
			m["version"] = "2.0.0"
			b, _ = json.Marshal(m)
		}
		destination, e := safeDestination(target, name, true)
		if e != nil {
			t.Fatal(e)
		}
		if e = writeAtomic(destination, b); e != nil {
			t.Fatal(e)
		}
	}
	manager := newManager(t.TempDir(), target)
	if os.Getenv("AAVE_TEST_PUBLIC") == "1" {
		manager.fetch = networkFetch
	} else {
		manager.fetch = func(_ context.Context, address string, _ int64) ([]byte, error) {
			if address == feedURL {
				return envelope, nil
			}
			return archive, nil
		}
	}
	result, e := manager.Check(context.Background())
	if e != nil || !result.Updated {
		t.Fatalf("%+v %v", result, e)
	}
	assertFiles(t, target, files)
}
