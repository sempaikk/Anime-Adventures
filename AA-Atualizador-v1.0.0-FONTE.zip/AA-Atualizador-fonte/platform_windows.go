//go:build windows

package main

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"syscall"
	"time"
	"unsafe"
)

var kernel = syscall.NewLazyDLL("kernel32.dll")
var createMutex = kernel.NewProc("CreateMutexW")
var createEvent = kernel.NewProc("CreateEventW")
var openEvent = kernel.NewProc("OpenEventW")
var setEvent = kernel.NewProc("SetEvent")
var waitObject = kernel.NewProc("WaitForSingleObject")
var moveFile = kernel.NewProc("MoveFileExW")

func wide(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func replaceFile(from, to string) error {
	r, _, e := moveFile.Call(uintptr(unsafe.Pointer(wide(from))), uintptr(unsafe.Pointer(wide(to))), 0x1|0x8)
	if r == 0 {
		return e
	}
	return nil
}
func lockFile(path string) (func(), error) {
	handle, e := syscall.CreateFile(wide(path), syscall.GENERIC_READ|syscall.GENERIC_WRITE, 0, nil, syscall.OPEN_ALWAYS, syscall.FILE_ATTRIBUTE_NORMAL, 0)
	if e != nil {
		if errors.Is(e, syscall.Errno(32)) || errors.Is(e, syscall.Errno(33)) {
			return nil, errBusy
		}
		return nil, e
	}
	return func() { syscall.CloseHandle(handle) }, nil
}
func appRoot() (string, error) {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" || !filepath.IsAbs(local) {
		return "", errors.New("não foi possível localizar a pasta do usuário do Windows")
	}
	return filepath.Join(local, "AAVisualEditorUpdater"), nil
}
func runHidden(name string, args ...string) error {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	b, e := c.CombinedOutput()
	if e != nil {
		return errors.New("o Windows não concluiu a configuração: " + string(b))
	}
	return nil
}
func setAutostart(executable string, on bool) error {
	reg := filepath.Join(os.Getenv("SystemRoot"), "System32", "reg.exe")
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`
	if on {
		return runHidden(reg, "ADD", key, "/v", "AAVisualEditorUpdater", "/t", "REG_SZ", "/d", `"`+executable+`" --watch`, "/f")
	}
	// Absence is already the desired state. A failed query can also mean that
	// registry access is denied; deletion then returns that error to the user.
	c := exec.Command(reg, "QUERY", key, "/v", "AAVisualEditorUpdater")
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if c.Run() != nil {
		return nil
	}
	return runHidden(reg, "DELETE", key, "/v", "AAVisualEditorUpdater", "/f")
}
func startWatcher(executable string) error {
	c := exec.Command(executable, "--watch")
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if e := c.Start(); e != nil {
		return e
	}
	return c.Process.Release()
}
func watchNames(root string) (string, string) {
	id := digest([]byte(root))[:20]
	return `Local\AAVisualEditorUpdater-` + id, `Local\AAVisualEditorUpdaterStop-` + id
}
func stopWatcher(root string) error {
	mutex, event := watchNames(root)
	handle, _, _ := openEvent.Call(0x0002, falseValue, uintptr(unsafe.Pointer(wide(event))))
	if handle == 0 {
		return nil
	}
	defer syscall.CloseHandle(syscall.Handle(handle))
	setEvent.Call(handle)
	// A mutex is abandoned/released by Windows when the watcher exits.
	proc := kernel.NewProc("OpenMutexW")
	lock, _, _ := proc.Call(0x00100000, 0, uintptr(unsafe.Pointer(wide(mutex))))
	if lock == 0 {
		return nil
	}
	defer syscall.CloseHandle(syscall.Handle(lock))
	result, _, _ := waitObject.Call(lock, 12000)
	if result == 0 || result == 0x80 {
		return nil
	}
	return errors.New("a verificação atual ainda está terminando; aguarde e tente desativar novamente")
}

const falseValue uintptr = 0

func installBinary(root string) (string, error) {
	source, e := os.Executable()
	if e != nil {
		return "", e
	}
	destination := filepath.Join(root, "AA-Atualizador.exe")
	if a, e := os.Stat(destination); e == nil {
		if b, e := os.Stat(source); e == nil && os.SameFile(a, b) {
			return destination, nil
		}
	}
	if e = stopWatcher(root); e != nil {
		return "", e
	}
	b, e := readSmall(source, 32<<20)
	if e != nil {
		return "", e
	}
	if e = writeAtomic(destination, b); e != nil {
		return "", e
	}
	return destination, nil
}
func untilEvent(handle uintptr, timeout time.Duration) bool {
	r, _, _ := waitObject.Call(handle, uintptr(timeout/time.Millisecond))
	return r == 0
}

type comObject struct{ Table *[21]uintptr }

func comResult(value uintptr) error {
	if int32(value) < 0 {
		return errors.New("não foi possível criar o atalho no menu Iniciar")
	}
	return nil
}
func createStartShortcut(executable string) error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	hr, _, _ := ole.NewProc("CoInitializeEx").Call(0, 2)
	if e := comResult(hr); e != nil {
		return e
	}
	defer ole.NewProc("CoUninitialize").Call()
	clsid := syscall.GUID{Data1: 0x00021401, Data4: [8]byte{0xc0, 0, 0, 0, 0, 0, 0, 0x46}}
	shellID := syscall.GUID{Data1: 0x000214f9, Data4: [8]byte{0xc0, 0, 0, 0, 0, 0, 0, 0x46}}
	persistID := syscall.GUID{Data1: 0x0000010b, Data4: [8]byte{0xc0, 0, 0, 0, 0, 0, 0, 0x46}}
	var link *comObject
	hr, _, _ = ole.NewProc("CoCreateInstance").Call(uintptr(unsafe.Pointer(&clsid)), 0, 1, uintptr(unsafe.Pointer(&shellID)), uintptr(unsafe.Pointer(&link)))
	if e := comResult(hr); e != nil {
		return e
	}
	defer syscall.SyscallN(link.Table[2], uintptr(unsafe.Pointer(link)))
	hr, _, _ = syscall.SyscallN(link.Table[20], uintptr(unsafe.Pointer(link)), uintptr(unsafe.Pointer(wide(executable))))
	if e := comResult(hr); e != nil {
		return e
	}
	hr, _, _ = syscall.SyscallN(link.Table[9], uintptr(unsafe.Pointer(link)), uintptr(unsafe.Pointer(wide(filepath.Dir(executable)))))
	if e := comResult(hr); e != nil {
		return e
	}
	var persist *comObject
	hr, _, _ = syscall.SyscallN(link.Table[0], uintptr(unsafe.Pointer(link)), uintptr(unsafe.Pointer(&persistID)), uintptr(unsafe.Pointer(&persist)))
	if e := comResult(hr); e != nil {
		return e
	}
	defer syscall.SyscallN(persist.Table[2], uintptr(unsafe.Pointer(persist)))
	menu := filepath.Join(os.Getenv("APPDATA"), "Microsoft", "Windows", "Start Menu", "Programs")
	if !filepath.IsAbs(menu) {
		return errors.New("a pasta do menu Iniciar não está disponível")
	}
	if e := os.MkdirAll(menu, 0700); e != nil {
		return e
	}
	destination := filepath.Join(menu, "Atualizador AA Visual Editor.lnk")
	if _, e := os.Lstat(destination); e == nil {
		return nil
	}
	hr, _, _ = syscall.SyscallN(persist.Table[6], uintptr(unsafe.Pointer(persist)), uintptr(unsafe.Pointer(wide(destination))), 1)
	return comResult(hr)
}
