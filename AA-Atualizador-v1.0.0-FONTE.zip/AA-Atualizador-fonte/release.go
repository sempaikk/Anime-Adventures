package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"path"
	"strconv"
	"strings"
	"time"
)

const (
	updaterVersion = "1.0.0"
	downloadBase   = "https://raw.githubusercontent.com/sempaikk/Anime-Adventures/refs/heads/aa-visual-editor-downloads/"
	feedURL        = downloadBase + "aa-editor-stable.json"
	maxArchive     = 8 << 20
	maxExpanded    = 32 << 20
	maxFile        = 16 << 20
	maxFiles       = 256
)

type Release struct {
	Schema  int               `json:"schema"`
	App     string            `json:"app"`
	Version string            `json:"version"`
	URL     string            `json:"url"`
	Size    int64             `json:"size"`
	SHA256  string            `json:"sha256"`
	Files   map[string]string `json:"files"`
}
type Envelope struct {
	Payload   string `json:"payload"`
	Signature string `json:"signature"`
}
type Manifest struct {
	ManifestVersion int      `json:"manifest_version"`
	Name            string   `json:"name"`
	Version         string   `json:"version"`
	Key             string   `json:"key"`
	Permissions     []string `json:"permissions"`
	HostPermissions []string `json:"host_permissions"`
	ContentScripts  []struct {
		Matches []string `json:"matches"`
		JS      []string `json:"js"`
	} `json:"content_scripts"`
	Background struct {
		ServiceWorker string `json:"service_worker"`
	} `json:"background"`
}

func strictJSON(data []byte, out any) error {
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if err := d.Decode(out); err != nil {
		return err
	}
	var extra any
	if d.Decode(&extra) != io.EOF {
		return errors.New("JSON contém dados adicionais")
	}
	return nil
}
func version(s string) ([4]int, error) {
	var v [4]int
	parts := strings.Split(s, ".")
	if len(parts) < 1 || len(parts) > 4 {
		return v, errors.New("versão inválida")
	}
	for i, p := range parts {
		n, e := strconv.Atoi(p)
		if e != nil || n < 0 || n > 65535 || strconv.Itoa(n) != p {
			return v, errors.New("versão inválida")
		}
		v[i] = n
	}
	return v, nil
}
func compareVersion(a, b string) (int, error) {
	av, e := version(a)
	if e != nil {
		return 0, e
	}
	bv, e := version(b)
	if e != nil {
		return 0, e
	}
	for i := range av {
		if av[i] < bv[i] {
			return -1, nil
		}
		if av[i] > bv[i] {
			return 1, nil
		}
	}
	return 0, nil
}
func digest(b []byte) string { v := sha256.Sum256(b); return hex.EncodeToString(v[:]) }
func validHash(s string) bool {
	b, e := hex.DecodeString(s)
	return e == nil && len(b) == 32 && s == strings.ToLower(s)
}

// These are archive-relative paths, never arbitrary Windows paths or commands.
func validPath(p string) bool {
	if p == "" || len(p) > 240 || p != path.Clean(p) || strings.ContainsAny(p, "\\:\x00\r\n") || strings.HasPrefix(p, "/") {
		return false
	}
	for _, s := range strings.Split(p, "/") {
		if s == "." || s == ".." || strings.HasSuffix(s, ".") || strings.HasSuffix(s, " ") {
			return false
		}
		for _, r := range s {
			if r < 32 || strings.ContainsRune("<>\"|?*", r) {
				return false
			}
		}
		base := strings.ToUpper(strings.SplitN(s, ".", 2)[0])
		if base == "CON" || base == "PRN" || base == "AUX" || base == "NUL" || base == "CONIN$" || base == "CONOUT$" {
			return false
		}
		if len(base) == 4 && (strings.HasPrefix(base, "COM") || strings.HasPrefix(base, "LPT")) && base[3] >= '0' && base[3] <= '9' {
			return false
		}
	}
	switch strings.ToLower(path.Ext(p)) {
	case ".js", ".json", ".html", ".css", ".md", ".png", ".jpg", ".jpeg", ".webp", ".gif":
		return true
	}
	return false
}
func allowedURL(s string) bool {
	u, e := url.Parse(s)
	return e == nil && u.Scheme == "https" && u.Host == "raw.githubusercontent.com" && u.User == nil && u.RawQuery == "" && u.Fragment == "" && strings.HasPrefix(s, downloadBase)
}
func verifyRelease(data []byte, key ed25519.PublicKey) (Release, error) {
	var r Release
	var env Envelope
	if len(data) > 128<<10 {
		return r, errors.New("resposta de atualização grande demais")
	}
	if strictJSON(data, &env) != nil {
		return r, errors.New("resposta de atualização inválida")
	}
	payload, e := base64.StdEncoding.DecodeString(env.Payload)
	if e != nil {
		return r, errors.New("resposta de atualização incompleta")
	}
	sig, e := base64.StdEncoding.DecodeString(env.Signature)
	if e != nil || len(key) != ed25519.PublicKeySize || !ed25519.Verify(key, payload, sig) {
		return r, errors.New("a assinatura da atualização não confere; nenhum arquivo foi alterado")
	}
	if e = strictJSON(payload, &r); e != nil {
		return r, errors.New("dados da atualização inválidos")
	}
	if r.Schema != 1 || r.App != "aa-visual-editor" || r.Size <= 0 || r.Size > maxArchive || !validHash(r.SHA256) || len(r.Files) < 3 || len(r.Files) > maxFiles {
		return r, errors.New("pacote de atualização inválido")
	}
	if _, e = version(r.Version); e != nil {
		return r, e
	}
	if r.URL != downloadBase+"AA-Visual-Editor-v"+r.Version+".zip" || !allowedURL(r.URL) {
		return r, errors.New("origem da atualização não autorizada")
	}
	seen := map[string]bool{}
	for name, hash := range r.Files {
		if !validPath(name) || !validHash(hash) || seen[strings.ToLower(name)] {
			return r, errors.New("lista de arquivos inválida")
		}
		seen[strings.ToLower(name)] = true
	}
	if _, ok := r.Files["manifest.json"]; !ok {
		return r, errors.New("manifesto ausente")
	}
	return r, nil
}
func validateManifest(data []byte) (Manifest, error) {
	var m Manifest
	if len(data) > 128<<10 || json.Unmarshal(data, &m) != nil {
		return m, errors.New("manifest.json inválido")
	}
	if m.ManifestVersion != 3 || m.Name != "AA Visual Editor" {
		return m, errors.New("escolha a pasta da extensão AA Visual Editor que já está instalada")
	}
	if _, e := version(m.Version); e != nil {
		return m, e
	}
	want := map[string]bool{"storage": true, "activeTab": true, "scripting": true}
	if len(m.Permissions) != 3 || len(m.HostPermissions) != 0 {
		return m, errors.New("a versão altera as permissões da extensão; atualização automática interrompida")
	}
	for _, p := range m.Permissions {
		if !want[p] {
			return m, errors.New("permissão não autorizada")
		}
		delete(want, p)
	}
	if len(want) != 0 {
		return m, errors.New("permissões inconsistentes")
	}
	return m, nil
}
func validatePackageManifest(m Manifest, files map[string][]byte) error {
	allowed := map[string]bool{
		"https://www.roblox.com/games/8304191830*": true, "https://www.roblox.com/*/games/8304191830*": true,
		"https://roblox.com/games/8304191830*": true, "https://roblox.com/*/games/8304191830*": true,
	}
	if len(m.ContentScripts) == 0 {
		return errors.New("scripts da extensão ausentes")
	}
	for _, s := range m.ContentScripts {
		if len(s.Matches) == 0 || len(s.JS) == 0 {
			return errors.New("scripts da extensão inválidos")
		}
		for _, match := range s.Matches {
			if !allowed[match] {
				return errors.New("o pacote amplia os sites acessados; atualização interrompida")
			}
		}
		for _, name := range s.JS {
			if _, ok := files[name]; !ok || !validPath(name) {
				return errors.New("script ausente do pacote")
			}
		}
	}
	if _, ok := files[m.Background.ServiceWorker]; !ok || !validPath(m.Background.ServiceWorker) {
		return errors.New("serviço da extensão ausente do pacote")
	}
	return nil
}
func unpack(r Release, raw []byte) (map[string][]byte, error) {
	if int64(len(raw)) != r.Size || digest(raw) != r.SHA256 {
		return nil, errors.New("download incompleto ou alterado; nenhum arquivo foi substituído")
	}
	z, e := zip.NewReader(bytes.NewReader(raw), int64(len(raw)))
	if e != nil {
		return nil, errors.New("o download não é um ZIP válido")
	}
	if len(z.File) > maxFiles+16 {
		return nil, errors.New("pacote com arquivos demais")
	}
	result := map[string][]byte{}
	seen := map[string]bool{}
	var total int64
	for _, entry := range z.File {
		if entry.FileInfo().IsDir() {
			if entry.Name == "AA-Visual-Editor/" || entry.Name == "AA-Visual-Editor/icons/" {
				continue
			}
			return nil, errors.New("pasta inesperada no pacote")
		}
		if entry.Mode()&ioModeType != 0 || !strings.HasPrefix(entry.Name, "AA-Visual-Editor/") {
			return nil, errors.New("entrada inválida no ZIP")
		}
		name := strings.TrimPrefix(entry.Name, "AA-Visual-Editor/")
		if !validPath(name) || seen[strings.ToLower(name)] {
			return nil, errors.New("caminho inválido ou duplicado no ZIP")
		}
		seen[strings.ToLower(name)] = true
		hash, ok := r.Files[name]
		if !ok {
			return nil, errors.New("arquivo fora da lista assinada")
		}
		if entry.UncompressedSize64 > maxFile || entry.UncompressedSize64 > uint64(maxExpanded-total) {
			return nil, errors.New("pacote descompactado grande demais")
		}
		reader, e := entry.Open()
		if e != nil {
			return nil, e
		}
		b, e := io.ReadAll(io.LimitReader(reader, maxFile+1))
		reader.Close()
		if e != nil || len(b) > maxFile || digest(b) != hash {
			return nil, errors.New("integridade de arquivo inválida")
		}
		total += int64(len(b))
		result[name] = b
	}
	if len(result) != len(r.Files) {
		return nil, errors.New("pacote incompleto")
	}
	m, e := validateManifest(result["manifest.json"])
	if e != nil {
		return nil, e
	}
	if m.Version != r.Version {
		return nil, errors.New("versão do manifesto não corresponde ao pacote")
	}
	if e = validatePackageManifest(m, result); e != nil {
		return nil, e
	}
	return result, nil
}
func networkFetch(ctx context.Context, address string, limit int64) ([]byte, error) {
	if !allowedURL(address) {
		return nil, errors.New("origem não autorizada")
	}
	client := &http.Client{Timeout: 30 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) > 3 || !allowedURL(req.URL.String()) {
			return errors.New("redirecionamento não autorizado")
		}
		return nil
	}}
	req, e := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if e != nil {
		return nil, e
	}
	req.Header.Set("User-Agent", "AA-Visual-Editor-Updater/"+updaterVersion)
	req.Header.Set("Cache-Control", "no-cache")
	response, e := client.Do(req)
	if e != nil {
		return nil, fmt.Errorf("não foi possível consultar as atualizações: %w", e)
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return nil, fmt.Errorf("servidor de atualização respondeu HTTP %d; arquivos atuais preservados", response.StatusCode)
	}
	if response.ContentLength > limit {
		return nil, errors.New("download grande demais")
	}
	b, e := io.ReadAll(io.LimitReader(response.Body, limit+1))
	if e != nil {
		return nil, e
	}
	if int64(len(b)) > limit {
		return nil, errors.New("download grande demais")
	}
	return b, nil
}
