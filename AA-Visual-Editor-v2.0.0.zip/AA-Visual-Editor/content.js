/* Local page controller. Shared writes are serialized by the extension worker. */
(() => {
  "use strict";
  if (globalThis.__aaVisualEditor) return;
  const clone = (x) => structuredClone(x),
    same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  class Controller {
    constructor() {
      Object.assign(this, {
        profile: AAVEC.fresh(),
        book: AAVEStore.blank(),
        profileId: "default",
        assets: new Map(),
        editing: false,
        panelOpen: false,
        uiHidden: false,
        selected: null,
        previewOriginal: false,
        undoStack: [],
        redoStack: [],
        saving: false,
        saveError: false,
        scoped: false,
        lastResult: null,
        scheduled: false,
        disposed: false,
        pendingOps: [],
        waiters: [],
        inflight: [],
        drafts: new Map(),
        multi: [],
        captureActive: false,
        refreshing: false,
      });
      this.engine = new AAVEEngine.Engine();
      this.ui = new AAVEUI(this);
      this.extras = new AAVEExtras(this);
      this.pointer = (e) => {
        if (
          this.editing &&
          !this.ui.contains(e) &&
          this.scoped &&
          AAVEC.inScope(location.href)
        )
          this.ui.highlight(AAVEEngine.selectAt(e));
      };
      this.click = (e) => {
        if (
          !this.editing ||
          this.ui.contains(e) ||
          !this.scoped ||
          !AAVEC.inScope(location.href)
        )
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
        const target = AAVEEngine.selectAt(e);
        if (target) {
          if (e.shiftKey) {
            try {
              this.addSelection(target);
              this.ui.toast(
                `${this.multi.length} elementos na seleção múltipla.`,
              );
            } catch (error) {
              this.ui.toast(error.message, true);
            }
          }
          this.select(target);
        }
      };
      this.blockPointer = (e) => {
        if (
          this.editing &&
          !this.ui.contains(e) &&
          this.scoped &&
          AAVEC.inScope(location.href) &&
          e.button === 0
        ) {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
      };
      this.keyboard = (e) => this.key(e);
      this.changed = () => {
        if (this.checkScope() && this.selected)
          this.ui.highlight(this.selected);
        this.extras.clamp();
      };
      this.storageChanged = (changes, area) => {
        if (area === "local" && changes[AAVEStore.KEY])
          this.safe(() => this.refresh());
      };
    }
    safe(fn) {
      return Promise.resolve()
        .then(fn)
        .catch((e) =>
          this.ui.toast(e.message || "Não foi possível concluir a ação.", true),
        );
    }
    async init() {
      try {
        this.book = await AAVEStore.request("load");
        const view = await AAVEStore.request("tabView");
        if (view?.original) this.previewOriginal = true;
        this.profileId =
          view?.profileId ||
          sessionStorage.getItem("aave-active-profile") ||
          this.book.defaultProfile;
        const record =
          this.book.profiles.find((p) => p.id === this.profileId) ||
          this.book.profiles[0];
        this.profileId = record.id;
        this.profile = clone(record.profile);
        await this.loadAssets();
      } catch (e) {
        this.saveError = true;
        this.ui.toast(e.message, true);
      }
      this.observer = new MutationObserver((records) => {
        const external = records.filter(
          (r) =>
            !(
              r.target.nodeType === 1 ? r.target : r.target.parentElement
            )?.closest?.("[data-aave-root]"),
        );
        if (external.length) {
          this.engine.external(external);
          this.schedule();
        }
      });
      this.engine.observer = this.observer;
      this.observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        characterDataOldValue: true,
        attributes: true,
        attributeOldValue: true,
        attributeFilter: [
          "src",
          "srcset",
          "sizes",
          "style",
          "class",
          "id",
          "alt",
          "hidden",
          "data-testid",
          "aria-label",
        ],
      });
      for (const [name, fn] of [
        ["pointermove", this.pointer],
        ["click", this.click],
        ["pointerdown", this.blockPointer],
        ["mousedown", this.blockPointer],
        ["keydown", this.keyboard],
      ])
        document.addEventListener(name, fn, true);
      for (const event of ["popstate", "hashchange", "resize", "scroll"])
        window.addEventListener(event, this.changed, { passive: true });
      chrome.storage.onChanged.addListener(this.storageChanged);
      this.onMessage = (m, sender, respond) => {
        if (sender.id !== chrome.runtime.id || m?.app !== "aa-visual-editor")
          return;
        this.safeMessage(m).then(
          (value) => respond({ ok: true, ...value }),
          (e) => respond({ ok: false, error: e.message }),
        );
        return true;
      };
      chrome.runtime.onMessage.addListener(this.onMessage);
      this.interval = setInterval(() => {
        try {
          if (!chrome.runtime.id || !chrome.runtime.getManifest())
            return this.dispose();
        } catch {
          return this.dispose();
        }
        this.checkScope();
        if (Date.now() - (this.lastLease || 0) > 300000) {
          this.lastLease = Date.now();
          this.leaseAssets();
        }
      }, 700);
      this.checkScope();
      this.ui.render();
      this.extras.render();
    }
    async safeMessage(m) {
      if (!this.checkScope())
        throw Error("Abra a página do Anime Adventures primeiro.");
      if (m.action === "open") this.open(false);
      else if (m.action === "pick") this.togglePick();
      else if (m.action === "hideUI") this.hideUI();
      else if (["enabled", "hideBetterBlox"].includes(m.action))
        await this.flag(m.action, !!m.value);
      else if (m.action === "capture") await this.capture(!!m.full);
      else if (m.action !== "state") throw Error("Ação desconhecida.");
      return this.state();
    }
    async loadAssets() {
      const ids = [
        ...new Set(
          this.profile.patches
            .filter(
              (p) => p.kind === "image" && p.value.startsWith("aave-asset:"),
            )
            .map((p) => p.value),
        ),
      ];
      if (!ids.length) return;
      const missing = ids.filter((id) => !this.assets.has(id));
      if (!missing.length) return;
      for (const a of await AAVEStore.request("assets", { ids: missing }))
        if (a.data) this.assets.set(a.id, a.data);
    }
    async refresh() {
      if (this.disposed || this.refreshing) return;
      this.refreshing = true;
      try {
        const b = await AAVEStore.request("load");
        if (b.revision < this.book.revision) return;
        const record = b.profiles.find((p) => p.id === this.profileId);
        this.book = b;
        if (!record) {
          this.ui.toast(
            "O perfil desta aba foi removido. Exporte as alterações antes de trocar de perfil.",
            true,
          );
          return;
        }
        let profile = record.profile;
        const ops = [...this.inflight, ...this.pendingOps];
        if (ops.length) profile = AAVEStore.apply(profile, ops).profile;
        if (!same(this.profile, profile)) this.engine.rebase(profile);
        this.profile = clone(profile);
        await this.loadAssets();
        this.apply();
        this.ui.render();
        this.extras.render();
      } finally {
        this.refreshing = false;
      }
    }
    isCustomized() {
      return this.profile.enabled && !this.previewOriginal;
    }
    state() {
      return {
        enabled: this.isCustomized(),
        count: this.profile.patches.length,
        hideBetterBlox: this.profile.hideBetterBlox,
        editing: this.editing,
        hidden: this.uiHidden,
        profile: this.profileId,
        saved: !this.saveError && !this.saving,
      };
    }
    checkScope() {
      const active = AAVEC.inScope(location.href);
      if (active !== this.scoped) {
        this.scoped = active;
        if (active) {
          this.ui.mount();
          this.engine.invalidate();
          this.apply();
          this.ui.render();
          this.extras.render();
        } else {
          this.engine.removeBindings();
          this.ui.unmount();
          this.editing = false;
          this.selected = null;
          this.multi = [];
        }
      } else if (active && !this.ui.host.isConnected) this.ui.mount();
      return active;
    }
    schedule() {
      if (this.disposed || this.scheduled) return;
      this.scheduled = true;
      queueMicrotask(() => {
        this.scheduled = false;
        if (this.checkScope() && !this.disposed) {
          this.apply(false);
          clearTimeout(this.discoveryTimer);
          this.discoveryTimer = setTimeout(() => {
            if (!this.disposed) this.apply(true);
          }, 150);
        }
      });
    }
    apply(discover = true) {
      if (!this.scoped || this.disposed) return;
      const records = this.observer?.takeRecords();
      if (records?.length) this.engine.external(records);
      this.lastResult = this.engine.apply(
        { ...this.profile, enabled: this.isCustomized() },
        this.assets,
        discover,
      );
      this.ui.status(this.lastResult);
      if (this.selected?.el.isConnected) this.ui.highlight(this.selected);
    }
    open(pick = false) {
      if (!this.checkScope()) return;
      this.extras.focusBefore =
        this.ui.root.activeElement || document.activeElement;
      this.uiHidden = false;
      this.captureActive = false;
      this.panelOpen = true;
      this.ui.render();
      this.extras.render();
      this.ui.$(".panel").focus({ preventScroll: true });
      if (pick) this.togglePick(true);
    }
    togglePick(force) {
      if (!this.checkScope()) return;
      const on = force ?? (!this.editing || this.panelOpen);
      this.uiHidden = false;
      this.editing = on;
      this.panelOpen = !on;
      this.ui.render();
      if (on && !this.isCustomized())
        this.safe(() => this.flag("enabled", true));
      if (on) {
        this.pickIndex = 0;
        this.ui.toast(
          "Clique ou use Tab/Shift+Tab e Enter. Shift+clique adiciona à seleção.",
        );
      }
    }
    closePanel() {
      this.panelOpen = false;
      this.editing = false;
      this.ui.render();
      this.extras.restoreFocus();
    }
    hideUI() {
      this.extras.saveDraft();
      this.uiHidden = true;
      this.panelOpen = false;
      this.editing = false;
      this.ui.render();
      this.ui.$(".toast").hidden = true;
      this.flush().catch(() => {});
    }
    select(target) {
      this.extras.saveDraft();
      this.selected = target;
      this.panelOpen = true;
      this.uiHidden = false;
      this.ui.selection(target);
      this.extras.selection(target);
      this.ui.render();
      this.extras.render();
      this.ui.highlight(target);
    }
    navigate(direction) {
      let el = this.selected?.el;
      if (!el) return;
      el =
        direction === "parent"
          ? el.parentElement
          : direction === "child"
            ? el.firstElementChild
            : direction === "prev"
              ? el.previousElementSibling
              : el.nextElementSibling;
      if (!AAVEEngine.editable(el))
        throw Error("Nenhum elemento selecionável nessa direção.");
      this.select({
        el,
        node: AAVEEngine.textNodes(el)[0] || null,
        image:
          el instanceof HTMLImageElement
            ? "src"
            : getComputedStyle(el).backgroundImage !== "none"
              ? "background"
              : "",
      });
    }
    addSelection(target) {
      this.multi = this.multi.filter((t) => t.el.isConnected);
      if (this.multi.some((t) => t.el === target.el)) return;
      if (this.multi.length >= 50)
        throw Error(
          "O limite da seleção é de 50 elementos. Aplique ou limpe antes de adicionar mais.",
        );
      this.multi.push(target);
    }
    parent() {
      return this.navigate("parent");
    }
    trimHistory() {
      while (
        this.undoStack.length + this.redoStack.length > 80 ||
        AAVEC.bytes([this.undoStack, this.redoStack]) > 4 * 1024 * 1024
      ) {
        if (this.undoStack.length) this.undoStack.shift();
        else this.redoStack.shift();
      }
    }
    leaseAssets() {
      clearTimeout(this.leaseTimer);
      this.leaseTimer = setTimeout(() => {
        const ids = [
          ...new Set(
            JSON.stringify([this.undoStack, this.redoStack]).match(
              /aave-asset:[a-f0-9]{64}/g,
            ) || [],
          ),
        ];
        AAVEStore.request("assetLease", { ids, client: "page" }).catch(
          () => {},
        );
      }, 50);
    }
    async commit(raw, history = true, conditional = false) {
      const next = AAVEC.validate(raw),
        ops = AAVEStore.diff(this.profile, next).map((op) =>
          conditional ? { ...op, conditional: true } : op,
        );
      if (!ops.length) {
        if (this.saveError) return this.flush();
        return;
      }
      for (const p of next.patches) {
        const old = this.profile.patches.find((q) => q.id === p.id);
        if (
          this.selected?.el.isConnected &&
          (!old || !same(old.target, p.target)) &&
          AAVEEngine.path(this.selected.el) === p.target.selector
        ) {
          const binding = this.engine.bind(p.id, this.selected.el);
          binding.target = p.target;
          binding.node = this.selected.node;
        }
      }
      if (history) {
        this.undoStack.push(ops);
        this.redoStack = [];
        this.trimHistory();
        this.leaseAssets();
      }
      this.engine.rebase(next);
      this.profile = next;
      this.pendingOps.push(...ops);
      if (this.pendingOps.length > 1200)
        this.pendingOps = this.compact(this.pendingOps);
      this.saving = true;
      this.apply();
      this.ui.render();
      this.extras.render();
      clearTimeout(this.saveTimer);
      this.saveTimer = setTimeout(() => this.flush().catch(() => {}), 120);
      return new Promise((resolve, reject) =>
        this.waiters.push({ resolve, reject }),
      );
    }
    compact(ops) {
      const out = [];
      for (const op of ops) {
        const key =
          op.type === "flag"
            ? "flag:" + op.key
            : op.type === "field"
              ? "field:" + op.id + ":" + op.key + ":" + op.prop
              : null;
        const at = key ? out.findIndex((o) => o._key === key) : -1;
        if (at >= 0) out[at] = { ...op, before: out[at].before, _key: key };
        else out.push({ ...op, _key: key });
      }
      return out;
    }
    async flush() {
      clearTimeout(this.saveTimer);
      if (this.flushPromise)
        return this.flushPromise.then(() =>
          this.pendingOps.length ? this.flush() : undefined,
        );
      if (!this.pendingOps.length) {
        this.saving = false;
        return;
      }
      const ops = this.compact(this.pendingOps.splice(0)),
        waiters = this.waiters.splice(0);
      this.inflight = ops;
      this.saving = true;
      const request = {
        profileId: this.profileId,
        ops,
        opId: crypto.randomUUID(),
      };
      this.flushPromise = (async () => {
        try {
          const b = await AAVEStore.request("mutate", request);
          if (b.revision >= this.book.revision) this.book = b;
          this.inflight = [];
          const p = this.book.profiles.find((p) => p.id === this.profileId);
          if (p)
            this.profile = AAVEStore.apply(p.profile, this.pendingOps).profile;
          await this.loadAssets();
          this.saveError = false;
          for (const w of waiters) w.resolve();
        } catch (error) {
          this.pendingOps.unshift(...ops);
          this.inflight = [];
          this.saveError = true;
          for (const w of waiters)
            w.reject(
              Error("A alteração aparece, mas não foi salva. " + error.message),
            );
          this.ui.toast(
            "A alteração não foi salva. Use Tentar salvar ou exporte um backup. " +
              error.message,
            true,
          );
          throw error;
        } finally {
          this.saving = false;
          this.flushPromise = null;
          this.apply();
          this.ui.render();
          this.extras.render();
        }
      })();
      return this.flushPromise;
    }
    async flag(name, value) {
      if (name === "enabled") {
        this.previewOriginal = !value;
        if (value && !this.profile.enabled)
          await this.commit({ ...this.profile, enabled: true });
        if (!value) this.editing = false;
        this.engine.clear();
        this.apply();
        this.ui.render();
        return;
      }
      if (["hideLauncher", "hideBetterBlox"].includes(name)) {
        const pending = this.commit({ ...this.profile, [name]: !!value });
        const flushed = this.flush();
        await Promise.all([pending, flushed]);
      }
    }
    target() {
      if (!this.selected?.el.isConnected)
        throw Error("Selecione novamente o elemento da página.");
      return AAVEEngine.describe(
        this.selected.el,
        this.selected.node,
        this.selected.image,
      );
    }
    async patch(kind, value, target = null) {
      const d = target || this.target(),
        list = this.profile.patches.slice(),
        at = list.findIndex(
          (p) =>
            p.kind === kind &&
            p.target.selector === d.selector &&
            (kind !== "text" || p.target.index === d.index),
        );
      const old = at >= 0 ? list[at] : null,
        p = {
          ...old,
          id: old?.id || crypto.randomUUID(),
          kind,
          target: old?.target || d,
          label:
            old?.label ||
            (
              {
                text: "Texto",
                image: "Imagem",
                style: "Aparência",
                hide: "Oculto",
              }[kind] +
              " · " +
              (d.sample || d.tag)
            ).slice(0, 120),
          value,
        };
      if (at < 0) list.push(p);
      else list[at] = p;
      this.previewOriginal = false;
      await this.commit({ ...this.profile, enabled: true, patches: list });
      this.ui.toast("Salvo neste navegador.");
    }
    async bulk(kind, value, targets) {
      const patches = clone(this.profile.patches),
        bindings = [];
      for (const t of targets.slice(0, 50)) {
        if (!t.el.isConnected) continue;
        const target = AAVEEngine.describe(t.el, t.node, t.image),
          at = patches.findIndex(
            (p) => p.kind === kind && p.target.selector === target.selector,
          ),
          old = at >= 0 ? patches[at] : null;
        const patch = {
          ...old,
          id: old?.id || crypto.randomUUID(),
          kind,
          target: old?.target || target,
          label:
            old?.label ||
            (
              (kind === "style" ? "Aparência" : "Oculto") +
              " · " +
              (target.sample || target.tag)
            ).slice(0, 120),
          value: clone(value),
        };
        if (at < 0) patches.push(patch);
        else patches[at] = patch;
        bindings.push({ patch, t });
      }
      if (!bindings.length)
        throw Error("Selecione novamente os elementos da página.");
      const next = AAVEC.validate({ ...this.profile, enabled: true, patches });
      for (const { patch, t } of bindings) {
        const binding = this.engine.bind(patch.id, t.el);
        binding.target = patch.target;
        binding.node = t.node;
      }
      this.previewOriginal = false;
      await this.commit(next);
      this.ui.toast("Seleção aplicada e salva em uma operação.");
    }
    async text(value) {
      if (!this.selected?.node) throw Error("Selecione um texto ou número.");
      const target = this.target(),
        style =
          this.profile.patches.find(
            (p) => p.kind === "style" && p.target.selector === target.selector,
          )?.value || {};
      await this.patch("text", value, target);
      if (value.includes("\n"))
        await this.patch(
          "style",
          { ...style, "white-space": "pre-wrap" },
          target,
        );
    }
    async image(value, target = null) {
      const d = target || this.target(),
        profileId = this.profileId;
      if (!d.attr) throw Error("Selecione uma imagem ou fundo.");
      let url = AAVEC.imageURL(value),
        data = this.assets.get(url) || url;
      if (!url.startsWith("aave-asset:")) {
        await AAVEImages.decode(data);
        if (url.startsWith("data:")) {
          url = await AAVEStore.request("assetPut", {
            data: url,
            name: this.extras.imageName || "Imagem local",
          });
          this.assets.set(url, data);
        }
      }
      if (this.profileId !== profileId)
        throw Error(
          "O perfil mudou durante a leitura. Escolha a imagem novamente neste perfil.",
        );
      await this.patch("image", url, d);
      if (this.selected) this.ui.selection(this.selected);
    }
    async imageFile(file) {
      const target = this.target(),
        profileId = this.profileId,
        token = (this.extras.previewRequest =
          (this.extras.previewRequest || 0) + 1);
      const image = await AAVEImages.file(file);
      if (token !== this.extras.previewRequest) return;
      if (profileId !== this.profileId)
        throw Error(
          "O perfil mudou durante a leitura. Escolha o arquivo novamente.",
        );
      this.extras.imageName = image.name;
      this.extras.setImageDraft(image.data, target);
      this.ui.toast(
        `Prévia de ${image.name}: ${image.width} × ${image.height}. Confirme para aplicar.`,
      );
    }
    async remove(id) {
      await this.commit({
        ...this.profile,
        patches: this.profile.patches.filter((p) => p.id !== id),
      });
    }
    async clearStyle() {
      const d = this.target();
      await this.commit({
        ...this.profile,
        patches: this.profile.patches.filter(
          (p) => !(p.kind === "style" && p.target.selector === d.selector),
        ),
      });
      this.ui.selection(this.selected);
      this.extras.selection(this.selected);
    }
    locate(id) {
      const p = this.profile.patches.find((p) => p.id === id),
        el =
          p &&
          (this.engine.bindings.get(id)?.el.isConnected
            ? this.engine.bindings.get(id).el
            : this.engine.resolve(p.target));
      if (!el) {
        this.extras.repairId = id;
        this.togglePick(true);
        this.ui.toast(
          "Destino pendente. Selecione o elemento correto e use Reparar destino.",
        );
        return;
      }
      const n = el.childNodes[p.target.index];
      this.select({
        el,
        node: n?.nodeType === Node.TEXT_NODE ? n : null,
        image: p.target.attr,
      });
      el.scrollIntoView({
        block: "center",
        behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "instant"
          : "smooth",
      });
    }
    async undo() {
      await this.flush();
      const ops = this.undoStack.pop();
      if (!ops) return;
      const inverse = AAVEStore.inverse(ops),
        result = AAVEStore.apply(this.profile, inverse, true);
      this.redoStack.push(ops);
      this.trimHistory();
      await this.commit(result.profile, false, true);
      if (result.conflicts)
        this.ui.toast(
          "Parte do desfazer foi preservada porque outra aba alterou o mesmo campo.",
          true,
        );
      this.selected = null;
      this.ui.selection(null);
    }
    async redo() {
      await this.flush();
      const ops = this.redoStack.pop();
      if (!ops) return;
      const result = AAVEStore.apply(this.profile, ops, true);
      this.undoStack.push(ops);
      await this.commit(result.profile, false, true);
      if (result.conflicts)
        this.ui.toast("Parte do refazer conflitou com outra aba.", true);
    }
    async reset() {
      await this.commit({
        ...AAVEC.fresh(),
        hideLauncher: this.profile.hideLauncher,
      });
      this.previewOriginal = false;
      this.selected = null;
      this.editing = false;
      this.ui.selection(null);
      this.ui.render();
      this.ui.toast("Página restaurada e salva. Você pode desfazer.");
    }
    async portable(profile) {
      const p = clone(profile);
      const missing = p.patches
        .filter(
          (x) =>
            x.kind === "image" &&
            x.value.startsWith("aave-asset:") &&
            !this.assets.has(x.value),
        )
        .map((p) => p.value);
      if (missing.length)
        for (const a of await AAVEStore.request("assets", { ids: missing }))
          if (a.data) this.assets.set(a.id, a.data);
      for (const patch of p.patches)
        if (patch.kind === "image" && patch.value.startsWith("aave-asset:")) {
          const data = this.assets.get(patch.value);
          if (!data)
            throw Error(
              "Uma imagem local não foi encontrada. O perfil não foi exportado incompleto.",
            );
          patch.value = data;
        }
      return p;
    }
    download(value, name, type = "application/json") {
      const url = URL.createObjectURL(
          new Blob(
            [
              typeof value === "string"
                ? value
                : JSON.stringify(value, null, 2),
            ],
            { type },
          ),
        ),
        a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.hidden = true;
      this.ui.root.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }
    async exportSet(all = false) {
      const b = clone(this.book);
      b.profiles = all
        ? clone(this.book.profiles)
        : [
            {
              id: this.profileId,
              name:
                this.book.profiles.find((p) => p.id === this.profileId)?.name ||
                "Meu perfil",
              profile: clone(this.profile),
            },
          ];
      b.defaultProfile = b.profiles[0].id;
      b.backups = [];
      b.recent = [];
      b.assets = {};
      b.exportKind = all ? "set" : "profile";
      const ids = [
        ...new Set(
          b.profiles.flatMap((p) =>
            p.profile.patches
              .filter(
                (x) => x.kind === "image" && x.value.startsWith("aave-asset:"),
              )
              .map((x) => x.value),
          ),
        ),
      ];
      for (const row of await AAVEStore.request("assets", { ids })) {
        if (ids.includes(row.id)) {
          if (!row.data) throw Error("Uma imagem local está indisponível.");
          b.assets[row.id] = { data: row.data, name: row.name };
        }
      }
      if (ids.some((id) => !b.assets[id]))
        throw Error("Uma imagem local está indisponível.");
      if (AAVEC.bytes(b) > 96 * 1024 * 1024)
        throw Error(
          "Este conjunto é grande demais. Exporte os perfis separadamente.",
        );
      this.download(
        b,
        all ? "anime-adventures-perfis.json" : "anime-adventures-perfil.json",
      );
    }
    async export() {
      await this.loadAssets();
      let estimated = AAVEC.bytes(this.profile);
      for (const p of this.profile.patches)
        if (p.kind === "image" && p.value.startsWith("aave-asset:")) {
          const data = this.assets.get(p.value);
          if (!data) throw Error("Uma imagem local está indisponível.");
          estimated += data.length - p.value.length;
          if (estimated > AAVEC.MAX_BYTES) {
            await this.exportSet(false);
            return;
          }
        }
      const portable = await this.portable(this.profile);
      this.download(portable, "anime-adventures-personalizacao.json");
      this.ui.toast(
        "Backup exportado. Imagens por link continuam referências ao servidor original.",
      );
    }
    async importFile(file) {
      this.extras.importBytes = file.size;
      if (file.size > 96 * 1024 * 1024)
        throw Error("O backup ultrapassa 96 MB.");
      let parsed;
      try {
        parsed = JSON.parse(await file.text());
      } catch {
        throw Error("O arquivo não é um backup JSON válido.");
      }
      if (parsed.schema === 2) {
        const b = AAVEStore.book(parsed);
        if (
          parsed.assets &&
          (typeof parsed.assets !== "object" ||
            Array.isArray(parsed.assets) ||
            Object.keys(parsed.assets).length > 500)
        )
          throw Error("Biblioteca de imagens inválida.");
        this.extras.importDraft =
          parsed.exportKind === "profile"
            ? { profile: b.profiles[0].profile, assets: parsed.assets || {} }
            : { book: b, assets: parsed.assets || {} };
        this.extras.showImport(
          b.profiles.reduce((n, p) => n + p.profile.patches.length, 0),
          b.profiles.length,
        );
      } else {
        const p = AAVEC.validate(parsed);
        for (const patch of p.patches)
          if (patch.kind === "image" && patch.value.startsWith("data:"))
            await AAVEImages.decode(patch.value);
        this.extras.importDraft = { profile: p };
        this.extras.showImport(p.patches.length, 1);
      }
    }
    async importApply(merge) {
      const draft = this.extras.importDraft;
      if (!draft) throw Error("Escolha um backup primeiro.");
      for (const [id, a] of Object.entries(draft.assets || {})) {
        await AAVEImages.decode(a.data);
        const actual = await AAVEStore.request("assetPut", {
          data: a.data,
          name: a.name,
        });
        if (actual !== id)
          throw Error("Uma imagem do backup não corresponde ao seu hash.");
        this.assets.set(id, a.data);
      }
      if (draft.book) {
        for (const p of draft.book.profiles)
          p.profile = await this.externalize(p.profile);
        this.book = await AAVEStore.request("importBook", {
          book: draft.book,
          merge,
          opId: crypto.randomUUID(),
        });
        await this.refresh();
      } else {
        let p = await this.externalize(draft.profile);
        if (merge)
          p = AAVEStore.apply(
            this.profile,
            AAVEStore.diff(AAVEC.fresh(), p),
          ).profile;
        await this.commit(p);
      }
      if (!this.book.profiles.some((p) => p.id === this.profileId))
        await this.switchProfile(this.book.defaultProfile);
      this.extras.importDraft = null;
      this.extras.showImport(0, 0);
      this.ui.toast("Backup importado e salvo.");
    }
    async externalize(profile) {
      const p = clone(profile);
      for (const patch of p.patches)
        if (patch.kind === "image" && patch.value.startsWith("data:")) {
          const data = patch.value;
          await AAVEImages.decode(data);
          patch.value = await AAVEStore.request("assetPut", {
            data,
            name: "Importada",
          });
          this.assets.set(patch.value, data);
        }
      return p;
    }
    async switchProfile(id) {
      await this.flush();
      const p = this.book.profiles.find((p) => p.id === id);
      if (!p) throw Error("Perfil não encontrado.");
      this.extras.saveDraft();
      this.engine.clear();
      this.profileId = id;
      sessionStorage.setItem("aave-active-profile", id);
      this.profile = clone(p.profile);
      this.undoStack = [];
      this.redoStack = [];
      this.selected = null;
      this.multi = [];
      this.previewOriginal = false;
      await this.loadAssets();
      this.ui.selection(null);
      this.apply();
      this.ui.render();
      this.extras.render();
    }
    async profileAction(command, name) {
      await this.flush();
      const id = ["create", "duplicate"].includes(command)
        ? crypto.randomUUID()
        : this.profileId;
      this.book = await AAVEStore.request("profile", {
        command,
        id,
        name,
        source: command === "duplicate" ? this.profileId : null,
        opId: crypto.randomUUID(),
      });
      await this.switchProfile(
        this.book.profiles.some((p) => p.id === id)
          ? id
          : this.book.defaultProfile,
      );
    }
    key(e) {
      if (!this.checkScope()) return;
      const input = e
        .composedPath()
        .some(
          (el) =>
            el instanceof Element &&
            (el.matches("input,textarea,select") || el.isContentEditable),
        );
      if (input && !this.ui.contains(e)) return;
      const keys = this.book.settings.shortcuts;
      if (e.altKey && e.shiftKey) {
        let action = Object.entries(keys).find(
          ([, key]) => key === e.code,
        )?.[0];
        if (action) {
          e.preventDefault();
          e.stopImmediatePropagation();
          if (action === "pick") this.togglePick();
          else if (action === "hide")
            this.uiHidden || (!this.panelOpen && this.profile.hideLauncher)
              ? this.open()
              : this.hideUI();
          else this.safe(() => this.flag("enabled", !this.isCustomized()));
          return;
        }
      }
      if (e.code === "KeyK" && (e.ctrlKey || e.metaKey) && e.shiftKey) {
        e.preventDefault();
        this.open();
        this.extras.palette();
        return;
      }
      if (e.key === "Escape") {
        if (this.captureActive) return;
        if (!input) {
          e.preventDefault();
          this.closePanel();
        }
        return;
      }
      if (!input && this.editing && (e.key === "Tab" || e.key === "Enter")) {
        e.preventDefault();
        const items = [
          ...document.querySelectorAll(
            "h1,h2,h3,p,span,strong,dt,dd,img,button,a",
          ),
        ]
          .filter(
            (el) =>
              AAVEEngine.editable(el) &&
              el.getBoundingClientRect().width &&
              el.getBoundingClientRect().height,
          )
          .slice(0, 1500);
        if (!items.length) return;
        this.pickIndex =
          ((this.pickIndex || 0) + (e.shiftKey ? -1 : 1) + items.length) %
          items.length;
        const el = items[this.pickIndex];
        const target = {
          el,
          node: AAVEEngine.textNodes(el)[0] || null,
          image: el instanceof HTMLImageElement ? "src" : "",
        };
        this.ui.highlight(target);
        el.scrollIntoView({ block: "nearest" });
        if (e.key === "Enter") {
          this.select(target);
          this.editing = false;
          this.ui.render();
          this.ui.$("#text").focus();
        }
        return;
      }
      if (
        !input &&
        (this.editing || this.panelOpen) &&
        (e.ctrlKey || e.metaKey) &&
        e.code === "KeyZ"
      ) {
        e.preventDefault();
        this.safe(() => (e.shiftKey ? this.redo() : this.undo()));
      }
    }
    async capture(full = false) {
      return this.extras.capture(full);
    }
    dispose() {
      if (this.disposed) return;
      this.disposed = true;
      clearInterval(this.interval);
      clearTimeout(this.saveTimer);
      clearTimeout(this.leaseTimer);
      clearTimeout(this.discoveryTimer);
      this.observer?.disconnect();
      this.engine.removeBindings();
      this.ui.unmount();
      this.extras.dispose();
      for (const [name, fn] of [
        ["pointermove", this.pointer],
        ["click", this.click],
        ["pointerdown", this.blockPointer],
        ["mousedown", this.blockPointer],
        ["keydown", this.keyboard],
      ])
        document.removeEventListener(name, fn, true);
      for (const event of ["popstate", "hashchange", "resize", "scroll"])
        window.removeEventListener(event, this.changed);
      try {
        chrome.storage.onChanged.removeListener(this.storageChanged);
        chrome.runtime.onMessage.removeListener(this.onMessage);
      } catch {}
      delete globalThis.__aaVisualEditor;
    }
  }
  const c = new Controller();
  globalThis.__aaVisualEditor = c;
  c.ready = c.init().then(
    () => true,
    (e) => {
      console.warn("AA Visual Editor:", e?.name);
      c.dispose();
      return false;
    },
  );
})();
