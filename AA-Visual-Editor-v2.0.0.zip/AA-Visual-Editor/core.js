/* Local-only profile format. No Roblox API, cookies, remote code or analytics. */
(() => {
  "use strict";
  if (globalThis.AAVEC) return;
  const PLACE = "8304191830",
    KEY = "aa-visual-editor.profile.v1";
  const MAX_BYTES = 8 * 1024 * 1024,
    MAX_PATCHES = 200;
  const plain = (x) => !!x && typeof x === "object" && !Array.isArray(x);
  const bytes = (x) => new TextEncoder().encode(JSON.stringify(x)).length;
  function inScope(href) {
    try {
      const u = new URL(href);
      return (
        u.protocol === "https:" &&
        ["www.roblox.com", "roblox.com"].includes(u.hostname) &&
        new RegExp(
          `^(?:/[a-z]{2}(?:-[a-z]{2})?)?/games/${PLACE}(?:/|$)`,
          "i",
        ).test(u.pathname)
      );
    } catch {
      return false;
    }
  }
  const fresh = () => ({
    schema: 1,
    app: "aa-visual-editor",
    placeId: PLACE,
    enabled: true,
    hideLauncher: false,
    hideBetterBlox: false,
    patches: [],
  });
  function imageURL(input) {
    if (typeof input !== "string" || input.length > 6 * 1024 * 1024)
      throw Error("A imagem é muito grande.");
    if (/^aave-asset:[a-f0-9]{64}$/.test(input)) return input;
    if (/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/i.test(input))
      return input;
    try {
      const url = new URL(input);
      if (
        url.protocol === "https:" &&
        !url.username &&
        !url.password &&
        input.length <= 4096
      )
        return url.href;
    } catch {}
    throw Error(
      "Use um link HTTPS direto de imagem ou escolha um arquivo PNG, JPG, WebP ou GIF.",
    );
  }
  function styles(value) {
    if (!plain(value)) throw Error("Estilo inválido.");
    const out = {},
      checks = {
        color: /^#[\da-f]{6}$/i,
        "background-color": /^#[\da-f]{6}$/i,
        "font-weight": /^(100|200|300|400|500|600|700|800|900)$/,
        "text-align": /^(left|center|right|start|end)$/,
        "object-fit": /^(cover|contain|fill|none|scale-down)$/,
        "white-space": /^(normal|pre-wrap|pre-line)$/,
        "font-family":
          /^(Arial|Verdana|Georgia|Tahoma|Trebuchet MS|Courier New|system-ui|sans-serif|serif|monospace)$/,
        "border-style": /^(none|solid|dashed|dotted|double)$/,
        "border-color": /^#[\da-f]{6}$/i,
        "background-size": /^(cover|contain|auto)$/,
        "box-shadow":
          /^(none|-?\d{1,3}px -?\d{1,3}px \d{1,3}px \d{1,3}px #[\da-f]{6})$/i,
      };
    for (const [k, v] of Object.entries(value)) {
      if (typeof v !== "string") throw Error("Estilo inválido.");
      if (checks[k]?.test(v)) out[k] = v;
      else if (
        [
          "font-size",
          "border-radius",
          "width",
          "height",
          "line-height",
          "letter-spacing",
          "margin-top",
          "margin-bottom",
          "margin-left",
          "margin-right",
          "padding-top",
          "padding-bottom",
          "padding-left",
          "padding-right",
          "border-width",
        ].includes(k) &&
        /^\d+(?:\.\d+)?(px|%|em|rem|vw|vh)$/.test(v)
      ) {
        const n = parseFloat(v);
        const cap = v.endsWith("px")
          ? {
              "font-size": 300,
              "border-width": 100,
              "letter-spacing": 100,
              "border-radius": 500,
              "line-height": 1000,
            }[k] || 5000
          : 100;
        if (n < 0 || n > cap) throw Error("Dimensão fora do limite.");
        out[k] = v;
      } else if (k === "opacity" && /^(0(?:\.\d+)?|1(?:\.0+)?)$/.test(v))
        out[k] = v;
      else if (
        ["object-position", "background-position"].includes(k) &&
        /^(?:100|\d{1,2})(?:\.\d+)?% (?:100|\d{1,2})(?:\.\d+)?%$/.test(v) &&
        v.split(" ").every((x) => parseFloat(x) <= 100)
      )
        out[k] = v;
      else if (
        k === "aspect-ratio" &&
        /^\d{1,4} \/ \d{1,4}$/.test(v) &&
        v.split(" / ").every((x) => +x > 0)
      )
        out[k] = v;
      else throw Error("Esse estilo não é permitido no perfil.");
    }
    return out;
  }
  function validate(raw) {
    if (
      !plain(raw) ||
      raw.schema !== 1 ||
      raw.app !== "aa-visual-editor" ||
      raw.placeId !== PLACE
    )
      throw Error(
        "Escolha um perfil exportado pelo AA Visual Editor para o Anime Adventures.",
      );
    const allowed = [
      "schema",
      "app",
      "placeId",
      "enabled",
      "hideLauncher",
      "hideBetterBlox",
      "patches",
    ];
    if (Object.keys(raw).some((k) => !allowed.includes(k)))
      throw Error("O perfil contém campos desconhecidos.");
    if (!Array.isArray(raw.patches) || raw.patches.length > MAX_PATCHES)
      throw Error(`O limite é de ${MAX_PATCHES} alterações.`);
    const out = fresh(),
      ids = new Set();
    for (const flag of ["enabled", "hideLauncher", "hideBetterBlox"]) {
      if (typeof raw[flag] !== "boolean")
        throw Error("Preferência inválida no perfil.");
      out[flag] = raw[flag];
    }
    for (const p of raw.patches) {
      if (
        !plain(p) ||
        typeof p.id !== "string" ||
        !/^[a-z\d-]{8,64}$/i.test(p.id) ||
        ids.has(p.id) ||
        !["text", "image", "style", "hide"].includes(p.kind) ||
        !plain(p.target)
      )
        throw Error("Alteração inválida no perfil.");
      ids.add(p.id);
      const d = p.target;
      if (
        typeof d.selector !== "string" ||
        !d.selector ||
        d.selector.length > 2048 ||
        typeof d.tag !== "string" ||
        !/^[a-z][a-z\d-]{0,40}$/.test(d.tag) ||
        [
          "html",
          "head",
          "body",
          "script",
          "style",
          "iframe",
          "input",
          "textarea",
          "select",
          "option",
          "meta",
          "link",
        ].includes(d.tag) ||
        typeof d.sample !== "string" ||
        d.sample.length > 300 ||
        typeof d.anchor !== "string" ||
        d.anchor.length > 160 ||
        !Number.isInteger(d.index) ||
        d.index < -1 ||
        d.index > 500 ||
        typeof d.attr !== "string" ||
        !["", "src", "background"].includes(d.attr)
      )
        throw Error("Destino inválido no perfil.");
      const target = {
        selector: d.selector,
        tag: d.tag,
        sample: d.sample,
        anchor: d.anchor,
        index: d.index,
        attr: d.attr,
      };
      for (const key of ["stable", "context", "textBefore", "textAfter"]) {
        if (d[key] !== undefined) {
          if (typeof d[key] !== "string" || d[key].length > 2048)
            throw Error("Contexto de destino inválido.");
          target[key] = d[key];
        }
      }
      if (typeof p.label !== "string" || p.label.length > 120)
        throw Error("Nome de alteração inválido.");
      let value;
      if (p.kind === "text") {
        if (
          typeof p.value !== "string" ||
          p.value.length > 20000 ||
          d.index < 0
        )
          throw Error("Texto inválido ou muito longo.");
        value = p.value;
      } else if (p.kind === "image") {
        if (!d.attr || (d.attr === "src" && d.tag !== "img"))
          throw Error("Destino de imagem inválido.");
        value = imageURL(p.value);
      } else if (p.kind === "style") value = styles(p.value);
      else value = true;
      const patch = { id: p.id, kind: p.kind, target, label: p.label, value };
      if (p.enabled !== undefined) {
        if (typeof p.enabled !== "boolean") throw Error("Estado inválido.");
        patch.enabled = p.enabled;
      }
      if (p.group !== undefined) {
        if (typeof p.group !== "string" || p.group.length > 80)
          throw Error("Grupo inválido.");
        patch.group = p.group;
      }
      out.patches.push(patch);
    }
    if (bytes(out) > MAX_BYTES)
      throw Error(
        "O perfil ultrapassa 8 MB. Use imagens menores ou remova alguma imagem.",
      );
    return out;
  }
  globalThis.AAVEC = Object.freeze({
    PLACE,
    KEY,
    MAX_BYTES,
    MAX_PATCHES,
    bytes,
    fresh,
    inScope,
    imageURL,
    styles,
    validate,
  });
})();
