/* A shadow-root editor so Roblox/BetterBLOX styles cannot restyle these controls. */
(() => {
  "use strict";
  if (globalThis.AAVEUI) return;
  const CSS_TEXT = `
    :host{all:initial;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#eaf1ff;color-scheme:dark}
    *{box-sizing:border-box} [hidden]{display:none!important} .panel,.launcher,.toast,.highlight{font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#eaf1ff;line-height:1.4} button,input,textarea,select{font:inherit}
    button{cursor:pointer;border:1px solid #33415a;background:#1b293e;color:#edf4ff;border-radius:9px;padding:9px 11px;transition:background .12s}
    button:hover{background:#293c58} button:disabled{opacity:.4;cursor:default} button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:2px solid #7eafff;outline-offset:2px}
    .primary{background:#4384ef;border-color:#5794ff;color:white;font-weight:700}.primary:hover{background:#5894f5}
    .quiet{background:transparent}.danger{color:#ffb3b3}.small{font-size:11px;padding:5px 7px}
    .launcher{position:fixed;right:22px;bottom:20px;display:flex;align-items:center;gap:7px;padding:6px;border:1px solid #4c6f9c;border-radius:15px;background:#111d30;box-shadow:0 8px 32px #0008}
    .launcher button{border:0;background:transparent;padding:8px 10px}.launcher strong{color:#8fbcff;letter-spacing:.5px}.dot{width:7px;height:7px;border-radius:50%;background:#7990ad;display:inline-block;margin-right:6px}.dot.on{background:#72e0b0;box-shadow:0 0 10px #72e0b055}
    .panel{position:fixed;right:20px;top:76px;width:360px;max-height:calc(100vh - 108px);overflow:auto;background:#101b2c;border:1px solid #425c80;border-radius:17px;box-shadow:0 18px 60px #0009;scrollbar-width:thin;scrollbar-color:#3a5374 transparent}
    .head{padding:18px 17px 15px;border-bottom:1px solid #293c57;background:linear-gradient(130deg,#1d3356,#111d30)}
    .row{display:flex;align-items:center;gap:8px}.between{justify-content:space-between}.grow{flex:1}.brand{font-size:15px;font-weight:800;letter-spacing:1px}.tag{font-size:10px;color:#9eb9df;text-transform:uppercase;letter-spacing:1.3px;margin-top:6px}.close{padding:5px 9px;font-size:18px;line-height:20px}
    .section{padding:15px 17px;border-bottom:1px solid #26374e}.section:last-child{border:0}.muted{color:#a8bad3;line-height:1.5;font-size:12px;margin:7px 0}.mini{font-size:11px;color:#a8bad3;line-height:1.5}.title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#92baff;margin:0 0 10px}
    .seg{display:grid;grid-template-columns:1fr 1fr;gap:5px;padding:4px;background:#0b1422;border-radius:12px;margin:10px 0}.seg button{background:transparent;border:0;font-size:12px}.seg .active{background:#254671;color:#dceaff}
    .tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}.tools button{font-size:12px}.status{color:#8de0bd;font-size:11px;line-height:1.5;margin:8px 0 0}
    .switch{display:flex;gap:10px;align-items:center;line-height:1.4;margin:10px 0;cursor:pointer}.switch input{width:16px;height:16px;accent-color:#5896ff;flex:none}.switch span{flex:1}
    label.field{display:block;font-size:11px;font-weight:700;color:#bed0e9;margin:10px 0 5px}textarea,input[type=text],input[type=number],select{width:100%;color:#f0f5ff;background:#091322;border:1px solid #3d5476;border-radius:9px;padding:9px;min-width:0}textarea{resize:vertical;min-height:86px;line-height:1.5}input[type=color]{width:100%;height:34px;border:1px solid #3d5476;border-radius:7px;background:#142238;padding:3px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.selection{font-size:12px;line-height:1.5;overflow-wrap:anywhere;margin:8px 0;color:#d4e4fb}.empty{border:1px dashed #3e587a;border-radius:11px;padding:13px;color:#b4c8e3;line-height:1.6}
    .file{display:block;text-align:center;cursor:pointer;border:1px dashed #6389ba;border-radius:10px;padding:11px;color:#c2dcff;margin-top:10px}.preview{width:100%;max-height:138px;object-fit:contain;background:#08111f;border-radius:8px;margin-top:10px;border:1px solid #334866}
    details>summary{cursor:pointer;list-style:none;font-size:12px;color:#bfd7f9;display:flex;justify-content:space-between;gap:10px}details>summary::after{content:'+';color:#83b3ff}details[open]>summary::after{content:'−'}
    .edits{list-style:none;padding:0;margin:10px 0 0;max-height:200px;overflow:auto}.edit{display:flex;gap:5px;align-items:center;border-top:1px solid #293d58;padding:7px 0}.edit:first-child{border:0}.edit .entry{flex:1;text-align:left;border:0;background:transparent;padding:3px;overflow:hidden;min-width:0}.edit b{display:block;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.edit small{display:block;color:#a9bedb;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;margin-top:3px}.edit .erase{padding:5px 8px;color:#ffbaba}.foot{padding:12px 17px;color:#8fa9cd;font-size:10px;line-height:1.5}
    .highlight{position:fixed;pointer-events:none;border:2px solid #7aafff;background:#74a9ff15;border-radius:4px;box-shadow:0 0 0 1px #112b4f;z-index:0}.highlight-label{position:absolute;left:-2px;top:-22px;white-space:nowrap;background:#3477db;color:white;font-size:10px;line-height:18px;padding:1px 6px;border-radius:5px 5px 0 0;max-width:200px;overflow:hidden;text-overflow:ellipsis}
    .panel,.launcher{z-index:2}.toast{position:fixed;bottom:82px;right:22px;max-width:370px;background:#193049;color:#eaf5ff;padding:12px 15px;border:1px solid #5c8cbe;border-radius:12px;box-shadow:0 10px 35px #0008;line-height:1.5;z-index:4}.toast.error{background:#40232b;border-color:#bc687a}
    @media(max-width:600px){.panel{right:8px;top:56px;width:min(360px,calc(100vw - 16px));max-height:calc(100vh - 70px)}.launcher{right:12px;bottom:12px}}
  `;
  class UI {
    constructor(c) {
      this.c = c;
      this.host = document.createElement("div");
      this.host.dataset.aaveRoot = "1";
      this.host.style.cssText =
        "all:initial!important;position:fixed!important;inset:0!important;width:0!important;height:0!important;z-index:2147483647!important;pointer-events:none!important";
      this.root = this.host.attachShadow({ mode: "open" });
      this.root.innerHTML = `<style>${CSS_TEXT}.panel,.launcher,.toast{pointer-events:auto}</style>
        <div class="highlight" hidden><span class="highlight-label"></span></div>
        <div class="launcher"><button data-action="open" title="Abrir editor — Alt+Shift+E"><strong>AA</strong> Editor</button><button data-action="pick" title="Ligar ou desligar seleção"><i class="dot"></i><span id="launchMode">Editar</span></button></div>
        <section class="panel" role="dialog" tabindex="-1" aria-modal="false" aria-label="AA Visual Editor" hidden>
          <header class="head"><div class="row between"><div class="brand">AA VISUAL EDITOR</div><button class="quiet close" data-action="close" title="Fechar painel">×</button></div><div class="tag">Anime Adventures · só neste navegador</div></header>
          <div class="section"><div class="seg"><button data-action="custom" id="custom">Personalizada</button><button data-action="original" id="original">Página real</button></div><button class="primary" data-action="pick" id="pick" style="width:100%">Ativar seleção por clique</button><p class="muted" id="tip">Ative a seleção e clique em um texto, número ou imagem da página.</p><div class="tools"><button data-action="undo" id="undo">↶ Desfazer</button><button data-action="redo" id="redo">↷ Refazer</button><button class="quiet" data-action="hideUI">Ocultar editor</button></div><p class="status" id="status">Carregando perfil…</p></div>
          <div class="section" id="selectionSection"><p class="title">Elemento selecionado</p><div class="empty" id="empty">Nome, jogadores ativos, visitas, descrição, banner… Escolha o que quer personalizar.</div><div id="selected" hidden><div class="selection" id="selectionLabel"></div><div class="tools"><button class="small" data-action="parent">Selecionar bloco acima</button><button class="small danger" data-action="hideElement">Ocultar elemento</button></div><div id="textEditor" hidden><label class="field" for="text">Seu texto ou número</label><textarea id="text" maxlength="20000" spellcheck="false"></textarea><p class="mini">Ctrl+Enter aplica. A alteração fica travada mesmo se o Roblox atualizar esse campo. As quebras de linha ficam visíveis ao aplicar texto multilinha.</p><button class="primary" data-action="text" style="width:100%">Aplicar texto</button></div><div id="imageEditor" hidden><img class="preview" id="preview" alt="Prévia da imagem selecionada" referrerpolicy="no-referrer"><label class="field" for="imageURL">Link direto da nova imagem</label><input id="imageURL" maxlength="4096" type="text" placeholder="https://…/imagem.png"><button class="primary" data-action="image" style="width:100%;margin-top:8px">Carregar prévia do link</button><label class="file">Escolher imagem do computador<input type="file" id="imageFile" accept="image/png,image/jpeg,image/webp,image/gif" hidden></label><p class="mini">Até 4 MB por imagem; biblioteca separada de até 64 MB. Confira a prévia e use Confirmar imagem.</p></div><details style="margin-top:14px"><summary>Cores, tamanho e aparência</summary><div class="grid"><div><label class="field" for="color">Cor do texto</label><input id="color" type="text" placeholder="#ffffff" maxlength="7"></div><div><label class="field" for="background">Cor de fundo</label><input id="background" type="text" placeholder="#101010" maxlength="7"></div><div><label class="field" for="fontSize">Fonte (px)</label><input id="fontSize" type="number" min="1" max="300" placeholder="Original"></div><div><label class="field" for="radius">Cantos (px)</label><input id="radius" type="number" min="0" max="200" placeholder="Original"></div><div><label class="field" for="width">Largura (px ou %)</label><input id="width" type="text" placeholder="Ex.: 100%"></div><div><label class="field" for="height">Altura (px ou %)</label><input id="height" type="text" placeholder="Ex.: 400px"></div><div><label class="field" for="weight">Peso do texto</label><select id="weight"><option value="">Original</option><option value="400">Normal</option><option value="600">Semibold</option><option value="700">Negrito</option><option value="900">Extra bold</option></select></div><div><label class="field" for="align">Alinhamento</label><select id="align"><option value="">Original</option><option value="left">Esquerda</option><option value="center">Centro</option><option value="right">Direita</option></select></div><div><label class="field" for="opacity">Opacidade (0–1)</label><input id="opacity" type="number" min="0" max="1" step="0.05" placeholder="Original"></div><div><label class="field" for="fit">Encaixe da imagem</label><select id="fit"><option value="">Original</option><option value="cover">Preencher</option><option value="contain">Mostrar inteira</option><option value="fill">Esticar</option></select></div></div><button data-action="style" style="width:100%;margin-top:12px">Aplicar aparência</button><button class="quiet small" data-action="clearStyle" style="margin-top:7px">Restaurar aparência deste elemento</button></details></div></div>
          <div class="section"><p class="title">Página limpa</p><label class="switch"><input id="hideBetterBlox" type="checkbox"><span>Ocultar rodapé do BetterBLOX<small class="mini" style="display:block">Marca, versão e feedback no canto inferior esquerdo.</small></span></label><label class="switch"><input id="hideLauncher" type="checkbox"><span>Esconder botão flutuante<small class="mini" style="display:block">Abra de novo por Alt+Shift+E ou pelo ícone da extensão.</small></span></label><button data-action="hideUI" style="width:100%">Modo captura: esconder toda a interface</button></div>
          <div class="section"><details id="changesDetails"><summary id="changesTitle">Alterações salvas</summary><ul class="edits" id="edits"></ul><p class="mini" id="noEdits">Nenhuma alteração ainda.</p></details></div>
          <div class="section"><p class="title">Seu perfil</p><div class="tools"><button data-action="export">Exportar backup</button><button data-action="import">Importar backup</button><button class="quiet danger" data-action="reset">Restaurar tudo</button></div><input type="file" id="importFile" accept="application/json,.json" hidden></div>
          <footer class="foot">Alt+Shift+E: editar · Alt+Shift+H: esconder/mostrar interface · Alt+Shift+O: real/personalizada.<br>Suas alterações ficam no Chrome deste computador.</footer>
        </section><div class="toast" role="status" hidden></div>`;
      this.$ = (selector) => this.root.querySelector(selector);
      this.root.addEventListener("click", (event) => {
        const button = event.target.closest("[data-action]");
        if (!button) return;
        event.preventDefault();
        Promise.resolve(
          this.action(button.dataset.action, button.dataset.id),
        ).catch((error) => this.toast(error.message, true));
      });
      this.$("#hideBetterBlox").addEventListener("change", (e) =>
        c
          .flag("hideBetterBlox", e.target.checked)
          .catch((error) => this.toast(error.message, true)),
      );
      this.$("#hideLauncher").addEventListener("change", (e) =>
        c
          .flag("hideLauncher", e.target.checked)
          .catch((error) => this.toast(error.message, true)),
      );
      this.$("#imageFile").addEventListener("change", async (e) => {
        const input = e.target;
        try {
          if (input.files[0]) await c.imageFile(input.files[0]);
        } catch (error) {
          this.toast(error.message, true);
        }
        input.value = "";
      });
      this.$("#importFile").addEventListener("change", async (e) => {
        const input = e.target;
        try {
          if (input.files[0]) await c.importFile(input.files[0]);
        } catch (error) {
          this.toast(error.message, true);
        }
        input.value = "";
      });
      this.$("#text").addEventListener("keydown", (e) => {
        if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          c.safe(() => c.text(this.$("#text").value));
        }
      });
      this.toastTimer = null;
      for (const label of this.root.querySelectorAll("label.file")) {
        label.tabIndex = 0;
        label.setAttribute("role", "button");
        label.addEventListener("keydown", (e) => {
          if (["Enter", " "].includes(e.key)) {
            e.preventDefault();
            label.querySelector("input").click();
          }
        });
      }
    }
    mount() {
      if (!this.host.isConnected) document.documentElement.append(this.host);
    }
    unmount() {
      this.host.remove();
    }
    contains(event) {
      return event.composedPath().includes(this.host);
    }
    panel(show) {
      this.$(".panel").hidden = !show;
      if (!show) this.highlight(null);
    }
    highlight(target) {
      const box = this.$(".highlight");
      if (!target?.el?.isConnected || !this.c.editing || this.c.uiHidden) {
        box.hidden = true;
        return;
      }
      const r = target.el.getBoundingClientRect();
      box.hidden = !r.width || !r.height;
      Object.assign(box.style, {
        left: r.left + "px",
        top: r.top + "px",
        width: r.width + "px",
        height: r.height + "px",
      });
      this.$(".highlight-label").textContent =
        (target.image ? "Imagem" : target.node ? "Texto" : "Bloco") +
        " · " +
        target.el.localName;
    }
    render() {
      const c = this.c,
        p = c.profile;
      this.$(".panel").hidden = !c.panelOpen || c.uiHidden;
      this.$(".launcher").hidden = c.uiHidden || p.hideLauncher;
      this.$("#launchMode").textContent = c.editing ? "Selecionando" : "Editar";
      this.$(".dot").classList.toggle("on", c.editing);
      this.$("#custom").classList.toggle("active", c.isCustomized());
      this.$("#custom").setAttribute("aria-pressed", String(c.isCustomized()));
      this.$("#original").classList.toggle("active", !c.isCustomized());
      this.$("#original").setAttribute(
        "aria-pressed",
        String(!c.isCustomized()),
      );
      this.$("#pick").textContent = c.editing
        ? "Selecionar outro elemento"
        : "Ativar seleção por clique";
      this.$("#tip").textContent = !c.isCustomized()
        ? "Página real nesta aba: suas alterações estão guardadas. Outras abas continuam independentes."
        : c.editing
          ? "Escolha outro elemento ou aplique a edição. Links e botões não são acionados durante a seleção."
          : "Ative a seleção e clique em um texto, número ou imagem da página.";
      this.$("#undo").disabled = !c.undoStack.length;
      this.$("#redo").disabled = !c.redoStack.length;
      this.$("#hideBetterBlox").checked = p.hideBetterBlox;
      this.$("#hideLauncher").checked = p.hideLauncher;
      this.$("#changesTitle").textContent =
        `Alterações salvas (${p.patches.length})`;
      const list = this.$("#edits");
      list.replaceChildren();
      for (const p of c.profile.patches) {
        const li = document.createElement("li");
        li.className = "edit";
        const entry = document.createElement("button");
        entry.className = "entry";
        entry.dataset.action = "locate";
        entry.dataset.id = p.id;
        const label = document.createElement("b");
        label.textContent = p.label;
        const small = document.createElement("small");
        small.textContent =
          p.kind === "text"
            ? p.value.slice(0, 90)
            : {
                image: "Imagem personalizada",
                style: "Aparência personalizada",
                hide: "Elemento oculto",
              }[p.kind];
        entry.append(label, small);
        const erase = document.createElement("button");
        erase.className = "erase";
        erase.dataset.action = "remove";
        erase.dataset.id = p.id;
        erase.textContent = "×";
        erase.title = "Restaurar esta alteração";
        li.append(entry, erase);
        list.append(li);
      }
      this.$("#noEdits").hidden = !!p.patches.length;
      this.status(c.lastResult);
      if (c.uiHidden || !c.editing) this.highlight(null);
    }
    status(result) {
      const p = this.c.profile;
      const missing = result ? result.total - result.matched : 0;
      this.$("#status").textContent = !this.c.isCustomized()
        ? "Original ao vivo nesta aba · personalizações preservadas."
        : `${p.patches.length} alteração(ões) · trava automática ativa · ${this.c.saving ? "salvando…" : this.c.saveError ? "não foi salvo — exporte um backup" : "salvo neste navegador"}` +
          (missing ? ` · ${missing} aguardando elemento aparecer` : "") +
          (p.hideBetterBlox
            ? ` · rodapé ${result?.footer ? "oculto" : "aguardando detecção"}`
            : "");
    }
    selection(target) {
      this.$("#empty").hidden = !!target;
      this.$("#selected").hidden = !target;
      if (!target) return;
      this.$("#selectionLabel").textContent =
        `${target.el.localName}${target.el.id ? "#" + target.el.id : ""} · ` +
        (target.image ? "imagem" : target.node ? "texto" : "bloco");
      this.$("#textEditor").hidden = !target.node;
      this.$("#imageEditor").hidden = !target.image;
      if (target.node) this.$("#text").value = target.node.nodeValue;
      if (target.image) {
        const src =
          target.el instanceof HTMLImageElement
            ? target.el.currentSrc || target.el.src
            : getComputedStyle(target.el).backgroundImage.replace(
                /^url\(["']?|["']?\)$/g,
                "",
              );
        this.$("#preview").src = src;
        this.$("#imageURL").value = "";
      }
      for (const id of [
        "color",
        "background",
        "fontSize",
        "radius",
        "width",
        "height",
        "weight",
        "align",
        "opacity",
        "fit",
      ])
        this.$("#" + id).value = "";
      const saved = this.c.profile.patches.find(
        (p) =>
          p.kind === "style" &&
          p.target.selector === AAVEEngine.path(target.el),
      );
      const map = {
        color: "color",
        background: "background-color",
        fontSize: "font-size",
        radius: "border-radius",
        width: "width",
        height: "height",
        weight: "font-weight",
        align: "text-align",
        opacity: "opacity",
        fit: "object-fit",
      };
      if (saved)
        for (const [id, key] of Object.entries(map))
          this.$("#" + id).value = ["fontSize", "radius"].includes(id)
            ? saved.value[key] === undefined
              ? ""
              : parseFloat(saved.value[key])
            : saved.value[key] || "";
    }
    toast(text, error = false) {
      if (this.c.uiHidden || this.c.captureActive) {
        this.lastToast = { text, error };
        return;
      }
      clearTimeout(this.toastTimer);
      const el = this.$(".toast");
      el.textContent = text;
      el.hidden = false;
      el.classList.toggle("error", error);
      this.toastTimer = setTimeout(() => {
        el.hidden = true;
      }, 4300);
    }
    async action(name, id) {
      const c = this.c;
      if (name === "open") c.open(false);
      else if (name === "close") c.closePanel();
      else if (name === "pick") c.togglePick();
      else if (name === "custom" || name === "original")
        await c.flag("enabled", name === "custom");
      else if (name === "hideUI") c.hideUI();
      else if (name === "text")
        await c.safe(() => c.text(this.$("#text").value));
      else if (name === "image")
        await c.image(this.$("#imageURL").value.trim());
      else if (name === "hideElement") await c.patch("hide", true);
      else if (name === "parent") c.parent();
      else if (name === "undo") await c.undo();
      else if (name === "redo") await c.redo();
      else if (name === "remove") await c.remove(id);
      else if (name === "locate") c.locate(id);
      else if (name === "clearStyle") await c.clearStyle();
      else if (name === "reset") await c.reset();
      else if (name === "export") await c.export();
      else if (name === "import") this.$("#importFile").click();
      else if (name === "style") {
        const value = {},
          map = {
            color: "color",
            background: "background-color",
            fontSize: "font-size",
            radius: "border-radius",
            width: "width",
            height: "height",
            weight: "font-weight",
            align: "text-align",
            opacity: "opacity",
            fit: "object-fit",
          };
        for (const [input, key] of Object.entries(map)) {
          let v = this.$("#" + input).value.trim();
          if (v)
            value[key] = ["fontSize", "radius"].includes(input) ? v + "px" : v;
        }
        if (Object.keys(value).length)
          await c.patch("style", AAVEC.styles(value));
        else await c.clearStyle();
      }
    }
  }
  globalThis.AAVEUI = UI;
})();
