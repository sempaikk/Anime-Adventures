/* Editing tools and capture UI, isolated from storage and DOM matching. */
(() => {
  "use strict";
  if (globalThis.AAVEExtras) return;
  const escapeText = (s) => String(s || ""),
    field = (id, label, type = "text", extra = "") =>
      `<label class="field" for="${id}">${label}</label><input id="${id}" type="${type}" ${extra}>`,
    button = (name, label) => `<button data-extra="${name}">${label}</button>`;
  const STYLE = {
    font: "font-family",
    line: "line-height",
    letter: "letter-spacing",
    white: "white-space",
    marginTop: "margin-top",
    marginBottom: "margin-bottom",
    marginLeft: "margin-left",
    marginRight: "margin-right",
    paddingTop: "padding-top",
    paddingBottom: "padding-bottom",
    paddingLeft: "padding-left",
    paddingRight: "padding-right",
    borderWidth: "border-width",
    borderColor: "border-color",
    borderStyle: "border-style",
    shadow: "box-shadow",
    aspect: "aspect-ratio",
    focal: "object-position",
    bgPosition: "background-position",
    bgSize: "background-size",
  };
  class Extras {
    constructor(c) {
      this.c = c;
      this.ui = c.ui;
      this.$ = this.ui.$;
      this.clipboard = null;
      this.imageDraft = null;
      this.filtered = "";
      this.focusBefore = null;
      const block = document.createElement("div");
      block.innerHTML = `<style>.panel{resize:both;min-width:280px;min-height:220px;max-width:calc(100vw - 16px)}.head{cursor:move;touch-action:none}.extras details{margin:9px 0}.extras img{max-width:100%;max-height:130px;object-fit:contain}.extras .library{display:grid;grid-template-columns:1fr 1fr;gap:7px}.asset{background:#14243a;padding:8px;border-radius:8px;overflow-wrap:anywhere}.extras .drop{border:1px dashed #87abdc;padding:12px;border-radius:8px}.extras .grid label{margin-top:4px}.extras progress{width:100%}.extras .computed{white-space:pre-wrap;max-height:170px;overflow:auto;font-size:11px}.edits .small{padding:4px}.extras [role=alert]{color:#ffb9c5}.extras output{display:block;color:#b9dbff;overflow-wrap:anywhere}@media(prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}@media(max-width:450px){.panel{min-width:260px}}:host{line-height:1.5}</style>
   <div class="section extras"><details open id="quickDetails"><summary>Campos rápidos e seleção</summary><div class="tools">${button("quickTitle", "Título")}${button("quickDescription", "Descrição")}${button("quickPlaying", "Jogadores")}${button("quickVisits", "Visitas")}${button("quickImage", "Imagem")}</div><div class="tools">${button("child", "Filho")}${button("prev", "Anterior")}${button("next", "Próximo")}${button("multiAdd", "Adicionar à seleção")}${button("multiClear", "Limpar seleção")}</div><p class="mini" id="multiInfo">Shift+clique reúne elementos. Aparência e ocultar podem usar a seleção.</p>${button("multiStyle", "Aplicar aparência aos selecionados")}${button("multiHide", "Ocultar selecionados")}<label class="switch"><input id="bulkConfirm" type="checkbox">Confirmar aplicação em vários elementos</label><div class="tools">${button("repair", "Reparar destino")}${button("restoreElement", "Restaurar elemento")}${button("copyStyle", "Copiar aparência")}${button("pasteStyle", "Colar aparência")}</div><p class="mini" id="draftInfo"></p></details>
   <details><summary>Texto, número e prévia</summary>${field("numberValue", "Número para formatar", "text", 'placeholder="1234567.89"')}<div class="grid"><select id="numberLocale" aria-label="Separadores"><option value="pt-BR">1.234,56</option><option value="en-US">1,234.56</option></select><select id="numberMode" aria-label="Abreviação"><option value="standard">Completo</option><option value="compact">Abreviado</option></select></div>${button("number", "Colocar número no rascunho")}${button("previewText", "Prévia do rascunho")}${button("cancelPreview", "Cancelar prévia")}<p class="mini">A prévia não grava. Trocar de elemento guarda o rascunho nesta aba. Texto multilinha usa apenas texto simples.</p></details>
   <details id="appearanceExtras"><summary>Aparência avançada e valores reais</summary><div class="grid">${field("colorPicker", "Cor do texto", "color")}${field("backgroundPicker", "Cor do fundo", "color")}</div><p class="mini">Use px, %, em, rem, vw ou vh nas dimensões. Zero é um valor válido. Espaço vazio restaura a propriedade.</p><div class="grid">${field("font", "Fonte local", "text", 'list="localFonts" placeholder="system-ui"')}<datalist id="localFonts">${["Arial", "Verdana", "Georgia", "Tahoma", "Trebuchet MS", "Courier New", "system-ui", "sans-serif", "serif", "monospace"].map((x) => `<option value="${x}">`).join("")}</datalist>${field("line", "Altura da linha", "text", 'placeholder="1.5em"')}${field("letter", "Espaço entre letras", "text", 'placeholder="0px"')}${field("white", "Quebras de linha", "text", 'list="whiteList" placeholder="pre-wrap"')}<datalist id="whiteList"><option value="normal"><option value="pre-wrap"><option value="pre-line"></datalist>${Object.entries(
     STYLE,
   )
     .filter(([id]) => !["font", "line", "letter", "white"].includes(id))
     .map(([id, prop]) => field(id, prop, "text"))
     .join(
       "",
     )}</div><label class="switch"><input id="keepAspect" type="checkbox">Manter proporção da imagem ao alterar largura</label><div class="tools">${button("advancedStyle", "Aplicar aparência completa")}${button("computed", "Atualizar valores")}</div><pre class="computed" id="computed"></pre>${field("restoreProperty", "Restaurar propriedade", "text", 'placeholder="font-size"')}${button("restoreProperty", "Restaurar propriedade")}${field("presetName", "Nome da predefinição", "text", 'maxlength="80"')}<select id="presets" aria-label="Predefinições de aparência"><option value="">Escolha uma aparência</option></select><div class="tools">${button("presetSave", "Salvar/duplicar aparência")}${button("presetApply", "Aplicar aparência")}${button("presetDelete", "Excluir aparência")}</div></details>
   <details id="imageTools"><summary>Imagens: prévia, biblioteca e recorte</summary><p class="mini">Até 4 MB por arquivo e 16 milhões de pixels. A prévia preserva a imagem atual até confirmar.</p><div class="drop" id="dropImage" tabindex="0" role="button" aria-label="Cole ou solte uma imagem aqui">Clique aqui e cole uma imagem, ou arraste um arquivo para esta área.</div><div class="tools">${button("previewLink", "Carregar prévia do link")}${button("confirmImage", "Confirmar imagem")}${button("discardImage", "Descartar prévia")}</div><img id="imageDraft" alt="Prévia ainda não aplicada" hidden><output id="imageInfo"></output><div class="grid">${field("resizeWidth", "Largura do resultado", "number", 'min="1" max="8192"')}${field("resizeHeight", "Altura do resultado", "number", 'min="1" max="8192"')}${field("quality", "Qualidade (0,1 a 1)", "number", 'min="0.1" max="1" step="0.05" value="0.9"')}<label class="field">Formato<select id="imageFormat"><option value="image/png">PNG</option><option value="image/jpeg">JPG</option><option value="image/webp">WebP</option></select></label>${field("focalX", "Foco horizontal (%)", "number", 'min="0" max="100" value="50"')}${field("focalY", "Foco vertical (%)", "number", 'min="0" max="100" value="50"')}</div><label class="switch"><input id="crop" type="checkbox">Recortar para preencher o resultado</label>${button("transform", "Gerar prévia do recorte/redução")}${button("focal", "Aplicar posição e encaixe")}${button("library", "Abrir biblioteca local")}<div class="library" id="library"></div></details>
   <details id="profilesDetails"><summary>Perfis e cenas</summary><label class="field" for="profiles">Perfil desta aba</label><select id="profiles"></select>${field("profileName", "Nome do perfil", "text", 'maxlength="80"')}<div class="tools">${button("profileCreate", "Novo")}${button("profileDuplicate", "Duplicar")}${button("profileRename", "Renomear")}${button("profileDefault", "Usar como padrão")}${button("profileDelete", "Excluir")}</div>${button("exportAll", "Exportar todos os perfis")}${button("usage", "Ver espaço e backups")}${button("recovery", "Recuperar cópia anterior")}${button("legacyExport", "Exportar cópia v1 da migração")}<output id="usage"></output><div id="backups"></div></details>
   <div id="importPreview" hidden role="region" aria-label="Prévia de importação"><p id="importSummary"></p><div class="tools">${button("importMerge", "Combinar com o perfil")}${button("importReplace", "Substituir o perfil")}${button("importCancel", "Cancelar importação")}</div></div>
   <details><summary>Captura PNG</summary><p class="mini">Abra pelo ícone da extensão para autorizar a captura da aba. A prévia permite baixar e repetir. Página inteira: até 16 milhões de pixels, 16.000 px de altura e 20 partes.</p><label class="switch"><input id="freezeImages" type="checkbox">Fixar imagens animadas locais na captura</label><div class="tools">${button("capture", "Capturar área visível")}${button("captureFull", "Capturar página inteira")}${button("captureRetry", "Repetir captura")}${button("captureDownload", "Baixar PNG")}</div>${field("captureName", "Nome do PNG", "text", 'value="anime-adventures.png" maxlength="100"')}<img id="capturePreview" alt="Prévia da captura PNG" hidden><output id="captureInfo"></output></details>
   <details id="helpDetails"><summary>Ajuda, atalhos e posição</summary><p class="mini">1. Selecione um campo. 2. Edite e aplique. 3. Compare com a página real. As alterações afetam somente este navegador. Nenhum saldo, voto ou estatística real é alterado. Tab/Enter selecionam pelo teclado; Esc fecha; Ctrl+Shift+K abre ações.</p><div class="grid">${field("keyPick", "Selecionar: Alt+Shift+letra", "text", 'maxlength="1" value="E"')}${field("keyHide", "Interface: Alt+Shift+letra", "text", 'maxlength="1" value="H"')}${field("keyCompare", "Comparar: Alt+Shift+letra", "text", 'maxlength="1" value="O"')}</div>${button("shortcuts", "Salvar atalhos")}<div class="tools">${button("dockLeft", "Acoplar à esquerda")}${button("dockRight", "Acoplar à direita")}${button("positionReset", "Restaurar posição")}</div>${field("palette", "Buscar ação", "text", 'placeholder="Digite título, captura, perfil…"')}<div id="paletteResults"></div>${button("retrySave", "Tentar salvar")}${button("compareTabs", "Abrir comparação em duas abas")}<p class="mini">Arraste pelo cabeçalho e redimensione pelo canto inferior. Para atualizar, mantenha a pasta AA-Visual-Editor no mesmo local e clique em Recarregar em chrome://extensions.</p></details></div>`;
      this.$(".panel").insertBefore(block, this.$(".foot"));
      this.block = block;
      const quick = document.createElement("div");
      quick.className = "section extras";
      quick.id = "quickAccess";
      quick.innerHTML = '<p class="title">Campos rápidos</p>';
      quick.append(this.$("#quickDetails .tools"));
      const shortcuts = document.createElement("div");
      shortcuts.className = "tools";
      shortcuts.innerHTML =
        button("openProfiles", "Perfis e cenas") +
        button("openPalette", "Buscar ferramenta");
      quick.append(shortcuts);
      this.$(".panel").insertBefore(quick, this.$("#selectionSection"));
      this.$("#quickDetails").open = false;
      this.$("#quickDetails summary").textContent =
        "Seleção, hierarquia e grupos";
      this.ui.root.addEventListener("click", (e) => {
        const b = e.target.closest("[data-extra]");
        if (b) {
          e.preventDefault();
          c.safe(() => this.action(b.dataset.extra, b.dataset.id));
        }
      });
      this.$("#profiles").addEventListener("change", (e) =>
        c.safe(() => c.switchProfile(e.target.value)),
      );
      for (const [picker, input] of [
        ["colorPicker", "color"],
        ["backgroundPicker", "background"],
      ])
        this.$("#" + picker).addEventListener("input", (e) => {
          this.$("#" + input).value = e.target.value;
        });
      this.$("#palette").addEventListener("input", () => this.paletteResults());
      this.$("#text").addEventListener("input", () => this.saveDraft());
      const drop = this.$("#dropImage");
      drop.addEventListener("dragover", (e) => {
        e.preventDefault();
      });
      drop.addEventListener("drop", (e) => {
        e.preventDefault();
        if (e.dataTransfer.files[0])
          c.safe(() => c.imageFile(e.dataTransfer.files[0]));
      });
      drop.addEventListener("paste", (e) => {
        const file = [...e.clipboardData.items]
          .find((i) => i.kind === "file")
          ?.getAsFile();
        if (file) {
          e.preventDefault();
          c.safe(() => c.imageFile(file));
        }
      });
      const search = document.createElement("input");
      search.type = "search";
      search.id = "changesSearch";
      search.placeholder = "Buscar nome, grupo, texto, tipo ou pendente";
      search.setAttribute("aria-label", "Buscar alterações");
      search.addEventListener("input", () => {
        this.filtered = search.value.toLocaleLowerCase();
        this.filter();
      });
      this.$("#changesDetails").insertBefore(search, this.$("#edits"));
      this.$(".head").addEventListener("pointerdown", (e) => {
        if (e.target.closest("button")) return;
        const panel = this.$(".panel"),
          r = panel.getBoundingClientRect();
        this.drag = { x: e.clientX - r.left, y: e.clientY - r.top };
        this.$(".head").setPointerCapture(e.pointerId);
      });
      this.$(".head").addEventListener("pointermove", (e) => {
        if (!this.drag) return;
        const panel = this.$(".panel");
        panel.style.right = "auto";
        panel.style.left = e.clientX - this.drag.x + "px";
        panel.style.top = e.clientY - this.drag.y + "px";
        this.clamp();
      });
      this.$(".head").addEventListener("pointerup", () => {
        this.drag = null;
        c.safe(() => this.savePosition());
      });
      this.resize = new ResizeObserver(() => {
        if (this.ignoreResize) return;
        this.clamp();
        clearTimeout(this.resizeTimer);
        this.resizeTimer = setTimeout(
          () => c.safe(() => this.savePosition()),
          400,
        );
      });
      this.resize.observe(this.$(".panel"));
      this.ui.renderBase = this.ui.render.bind(this.ui);
      this.ui.render = () => {
        this.ui.renderBase();
        this.render();
      };
      this.ui.selectionBase = this.ui.selection.bind(this.ui); // Explicit selection calls keep drafts predictable.
    }
    filter() {
      for (const li of this.$("#edits").children) {
        const p = this.c.profile.patches.find(
          (p) => p.id === li.querySelector("[data-id]")?.dataset.id,
        );
        if (!p) continue;
        const pending = !this.c.engine.bindings.has(p.id);
        li.hidden =
          !!this.filtered &&
          !`${p.label} ${p.group || ""} ${p.kind} ${typeof p.value === "string" ? p.value : ""} ${pending ? "pendente" : ""}`
            .toLocaleLowerCase()
            .includes(this.filtered);
      }
    }
    render() {
      if (!this.c.book) return;
      const c = this.c,
        select = this.$("#profiles"),
        active = select.value;
      select.replaceChildren();
      for (const p of c.book.profiles) {
        const o = document.createElement("option");
        o.value = p.id;
        o.textContent =
          p.name + (p.id === c.book.defaultProfile ? " · padrão" : "");
        select.append(o);
      }
      select.value = c.profileId;
      this.$("#multiInfo").textContent =
        `${c.multi.length} elementos na seleção. Shift+clique adiciona.`;
      const presets = this.$("#presets"),
        selected = presets.value;
      presets.replaceChildren(new Option("Escolha uma aparência", ""));
      for (const p of c.book.presets)
        presets.append(new Option(p.name, p.name));
      presets.value = selected;
      for (const li of this.$("#edits").children) {
        const id = li.querySelector("[data-id]")?.dataset.id,
          p = c.profile.patches.find((p) => p.id === id);
        if (!p) continue;
        if (li.querySelector(".aave-meta")) continue;
        const toggle = document.createElement("button");
        toggle.className = "small aave-meta";
        toggle.textContent = p.enabled === false ? "Ligar" : "Pausar";
        toggle.setAttribute("aria-label", `${toggle.textContent} ${p.label}`);
        toggle.onclick = () =>
          c.safe(() => this.update(id, { enabled: p.enabled === false }));
        const edit = document.createElement("button");
        edit.className = "small";
        edit.textContent = "Nome/grupo";
        edit.onclick = () => this.editMetadata(p);
        li.append(toggle, edit);
        if (p.group) {
          const s = document.createElement("small");
          s.textContent = p.group;
          li.append(s);
        }
      }
      this.filter();
      if (!this.positionLoaded && c.scoped) {
        this.positionLoaded = true;
        this.applyPosition(c.book.settings.panel);
      }
      if (c.uiHidden) this.$(".toast").hidden = true;
    }
    editMetadata(p) {
      const section = document.createElement("div");
      section.className = "section";
      const name = document.createElement("input"),
        group = document.createElement("input");
      name.value = p.label;
      name.maxLength = 120;
      name.setAttribute("aria-label", "Nome da alteração");
      group.value = p.group || "";
      group.maxLength = 80;
      group.setAttribute("aria-label", "Grupo");
      const save = document.createElement("button");
      save.textContent = "Salvar nome/grupo";
      save.onclick = () =>
        this.c.safe(async () => {
          await this.update(p.id, { label: name.value, group: group.value });
          section.remove();
        });
      const toggle = document.createElement("button");
      toggle.textContent = "Pausar/ligar grupo";
      toggle.onclick = () =>
        this.c.safe(async () => {
          const enabled = !(p.enabled !== false),
            patches = this.c.profile.patches.map((x) =>
              x.group === group.value ? { ...x, enabled } : x,
            );
          await this.c.commit({ ...this.c.profile, patches });
          section.remove();
        });
      const cancel = document.createElement("button");
      cancel.textContent = "Cancelar";
      cancel.onclick = () => section.remove();
      section.append(name, group, save, toggle, cancel);
      this.$(".panel").append(section);
      name.focus();
    }
    update(id, fields) {
      return this.c.commit({
        ...this.c.profile,
        patches: this.c.profile.patches.map((p) =>
          p.id === id ? { ...p, ...fields } : p,
        ),
      });
    }
    saveDraft() {
      if (!this.c.selected?.el.isConnected) return;
      const key = this.c.profileId + ":" + AAVEEngine.path(this.c.selected.el),
        text = this.$("#text").value;
      this.c.drafts.set(key, { text, image: this.$("#imageURL").value });
      while (
        this.c.drafts.size > 50 ||
        AAVEC.bytes([...this.c.drafts.values()]) > 1024 * 1024
      )
        this.c.drafts.delete(this.c.drafts.keys().next().value);
    }
    selection(target) {
      if (!target) return;
      const c = this.c,
        draft = c.drafts.get(c.profileId + ":" + AAVEEngine.path(target.el));
      if (draft) {
        this.$("#text").value = draft.text;
        this.$("#imageURL").value = draft.image;
        this.$("#draftInfo").textContent =
          "Rascunho desta aba recuperado. Aplique para salvar.";
      } else this.$("#draftInfo").textContent = "";
      const style = c.profile.patches.find(
        (p) =>
          p.kind === "style" &&
          p.target.selector === AAVEEngine.path(target.el),
      );
      for (const [id, key] of Object.entries(STYLE))
        this.$("#" + id).value = style?.value[key] ?? "";
      this.computed();
    }
    computed() {
      const el = this.c.selected?.el;
      if (!el) return;
      const style = getComputedStyle(el),
        p = this.c.profile.patches.find(
          (p) =>
            p.kind === "style" && p.target.selector === AAVEEngine.path(el),
        );
      this.$("#computed").textContent = [
        "color",
        "background-color",
        "font-size",
        "width",
        "height",
        "border-radius",
        "line-height",
        "opacity",
      ]
        .map(
          (k) =>
            `${k}: ${style.getPropertyValue(k)}${p?.value[k] !== undefined ? " · personalizado · original: " + this.c.engine.originalStyle(el, k) : " · original"}`,
        )
        .join("\n");
    }
    style() {
      const map = {
          color: "color",
          background: "background-color",
          fontSize: "font-size",
          radius: "border-radius",
          width: "width",
          height: "height",
          weight: "font-weight",
          align: "text-align",
          opacity: "opacity",
          fit: "object-fit",
          ...STYLE,
        },
        value = {};
      for (const [id, key] of Object.entries(map)) {
        let v = this.$("#" + id).value.trim();
        if (v !== "")
          value[key] = ["fontSize", "radius"].includes(id) ? v + "px" : v;
      }
      if (
        this.$("#keepAspect").checked &&
        this.c.selected?.el instanceof HTMLImageElement &&
        value.width?.endsWith("px")
      ) {
        const im = this.c.selected.el;
        value.height =
          (
            (parseFloat(value.width) * im.naturalHeight) /
            im.naturalWidth
          ).toFixed(2) + "px";
      }
      return AAVEC.styles(value);
    }
    setImageDraft(data, target = this.c.target()) {
      this.imageTarget = target;
      this.imageProfile = this.c.profileId;
      this.imageDraft = data;
      this.$("#imageDraft").src = data;
      this.$("#imageDraft").hidden = false;
      this.$("#imageTools").open = true;
      this.$(".panel").scrollTop = this.$("#imageTools").offsetTop;
      this.$("#imageInfo").textContent =
        "Prévia carregada. Confirme para aplicar.";
    }
    showImport(count, profiles) {
      this.$("#importPreview").hidden = !count && !profiles;
      this.$("#importSummary").textContent =
        `${profiles} perfil(is), ${count} alterações. Arquivo: ${((this.importBytes || 0) / 1048576).toFixed(2)} MB. ${this.importConflicts()} conflito(s) de campo. Substituir remove as alterações atuais; combinar preserva campos diferentes e dá preferência aos do arquivo em conflito. Uma cópia anterior será guardada.`;
      const library = !!this.importDraft?.book;
      this.$('[data-extra="importReplace"]').textContent = library
        ? "Substituir biblioteca"
        : "Substituir perfil";
      this.$('[data-extra="importMerge"]').textContent = library
        ? "Combinar bibliotecas"
        : "Combinar com o perfil";
      if (library)
        this.$("#importSummary").textContent +=
          " Substituir biblioteca troca TODOS os perfis pelos do arquivo. Combinar preserva perfis diferentes e aplica mudanças nos perfis de mesma identidade.";
      if (count || profiles)
        this.$("#importPreview").scrollIntoView({ block: "nearest" });
    }
    importConflicts() {
      const incoming =
        this.importDraft?.profile?.patches ||
        this.importDraft?.book?.profiles.flatMap((p) => p.profile.patches) ||
        [];
      return incoming.filter((p) =>
        this.c.profile.patches.some(
          (q) =>
            q.kind === p.kind &&
            q.target.selector === p.target.selector &&
            JSON.stringify(q.value) !== JSON.stringify(p.value),
        ),
      ).length;
    }
    async action(action, id) {
      const c = this.c;
      if (action.startsWith("quick")) {
        const choices = {
          quickTitle: ["#game-title", "h1.game-name", "h1"],
          quickDescription: [
            "#description",
            ".game-description-container",
            ".game-description",
          ],
          quickPlaying: ["#playing", '[data-testid="playing-count"]'],
          quickVisits: ["#visits", '[data-testid="visits-count"]'],
          quickImage: ["#hero", ".game-covers img", "img.game-thumbnail"],
        };
        const selector = choices[action].find((q) => document.querySelector(q));
        let el = selector && document.querySelector(selector);
        if (!el)
          throw Error(
            "Esse campo não foi reconhecido nesta página. Use seleção por clique.",
          );
        const n = AAVEEngine.textNodes(el)[0];
        c.select({
          el,
          node: n || null,
          image: el instanceof HTMLImageElement ? "src" : "",
        });
        el.scrollIntoView({ block: "center" });
      } else if (["child", "prev", "next"].includes(action)) c.navigate(action);
      else if (action === "multiAdd") {
        if (!c.selected) throw Error("Selecione um elemento.");
        c.addSelection(c.selected);
        this.render();
      } else if (action === "multiClear") {
        c.multi = [];
        this.render();
      } else if (action === "multiHide" || action === "multiStyle") {
        if (!this.$("#bulkConfirm").checked)
          throw Error("Confirme a aplicação em vários elementos.");
        if (!c.multi.length) throw Error("Adicione elementos à seleção.");
        await c.bulk(
          action === "multiHide" ? "hide" : "style",
          action === "multiHide" ? true : this.style(),
          c.multi,
        );
        this.$("#bulkConfirm").checked = false;
      } else if (action === "repair") {
        if (!this.repairId)
          throw Error(
            "Clique numa alteração pendente na lista antes de reparar.",
          );
        await this.update(this.repairId, { target: c.target() });
        this.repairId = null;
        c.ui.toast("Destino atualizado e salvo.");
      } else if (action === "restoreElement") {
        const selector = c.target().selector;
        await c.commit({
          ...c.profile,
          patches: c.profile.patches.filter(
            (p) => p.target.selector !== selector,
          ),
        });
      } else if (action === "copyStyle") {
        const el = c.selected?.el;
        if (!el) throw Error("Selecione um elemento.");
        const computed = getComputedStyle(el);
        const hex = (v) => {
          if (/^rgba\([^)]*,\s*0(?:\.0+)?\)$/.test(v)) return "";
          const m = v.match(
            /^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[\d.]+)?\)$/,
          );
          return m
            ? "#" +
                m
                  .slice(1, 4)
                  .map((n) => (+n).toString(16).padStart(2, "0"))
                  .join("")
            : v;
        };
        const saved = c.profile.patches.find(
          (p) =>
            p.kind === "style" &&
            (c.engine.bindings.get(p.id)?.el === el ||
              p.target.selector === AAVEEngine.path(el)),
        );
        this.clipboard = saved
          ? structuredClone(saved.value)
          : AAVEC.styles(
              Object.fromEntries(
                [
                  "color",
                  "background-color",
                  "font-size",
                  "font-weight",
                  "text-align",
                  "border-radius",
                  "opacity",
                  "object-fit",
                ]
                  .map((k) => [
                    k,
                    ["color", "background-color"].includes(k)
                      ? hex(computed.getPropertyValue(k))
                      : computed.getPropertyValue(k),
                  ])
                  .filter(
                    ([k, v]) =>
                      !["color", "background-color"].includes(k) ||
                      /^#[a-f\d]{6}$/i.test(v),
                  ),
              ),
            );
        c.ui.toast("Aparência copiada nesta aba.");
      } else if (action === "pasteStyle") {
        if (!this.clipboard) throw Error("Copie uma aparência primeiro.");
        await c.patch("style", this.clipboard);
      } else if (action === "number") {
        const n = Number(this.$("#numberValue").value);
        if (!this.$("#numberValue").value.trim() || !Number.isFinite(n))
          throw Error("Digite um número válido usando ponto decimal.");
        this.$("#text").value = new Intl.NumberFormat(
          this.$("#numberLocale").value,
          { notation: this.$("#numberMode").value, maximumFractionDigits: 2 },
        ).format(n);
        this.saveDraft();
      } else if (action === "previewText") {
        if (!c.selected?.node) throw Error("Selecione um texto.");
        this.preview = { target: c.target(), value: this.$("#text").value };
        c.engine.apply(
          {
            ...c.profile,
            patches: [
              ...c.profile.patches.filter(
                (p) =>
                  !(
                    p.kind === "text" &&
                    p.target.selector === this.preview.target.selector
                  ),
              ),
              {
                id: "preview-temporary",
                kind: "text",
                target: this.preview.target,
                label: "Prévia",
                value: this.preview.value,
              },
            ],
          },
          c.assets,
        );
        this.$("#draftInfo").textContent =
          "Prévia não salva. Aplique ou cancele.";
      } else if (action === "cancelPreview") {
        this.preview = null;
        c.engine.clear();
        c.apply();
        this.$("#draftInfo").textContent =
          "Prévia cancelada; rascunho preservado.";
      } else if (action === "advancedStyle")
        await c.patch("style", this.style());
      else if (action === "computed") this.computed();
      else if (action === "restoreProperty") {
        const key = this.$("#restoreProperty").value.trim(),
          selector = c.target().selector,
          p = c.profile.patches.find(
            (p) => p.kind === "style" && p.target.selector === selector,
          );
        if (!p || !(key in p.value))
          throw Error("Esta propriedade não tem personalização.");
        const value = { ...p.value };
        delete value[key];
        await this.update(p.id, { value });
      } else if (action.startsWith("preset")) {
        const name =
          this.$("#presetName").value.trim() || this.$("#presets").value;
        if (!name) throw Error("Digite ou escolha um nome.");
        if (action === "presetApply") {
          const p = c.book.presets.find((p) => p.name === name);
          if (!p) throw Error("Aparência não encontrada.");
          await c.patch("style", p.style);
        } else {
          c.book = await AAVEStore.request("preset", {
            name,
            style: action === "presetSave" ? this.style() : null,
            opId: crypto.randomUUID(),
          });
          this.render();
        }
      } else if (action === "previewLink") {
        const url = AAVEC.imageURL(this.$("#imageURL").value),
          target = c.target(),
          profile = c.profileId,
          token = (this.previewRequest = (this.previewRequest || 0) + 1);
        await AAVEImages.decode(url);
        if (token !== this.previewRequest) return;
        if (profile !== c.profileId)
          throw Error(
            "O perfil mudou durante a prévia. Carregue o link novamente.",
          );
        this.setImageDraft(url, target);
      } else if (action === "confirmImage") {
        if (!this.imageDraft)
          throw Error("Escolha um arquivo ou carregue a prévia do link.");
        if (this.imageProfile !== c.profileId)
          throw Error("Volte ao perfil em que esta prévia foi escolhida.");
        await c.image(this.imageDraft, this.imageTarget);
        this.imageDraft = null;
        this.$("#imageInfo").textContent = "Imagem aplicada e salva.";
      } else if (action === "discardImage") {
        this.imageDraft = null;
        this.$("#imageDraft").hidden = true;
        this.$("#imageInfo").textContent =
          "Prévia descartada. A imagem anterior foi preservada.";
      } else if (action === "transform") {
        if (!this.imageDraft) throw Error("Carregue uma imagem para a prévia.");
        const target = this.imageTarget,
          profile = this.imageProfile,
          token = (this.previewRequest = (this.previewRequest || 0) + 1);
        const data = await AAVEImages.transform(this.imageDraft, {
          width: this.$("#resizeWidth").value,
          height: this.$("#resizeHeight").value,
          quality: this.$("#quality").value,
          crop: this.$("#crop").checked,
          x: this.$("#focalX").value,
          y: this.$("#focalY").value,
          format: this.$("#imageFormat").value,
        });
        if (token !== this.previewRequest) return;
        if (profile !== c.profileId)
          throw Error(
            "O perfil mudou durante o recorte. Escolha a imagem novamente.",
          );
        this.setImageDraft(data, target);
      } else if (action === "focal") {
        const position = `${Number(this.$("#focalX").value)}% ${Number(this.$("#focalY").value)}%`,
          old =
            c.profile.patches.find(
              (p) =>
                p.kind === "style" && p.target.selector === c.target().selector,
            )?.value || {};
        await c.patch("style", {
          ...old,
          "object-position": position,
          "background-position": position,
        });
      } else if (action === "library") await this.library();
      else if (action.startsWith("profile")) {
        const command = action.slice(7).toLowerCase();
        await c.profileAction(
          command,
          this.$("#profileName").value.trim() || "Meu perfil",
        );
      } else if (action === "exportAll") {
        await c.flush();
        await c.exportSet(true);
      } else if (action === "openProfiles") {
        this.$("#profilesDetails").open = true;
        this.$("#profilesDetails").scrollIntoView({ block: "start" });
        this.$("#profiles").focus();
      } else if (action === "openPalette") {
        this.palette();
      } else if (action === "usage") await this.usage();
      else if (action === "legacyExport") {
        const legacy = await AAVEStore.request("legacyRead");
        if (!legacy)
          throw Error("Não há uma cópia v1 de migração nesta instalação.");
        c.download(legacy, "anime-adventures-perfil-v1-migracao.json");
      } else if (action === "recovery") {
        const rows = await AAVEStore.request("recoverList"),
          box = this.$("#backups");
        box.replaceChildren();
        if (!rows.length)
          throw Error(
            "Nenhuma cópia anterior está disponível nesta instalação.",
          );
        for (const row of rows) {
          const b = document.createElement("button");
          b.textContent =
            "Restaurar biblioteca de " + new Date(row.time).toLocaleString();
          b.onclick = () =>
            c.safe(async () => {
              c.book = await AAVEStore.request("backupRestore", { id: row.id });
              c.pendingOps = [];
              c.saveError = false;
              await c.switchProfile(c.book.defaultProfile);
              c.ui.toast("Biblioteca anterior recuperada e salva.");
            });
          box.append(b);
        }
      } else if (action === "importMerge" || action === "importReplace")
        await c.importApply(action === "importMerge");
      else if (action === "importCancel") {
        this.importDraft = null;
        this.showImport(0, 0);
      } else if (["capture", "captureFull", "captureRetry"].includes(action))
        await this.capture(
          action === "captureFull" ||
            (action === "captureRetry" && this.lastFull),
        );
      else if (action === "captureDownload") {
        if (!this.captureData) throw Error("Faça uma captura primeiro.");
        const name =
          this.$("#captureName")
            .value.replace(/[^\w. -]/g, "")
            .slice(0, 90) || "anime-adventures.png";
        const a = document.createElement("a");
        a.href = this.captureData;
        a.download = name.toLowerCase().endsWith(".png") ? name : name + ".png";
        this.ui.root.append(a);
        a.click();
        a.remove();
      } else if (action === "retrySave") await c.flush();
      else if (action === "compareTabs") {
        await c.flush();
        await c.flag("enabled", true);
        await AAVEStore.request("compare", { profileId: c.profileId });
        c.ui.toast(
          "Comparação aberta: esta aba personalizada e outra com a página real.",
        );
      } else if (action === "shortcuts") {
        const keys = {
          pick: "Key" + this.$("#keyPick").value.toUpperCase(),
          hide: "Key" + this.$("#keyHide").value.toUpperCase(),
          compare: "Key" + this.$("#keyCompare").value.toUpperCase(),
        };
        if (
          new Set(Object.values(keys)).size !== 3 ||
          !Object.values(keys).every((k) => /^Key[A-Z]$/.test(k))
        )
          throw Error("Escolha três letras diferentes.");
        c.book = await AAVEStore.request("settings", {
          shortcuts: keys,
          opId: crypto.randomUUID(),
        });
        c.ui.toast("Atalhos salvos. O ícone continua abrindo o editor.");
      } else if (action === "dockLeft" || action === "dockRight") {
        this.applyPosition({
          left:
            action === "dockLeft"
              ? 8
              : Math.max(8, innerWidth - this.$(".panel").offsetWidth - 8),
          top: 60,
        });
        await this.savePosition();
      } else if (action === "positionReset") {
        this.$(".panel").removeAttribute("style");
        this.clamp();
        await this.savePosition();
      }
    }
    async library() {
      const rows = await AAVEStore.request("assets", { ids: [] }),
        box = this.$("#library");
      box.replaceChildren();
      for (const a of rows) {
        const el = document.createElement("div");
        el.className = "asset";
        const title = document.createElement("input");
        title.value = a.name;
        title.maxLength = 80;
        title.setAttribute("aria-label", "Nome da imagem");
        const info = document.createElement("p");
        info.className = "mini";
        const usage = this.c.book.profiles.filter((p) =>
          p.profile.patches.some((x) => x.kind === "image" && x.value === a.id),
        ).length;
        info.textContent = `${(a.bytes / 1024).toFixed(1)} KB · ${usage} perfil(is)`;
        const use = document.createElement("button");
        use.textContent = "Prévia";
        use.onclick = () =>
          this.c.safe(async () => {
            const row = (
              await AAVEStore.request("assets", { ids: [a.id] })
            ).find((x) => x.id === a.id);
            if (row?.data) {
              this.c.assets.set(a.id, row.data);
              this.setImageDraft(row.data);
              const im = document.createElement("img");
              im.src = row.data;
              im.alt = a.name;
              el.prepend(im);
            }
          });
        const rename = document.createElement("button");
        rename.textContent = "Renomear";
        rename.onclick = () =>
          this.c.safe(() =>
            AAVEStore.request("assetName", { id: a.id, name: title.value }),
          );
        const remove = document.createElement("button");
        remove.textContent = "Excluir sem uso";
        remove.onclick = () =>
          this.c.safe(async () => {
            if (
              JSON.stringify([
                this.c.undoStack,
                this.c.redoStack,
                this.c.pendingOps,
              ]).includes(a.id)
            )
              throw Error(
                "Esta imagem ainda é usada pelo histórico desta aba.",
              );
            await AAVEStore.request("assetDelete", { id: a.id });
            await this.library();
          });
        if (a.thumb) {
          const thumbnail = document.createElement("img");
          thumbnail.src = a.thumb;
          thumbnail.alt = a.name;
          thumbnail.loading = "lazy";
          el.append(thumbnail);
        }
        el.append(title, info, use, rename, remove);
        box.append(el);
      }
    }
    async usage() {
      const u = await AAVEStore.request("usage");
      this.$("#usage").textContent =
        `Metadados: ${(u.metadata / 1024).toFixed(1)} KB de 9 MB. Imagens: ${(u.assets / 1048576).toFixed(2)} de 64 MB. ${u.backups} backups automáticos.${u.estimate?.usage !== undefined ? " Uso medido pelo navegador: " + (u.estimate.usage / 1048576).toFixed(2) + " MB." : ""}`;
      const box = this.$("#backups");
      box.replaceChildren();
      for (const backup of this.c.book.backups) {
        const b = document.createElement("button");
        b.textContent = "Recuperar " + new Date(backup.time).toLocaleString();
        b.onclick = () =>
          this.c.safe(async () => {
            const book = await AAVEStore.request("backupRead", {
              id: backup.id,
            });
            this.importDraft = { book };
            this.showImport(
              book.profiles.reduce((s, p) => s + p.profile.patches.length, 0),
              book.profiles.length,
            );
          });
        box.append(b);
      }
    }
    palette() {
      this.$("#helpDetails").open = true;
      this.$("#palette").focus();
      this.paletteResults();
    }
    paletteResults() {
      const text = this.$("#palette").value.toLocaleLowerCase(),
        box = this.$("#paletteResults");
      box.replaceChildren();
      for (const b of [...this.ui.root.querySelectorAll("button[data-extra]")]
        .filter(
          (b) =>
            !b.closest("#paletteResults") &&
            b.textContent.toLocaleLowerCase().includes(text),
        )
        .slice(0, 8)) {
        const button = document.createElement("button");
        button.textContent = b.textContent;
        button.onclick = () => this.c.safe(() => this.action(b.dataset.extra));
        box.append(button);
      }
    }
    clamp() {
      const p = this.$(".panel");
      if (p.hidden) return;
      const r = p.getBoundingClientRect(),
        left = Math.max(
          8,
          Math.min(r.left, innerWidth - Math.min(r.width, innerWidth - 16) - 8),
        ),
        top = Math.max(8, Math.min(r.top, innerHeight - 60));
      this.ignoreResize = true;
      p.style.maxWidth = Math.max(260, innerWidth - 16) + "px";
      p.style.maxHeight = Math.max(180, innerHeight - top - 8) + "px";
      if (p.style.left) {
        p.style.left = left + "px";
        p.style.top = top + "px";
      }
      this.ignoreResize = false;
    }
    applyPosition(position = {}) {
      const p = this.$(".panel");
      for (const key of ["left", "top", "width", "height"])
        if (Number.isFinite(position[key]))
          p.style[key] = Math.max(0, Math.min(5000, position[key])) + "px";
      if (p.style.left) p.style.right = "auto";
      this.clamp();
    }
    async savePosition() {
      const p = this.$(".panel");
      if (p.hidden || this.c.captureActive || !this.c.scoped) return;
      const r = p.getBoundingClientRect();
      const panel = {
        left: Math.round(r.left),
        top: Math.round(r.top),
        width: Math.round(r.width),
        height: Math.round(r.height),
      };
      if (JSON.stringify(panel) === JSON.stringify(this.lastPosition)) return;
      this.lastPosition = panel;
      this.c.book = await AAVEStore.request("settings", {
        panel,
        opId: crypto.randomUUID(),
      });
    }
    restoreFocus() {
      this.focusBefore?.focus?.();
    }
    async capture(full = false) {
      const c = this.c;
      if (c.captureActive) throw Error("Uma captura já está em andamento.");
      await c.flush();
      const saved = {
          hidden: c.uiHidden,
          open: c.panelOpen,
          editing: c.editing,
          x: scrollX,
          y: scrollY,
        },
        temporary = [],
        animations = [];
      this.lastFull = full;
      c.captureActive = true;
      c.hideUI();
      let canvas,
        completed = false;
      const frame = () =>
        new Promise((r) =>
          requestAnimationFrame(() => requestAnimationFrame(r)),
        );
      try {
        for (const a of document.getAnimations()) {
          if (a.playState === "running") {
            a.pause();
            animations.push(a);
          }
        }
        if (this.$("#freezeImages").checked)
          for (const p of c.profile.patches.filter(
            (p) => p.kind === "image" && p.value.startsWith("aave-asset:"),
          )) {
            const data = c.assets.get(p.value);
            if (data?.startsWith("data:image/gif")) {
              const b = c.engine.bindings.get(p.id);
              if (b?.el instanceof HTMLImageElement) {
                const original = b.el.src,
                  staticData = await AAVEImages.transform(data);
                c.engine.write(() => {
                  b.el.src = staticData;
                });
                temporary.push(() => {
                  b.el.src = original;
                });
              }
            }
          }
        if (full) {
          const width = Math.ceil(document.documentElement.clientWidth),
            height = Math.ceil(
              Math.max(
                document.body.scrollHeight,
                document.documentElement.scrollHeight,
              ),
            );
          if (
            height > 16000 ||
            height * width > 16000000 ||
            Math.ceil(height / innerHeight) > 20 ||
            document.documentElement.scrollWidth > width + 4
          )
            throw Error(
              "Esta página excede o limite da captura inteira ou tem rolagem horizontal. Use a área visível.",
            );
          canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          let expectedHeight = height,
            hiddenFixed = false;
          for (let y = 0; y < height; y += innerHeight) {
            scrollTo(0, y);
            await frame();
            await new Promise((r) => setTimeout(r, 100));
            if (
              Math.max(
                document.body.scrollHeight,
                document.documentElement.scrollHeight,
              ) >
              expectedHeight + 4
            )
              throw Error(
                "O conteúdo cresceu durante a captura. Role a página até carregar e tente de novo.",
              );
            const data = await AAVEStore.request("capture"),
              im = await AAVEImages.decode(data, {
                maxBytes: 80 * 1024 * 1024,
              }),
              actualY = scrollY,
              scale = im.naturalWidth / innerWidth,
              sourceY = Math.max(0, y - actualY) * scale,
              take = Math.min(innerHeight - (y - actualY), height - y);
            if (take <= 0) throw Error("Não foi possível percorrer a página.");
            ctx.drawImage(
              im,
              0,
              sourceY,
              width * scale,
              take * scale,
              0,
              y,
              width,
              take,
            );
            if (!hiddenFixed) {
              hiddenFixed = true;
              for (const el of document.body.querySelectorAll("*")) {
                if (el.closest("[data-aave-root]")) continue;
                const style = getComputedStyle(el);
                if (["fixed", "sticky"].includes(style.position)) {
                  const old = el.style.getPropertyValue("visibility"),
                    priority = el.style.getPropertyPriority("visibility");
                  c.engine.write(() =>
                    el.style.setProperty("visibility", "hidden", "important"),
                  );
                  temporary.push(() =>
                    old
                      ? el.style.setProperty("visibility", old, priority)
                      : el.style.removeProperty("visibility"),
                  );
                }
              }
            }
          }
          this.captureData = canvas.toDataURL("image/png");
        } else {
          await frame();
          this.captureData = await AAVEStore.request("capture");
          await AAVEImages.decode(this.captureData, {
            maxBytes: 80 * 1024 * 1024,
          });
        }
        this.$("#capturePreview").src = this.captureData;
        this.$("#capturePreview").hidden = false;
        this.$("#captureInfo").textContent =
          "Captura pronta. Confira a prévia e escolha Baixar PNG.";
        completed = true;
      } catch (e) {
        this.$("#captureInfo").textContent =
          "Captura não concluída: " + e.message;
        throw Error(
          "Captura não concluída. Abra pelo ícone da extensão para conceder acesso à aba. " +
            e.message,
        );
      } finally {
        if (canvas) canvas.width = canvas.height = 1;
        for (const restore of temporary.reverse()) c.engine.write(restore);
        for (const a of animations)
          try {
            a.play();
          } catch {}
        scrollTo(saved.x, saved.y);
        c.captureActive = false;
        c.uiHidden = completed ? false : saved.hidden;
        c.panelOpen = completed ? true : saved.open;
        c.editing = completed ? false : saved.editing;
        this.ui.render();
        this.$("#capturePreview").closest("details").open = true;
        if (completed)
          this.$(".panel").scrollTop =
            this.$("#capturePreview").closest("details").offsetTop;
      }
    }
    dispose() {
      this.resize.disconnect();
      clearTimeout(this.resizeTimer);
    }
  }
  globalThis.AAVEExtras = Extras;
})();
