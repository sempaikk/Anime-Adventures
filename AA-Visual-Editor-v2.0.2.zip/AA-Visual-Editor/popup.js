"use strict";
let tab;
const $ = (id) => document.getElementById(id);
async function send(action, value) {
  const message = { app: "aa-visual-editor", action, value };
  let response;
  try {
    response = await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    // Supports arriving through Roblox's client-side navigation from another page.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [
        "core.js",
        "storage.js",
        "images.js",
        "engine.js",
        "ui.js",
        "extras.js",
        "content.js",
      ],
    });
    const ready = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        return Boolean(await globalThis.__aaVisualEditor?.ready);
      },
    });
    if (!ready[0]?.result)
      throw Error(
        "Não foi possível abrir o editor. Atualize a página e tente de novo.",
      );
    response = await chrome.tabs.sendMessage(tab.id, message);
  }
  if (!response?.ok)
    throw Error(response?.error || "Recarregue a página e tente de novo.");
  $("enabled").checked = response.enabled;
  $("footer").checked = response.hideBetterBlox;
  $("status").textContent =
    `${response.count} alteração(ões) · ${response.saved ? "salvas" : "há alterações ainda não salvas"} · ${response.enabled ? "versão personalizada" : "página real"}.`;
  return response;
}
function fail(error) {
  $("status").textContent = error.message;
}
document.addEventListener("DOMContentLoaded", async () => {
  try {
    [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch (error) {
    fail(error);
    return;
  }
  if (!tab || !AAVEC.inScope(tab.url)) {
    $("status").textContent =
      "Abra a página do Anime Adventures para usar o editor.";
    return;
  }
  try {
    await send("state");
    $("controls").hidden = false;
  } catch (error) {
    fail(error);
  }
});
$("open").addEventListener("click", () =>
  send("open")
    .then(() => window.close())
    .catch(fail),
);
$("pick").addEventListener("click", () =>
  send("pick")
    .then(() => window.close())
    .catch(fail),
);
$("capture").addEventListener("click", () =>
  send("hideUI")
    .then(() => window.close())
    .catch(fail),
);
$("enabled").addEventListener("change", (e) =>
  send("enabled", e.target.checked).catch(fail),
);
$("footer").addEventListener("change", (e) =>
  send("hideBetterBlox", e.target.checked).catch(fail),
);

$("capturePNG").addEventListener("click", () => send("capture").catch(fail));
$("captureFull").addEventListener("click", () =>
  chrome.tabs
    .sendMessage(tab.id, {
      app: "aa-visual-editor",
      action: "capture",
      full: true,
    })
    .then((response) => {
      if (!response?.ok) throw Error(response?.error || "Falha ao capturar.");
    })
    .catch(fail),
);
