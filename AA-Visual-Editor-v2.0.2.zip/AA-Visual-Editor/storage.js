/* Extension-origin storage. Only the service worker writes the shared book. */
(() => {
  "use strict";
  if (globalThis.AAVEStore) return;
  const KEY = "aa-visual-editor.book.v2",
    APP = "aave-store-v2",
    LIMIT = 64 * 1024 * 1024;
  const clone = (x) => structuredClone(x),
    same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const blank = () => ({
    schema: 2,
    app: "aa-visual-editor",
    placeId: AAVEC.PLACE,
    revision: 0,
    defaultProfile: "default",
    profiles: [{ id: "default", name: "Meu perfil", profile: AAVEC.fresh() }],
    settings: {
      shortcuts: { pick: "KeyE", hide: "KeyH", compare: "KeyO" },
      panel: {},
    },
    presets: [],
    recent: [],
    backups: [],
    conflicts: 0,
  });
  function book(raw) {
    if (
      !raw ||
      raw.schema !== 2 ||
      raw.app !== "aa-visual-editor" ||
      raw.placeId !== AAVEC.PLACE ||
      !Array.isArray(raw.profiles) ||
      raw.profiles.length < 1 ||
      raw.profiles.length > 20
    )
      throw Error(
        "Biblioteca de perfis inválida. Sua cópia anterior foi preservada.",
      );
    const out = blank(),
      ids = new Set();
    out.revision = Number.isSafeInteger(raw.revision) ? raw.revision : 0;
    out.profiles = raw.profiles.map((p) => {
      if (
        !p ||
        typeof p.id !== "string" ||
        !/^[\w-]{1,64}$/.test(p.id) ||
        ids.has(p.id) ||
        typeof p.name !== "string" ||
        !p.name.trim() ||
        p.name.length > 80
      )
        throw Error("Nome ou identidade de perfil inválido.");
      ids.add(p.id);
      return { id: p.id, name: p.name, profile: AAVEC.validate(p.profile) };
    });
    out.defaultProfile = ids.has(raw.defaultProfile)
      ? raw.defaultProfile
      : out.profiles[0].id;
    if (raw.settings?.shortcuts) {
      const values = Object.values(raw.settings.shortcuts);
      if (
        values.length === 3 &&
        ["pick", "hide", "compare"].every((key) => Object.keys(raw.settings.shortcuts).includes(key)) &&
        new Set(values).size === 3 &&
        values.every((v) => /^Key[A-Z]$/.test(v))
      )
        out.settings.shortcuts = clone(raw.settings.shortcuts);
    }
    if (raw.settings?.panel && AAVEC.bytes(raw.settings.panel) < 512)
      out.settings.panel = clone(raw.settings.panel);
    if (Array.isArray(raw.presets))
      out.presets = raw.presets.slice(0, 20).map((p) => ({
        name: String(p.name).slice(0, 80),
        style: AAVEC.styles(p.style),
      }));
    out.recent = Array.isArray(raw.recent)
      ? raw.recent.filter((x) => typeof x === "string").slice(-64)
      : [];
    out.backups = Array.isArray(raw.backups)
      ? raw.backups
          .filter(
            (x) => x && typeof x.id === "string" && typeof x.time === "number",
          )
          .slice(-3)
      : [];
    out.conflicts = Number.isSafeInteger(raw.conflicts) ? raw.conflicts : 0;
    if (AAVEC.bytes(out) > 9 * 1024 * 1024)
      throw Error(
        "A biblioteca ultrapassa 9 MB de metadados. Exporte e remova alterações.",
      );
    return out;
  }
  function diff(before, after) {
    const result = [];
    for (const key of ["enabled", "hideLauncher", "hideBetterBlox"])
      if (before[key] !== after[key])
        result.push({
          type: "flag",
          key,
          before: before[key],
          after: after[key],
        });
    const prev = new Map(before.patches.map((p) => [p.id, p])),
      next = new Map(after.patches.map((p) => [p.id, p]));
    for (const [id, p] of prev)
      if (!next.has(id))
        result.push({ type: "patch", id, before: p, after: null });
    for (const [id, p] of next) {
      const old = prev.get(id);
      if (same(old, p)) continue;
      if (!old) {
        result.push({ type: "patch", id, before: null, after: p });
        continue;
      }
      for (const key of ["target", "label", "enabled", "group", "value"]) {
        if (key === "value" && p.kind === "style") {
          for (const prop of new Set([
            ...Object.keys(old.value),
            ...Object.keys(p.value),
          ]))
            if (old.value[prop] !== p.value[prop])
              result.push({
                type: "field",
                id,
                key: "style",
                prop,
                before: old.value[prop],
                after: p.value[prop],
              });
        } else if (!same(old[key], p[key]))
          result.push({
            type: "field",
            id,
            key,
            before: old[key],
            after: p[key],
          });
      }
    }
    return result;
  }
  function apply(profile, ops, conditional = false) {
    const p = clone(profile);
    let conflicts = 0;
    for (const op of ops) {
      const guarded = conditional || op.conditional === true;
      if (op.type === "flag") {
        if (!["enabled", "hideLauncher", "hideBetterBlox"].includes(op.key))
          throw Error("Preferência inválida.");
        if (!same(p[op.key], op.before) && !same(p[op.key], op.after)) {
          conflicts++;
          if (guarded) continue;
        }
        p[op.key] = op.after;
      } else if (op.type === "patch") {
        let at = p.patches.findIndex((x) => x.id === op.id);
        if (at < 0 && op.after)
          at = p.patches.findIndex(
            (x) =>
              x.kind === op.after.kind &&
              x.target.selector === op.after.target.selector &&
              x.target.index === op.after.target.index &&
              (!x.target.stat || !op.after.target.stat || x.target.stat === op.after.target.stat),
          );
        const current = at < 0 ? null : p.patches[at];
        if (!same(current, op.before) && !same(current, op.after)) {
          conflicts++;
          if (guarded) continue;
        }
        if (!op.after) {
          if (at >= 0) p.patches.splice(at, 1);
        } else if (at < 0) p.patches.push(clone(op.after));
        else if (current.kind === "style" && op.before === null) {
          p.patches[at] = {
            ...clone(op.after),
            id: current.id,
            value: { ...current.value, ...op.after.value },
          };
        } else p.patches[at] = { ...clone(op.after), id: current.id };
      } else if (op.type === "field") {
        const item = p.patches.find((x) => x.id === op.id);
        if (!item) {
          conflicts++;
          continue;
        }
        if (
          !["target", "label", "enabled", "group", "value", "style"].includes(
            op.key,
          )
        )
          throw Error("Campo inválido.");
        const current = op.key === "style" ? item.value[op.prop] : item[op.key];
        if (!same(current, op.before) && !same(current, op.after)) {
          conflicts++;
          if (guarded) continue;
        }
        if (op.key === "style") {
          if (op.after === undefined) delete item.value[op.prop];
          else item.value[op.prop] = op.after;
        } else if (op.after === undefined) delete item[op.key];
        else item[op.key] = clone(op.after);
      } else throw Error("Operação inválida.");
    }
    return { profile: AAVEC.validate(p), conflicts };
  }
  const inverse = (ops) =>
    ops
      .slice()
      .reverse()
      .map((op) => ({ ...op, before: op.after, after: op.before }));
  class Assets {
    async open() {
      if (this.db) return this.db;
      this.db = await new Promise((resolve, reject) => {
        const r = indexedDB.open("aa-visual-editor-assets-v2", 2);
        r.onupgradeneeded = () => {
          for (const name of ["assets", "backups", "recovery"])
            if (!r.result.objectStoreNames.contains(name))
              r.result.createObjectStore(name, { keyPath: "id" });
        };
        r.onsuccess = () => resolve(r.result);
        r.onerror = () =>
          reject(Error("Não foi possível abrir as imagens locais."));
      });
      return this.db;
    }
    async run(store, mode, action) {
      const db = await this.open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(store, mode),
          r = action(tx.objectStore(store));
        let result;
        r.onsuccess = () => {
          result = r.result;
        };
        tx.oncomplete = () => resolve(result);
        tx.onerror = () =>
          reject(
            Error("Falha ao gravar imagens ou backup. Confira o espaço livre."),
          );
        tx.onabort = tx.onerror;
      });
    }
    get(id, store = "assets") {
      return this.run(store, "readonly", (s) => s.get(id));
    }
    all(store = "assets") {
      return this.run(store, "readonly", (s) => s.getAll());
    }
    keys(store = "assets") {
      return this.run(store, "readonly", (s) => s.getAllKeys());
    }
    put(x, store = "assets") {
      return this.run(store, "readwrite", (s) => s.put(x));
    }
    delete(id, store = "assets") {
      return this.run(store, "readwrite", (s) => s.delete(id));
    }
  }
  class Backend {
    constructor() {
      this.assets = new Assets();
      this.queue = Promise.resolve();
    }
    request(message, sender) {
      const work = () => this.execute(message, sender);
      const p = this.queue.catch(() => {}).then(work);
      this.queue = p.catch(() => {});
      return p;
    }
    async legacy() {
      const raw = (await chrome.storage.local.get(AAVEC.KEY))[AAVEC.KEY];
      if (raw !== undefined) return raw;
      return (await this.assets.get("legacy-v1", "recovery"))?.raw;
    }
    async load() {
      const raw = (await chrome.storage.local.get(KEY))[KEY];
      if (raw !== undefined) return book(raw);
      const legacy = await this.legacy(),
        b = blank();
      if (legacy !== undefined)
        b.profiles[0].profile = await this.externalize(AAVEC.validate(legacy));
      const checked = book(b),
        quota = chrome.storage.local.QUOTA_BYTES || 10 * 1024 * 1024;
      const localLegacy = (await chrome.storage.local.get(AAVEC.KEY))[
        AAVEC.KEY
      ];
      if (
        localLegacy !== undefined &&
        AAVEC.bytes(localLegacy) + AAVEC.bytes(checked) + 4096 > quota
      ) {
        // A verified extension-origin copy exists before freeing the local key.
        // If the new write fails, the next load resumes from this same copy.
        await this.assets.put(
          { id: "legacy-v1", time: Date.now(), raw: localLegacy },
          "recovery",
        );
        const verified = await this.assets.get("legacy-v1", "recovery");
        if (!same(verified?.raw, localLegacy))
          throw Error(
            "A cópia do perfil anterior não pôde ser verificada. Nada foi removido.",
          );
        await chrome.storage.local.remove(AAVEC.KEY);
      }
      await chrome.storage.local.set({ [KEY]: checked });
      return checked;
    }
    async asset(data, name = "Imagem local") {
      if (
        typeof data !== "string" ||
        !/^data:image\/(png|jpeg|webp|gif);base64,/.test(data) ||
        data.length > 6 * 1024 * 1024
      )
        throw Error("Imagem local inválida ou acima de 4 MB.");
      const raw = Uint8Array.from(atob(data.split(",")[1]), (c) =>
        c.charCodeAt(0),
      );
      if (raw.length > 4 * 1024 * 1024)
        throw Error("A imagem ultrapassa 4 MB.");
      const png =
          raw[0] === 137 && raw[1] === 80 && raw[2] === 78 && raw[3] === 71,
        jpg = raw[0] === 255 && raw[1] === 216 && raw[2] === 255,
        gif = String.fromCharCode(...raw.slice(0, 6)).startsWith("GIF8"),
        webp =
          String.fromCharCode(...raw.slice(0, 4)) === "RIFF" &&
          String.fromCharCode(...raw.slice(8, 12)) === "WEBP";
      if (!png && !jpg && !gif && !webp)
        throw Error(
          "O conteúdo do arquivo não corresponde a uma imagem permitida.",
        );
      if (globalThis.AAVEImages) AAVEImages.dimensions(raw);
      const hash = [
          ...new Uint8Array(await crypto.subtle.digest("SHA-256", raw)),
        ]
          .map((x) => x.toString(16).padStart(2, "0"))
          .join(""),
        id = "aave-asset:" + hash;
      if (await this.assets.get(id)) return id;
      let thumb = "";
      if (typeof createImageBitmap === "function") {
        let bitmap, canvas;
        try {
          bitmap = await createImageBitmap(new Blob([raw]));
          if (typeof OffscreenCanvas === "function") {
            const scale = Math.min(1, 128 / bitmap.width, 128 / bitmap.height);
            canvas = new OffscreenCanvas(
              Math.max(1, Math.round(bitmap.width * scale)),
              Math.max(1, Math.round(bitmap.height * scale)),
            );
            canvas
              .getContext("2d")
              .drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            const blob = await canvas.convertToBlob({
                type: "image/jpeg",
                quality: 0.6,
              }),
              bytes = new Uint8Array(await blob.arrayBuffer());
            if (bytes.length <= 32768)
              thumb =
                "data:image/jpeg;base64," + btoa(String.fromCharCode(...bytes));
          }
        } catch {
          throw Error("O navegador não conseguiu decodificar a imagem local.");
        } finally {
          bitmap?.close();
          if (canvas) canvas.width = canvas.height = 1;
        }
      }

      const entries = await this.assets.all();
      if (entries.length >= 500)
        throw Error(
          "A biblioteca atingiu 500 imagens. Exporte antes de remover arquivos sem uso.",
        );
      const used = entries.reduce((s, a) => s + a.bytes, 0);
      if (used + raw.length > LIMIT)
        throw Error(
          "A biblioteca atingiu 64 MB. Exporte antes de remover imagens sem uso.",
        );
      await this.assets.put({
        id,
        data,
        thumb,
        bytes: raw.length,
        name: String(name).slice(0, 80),
        time: Date.now(),
      });
      return id;
    }
    async externalize(profile) {
      const p = clone(profile);
      for (const patch of p.patches)
        if (patch.kind === "image" && patch.value.startsWith("data:"))
          patch.value = await this.asset(patch.value);
      const refs = p.patches
        .filter((x) => x.kind === "image" && x.value.startsWith("aave-asset:"))
        .map((x) => x.value);
      if (refs.length) {
        const known = new Set(await this.assets.keys());
        if (refs.some((id) => !known.has(id)))
          throw Error(
            "O backup está incompleto: uma imagem local não foi encontrada. Importe o arquivo portátil que inclui suas imagens.",
          );
      }
      return AAVEC.validate(p);
    }
    async backup(b, force = false) {
      for (const old of await this.assets.all("backups"))
        if (!b.backups.some((x) => x.id === old.id))
          await this.assets.delete(old.id, "backups");
      const last = b.backups.at(-1);
      if (!force && last && Date.now() - last.time < 60000) return;
      const id = crypto.randomUUID(),
        time = Date.now(),
        snapshot = { ...clone(b), backups: [], recent: [] };
      await this.assets.put({ id, time, book: snapshot }, "backups");
      b.backups.push({ id, time });
      while (b.backups.length > 3) {
        b.backups.shift();
      }
    }
    async execute(m, sender) {
      if (m?.app !== APP) throw Error("Mensagem desconhecida.");
      if (m.action === "legacyRead") return (await this.legacy()) ?? null;
      if (m.action === "recoverList")
        return (await this.assets.all("backups"))
          .filter((x) => x.book)
          .map((x) => ({ id: x.id, time: x.time }));
      if (m.action === "backupRestore") {
        const snapshot = await this.assets.get(m.id, "backups");
        if (!snapshot?.book) throw Error("Backup não encontrado.");
        const restored = book(snapshot.book),
          old = (await chrome.storage.local.get(KEY))[KEY];
        if (old)
          await this.assets.put(
            { id: "last-before-recovery", time: Date.now(), raw: old },
            "recovery",
          );
        restored.revision =
          Math.max(
            restored.revision,
            Number.isSafeInteger(old?.revision) ? old.revision : 0,
          ) + 1;
        await chrome.storage.local.set({ [KEY]: restored });
        return restored;
      }
      const b = await this.load();
      if (m.action === "load") return b;
      if (m.action === "tabView") {
        const key = "aave-tab-" + sender?.tab?.id;
        return chrome.storage.session
          ? (await chrome.storage.session.get(key))[key] || null
          : null;
      }
      if (m.action === "compare") {
        if (!sender?.tab || !AAVEC.inScope(sender.tab.url))
          throw Error("Abra a página do Anime Adventures.");
        const tab = await chrome.tabs.create({
          url: sender.tab.url,
          active: false,
        });
        await chrome.storage.session.set({
          ["aave-tab-" + tab.id]: { profileId: m.profileId, original: true },
        });
        return { tabId: tab.id };
      }
      if (m.action === "assets") {
        const rows = await this.assets.all();
        return rows.map(({ id, data, name, bytes, time, thumb }) => ({
          id,
          name,
          bytes,
          time,
          thumb,
          ...(m.ids?.includes(id) ? { data } : {}),
        }));
      }
      if (m.action === "assetPut") return this.asset(m.data, m.name);
      if (m.action === "usage") {
        const rows = await this.assets.all();
        return {
          metadata: AAVEC.bytes(b),
          assets: rows.reduce((n, a) => n + a.bytes, 0),
          assetLimit: LIMIT,
          backups: b.backups.length,
          estimate: await navigator.storage?.estimate?.(),
        };
      }
      if (m.action === "assetName") {
        const a = await this.assets.get(m.id);
        if (!a) throw Error("Imagem não encontrada.");
        a.name = String(m.name).slice(0, 80);
        await this.assets.put(a);
        return true;
      }
      if (m.action === "assetLease") {
        if (!chrome.storage.session) return true;
        const key = "aave-assets-" + (sender?.tab?.id || m.client),
          ids = Array.isArray(m.ids)
            ? m.ids
                .filter((x) => /^aave-asset:[a-f0-9]{64}$/.test(x))
                .slice(0, 1000)
            : [];
        await chrome.storage.session.set({ [key]: { ids, time: Date.now() } });
        return true;
      }
      if (m.action === "assetDelete") {
        if (chrome.storage.session) {
          const leases = await chrome.storage.session.get(null);
          if (
            Object.entries(leases).some(
              ([k, v]) =>
                k.startsWith("aave-assets-") &&
                Date.now() - v.time < 3600000 &&
                v.ids?.includes(m.id),
            )
          )
            throw Error(
              "Esta imagem ainda está no histórico de uma aba aberta.",
            );
        }
        let references = JSON.stringify(b.profiles);
        for (const backup of await this.assets.all("backups"))
          references += JSON.stringify(backup.book.profiles);
        for (const recovery of await this.assets.all("recovery"))
          references += JSON.stringify(recovery.raw);
        if (references.includes(m.id))
          throw Error("Esta imagem ainda é usada por um perfil, backup ou cópia de recuperação.");
        await this.assets.delete(m.id);
        return true;
      }
      if (m.action === "backupRead") {
        const backup = await this.assets.get(m.id, "backups");
        if (!backup) throw Error("Backup não encontrado.");
        return book(backup.book);
      }
      if (m.action === "capture") {
        if (!sender?.tab?.id || !AAVEC.inScope(sender.tab.url))
          throw Error("Abra a página do Anime Adventures.");
        const current = async () => {
          const [tab] = await chrome.tabs.query({
            active: true,
            windowId: sender.tab.windowId,
          });
          if (!tab || tab.id !== sender.tab.id || !AAVEC.inScope(tab.url))
            throw Error(
              "A aba ativa mudou. Volte ao Anime Adventures e repita a captura.",
            );
        };
        await current();
        const data = await chrome.tabs.captureVisibleTab(sender.tab.windowId, {
          format: "png",
        });
        await current();
        return data;
      }
      if (m.opId && b.recent.includes(m.opId)) return b;
      if (m.action === "mutate") {
        const p = b.profiles.find((p) => p.id === m.profileId);
        if (!p)
          throw Error(
            "Este perfil foi removido em outra aba. Exporte suas alterações antes de trocar.",
          );
        if (!Array.isArray(m.ops) || m.ops.length > 1200)
          throw Error("Muitas alterações em uma operação.");
        await this.backup(
          b,
          m.ops.some((o) => o.type === "patch" && !o.after),
        );
        const result = apply(p.profile, m.ops, !!m.conditional);
        p.profile = await this.externalize(result.profile);
        b.conflicts += result.conflicts;
      } else if (m.action === "profile") {
        await this.backup(b, true);
        if (m.command === "create" || m.command === "duplicate") {
          if (b.profiles.length >= 20) throw Error("O limite é de 20 perfis.");
          const source = b.profiles.find((p) => p.id === m.source);
          b.profiles.push({
            id: m.id,
            name: String(m.name || "Novo perfil").slice(0, 80),
            profile: source ? clone(source.profile) : AAVEC.fresh(),
          });
        } else {
          const p = b.profiles.find((p) => p.id === m.id);
          if (!p) throw Error("Perfil não encontrado.");
          if (m.command === "rename") p.name = String(m.name).slice(0, 80);
          else if (m.command === "delete") {
            if (b.profiles.length === 1)
              throw Error("Mantenha pelo menos um perfil.");
            b.profiles = b.profiles.filter((p) => p.id !== m.id);
          } else if (m.command === "default") b.defaultProfile = m.id;
          else throw Error("Ação desconhecida.");
        }
      } else if (m.action === "settings") {
        if (m.shortcuts) b.settings.shortcuts = clone(m.shortcuts);
        if (m.panel) b.settings.panel = clone(m.panel);
      } else if (m.action === "preset") {
        b.presets = b.presets.filter((p) => p.name !== m.name);
        if (m.style)
          b.presets.push({
            name: String(m.name).slice(0, 80),
            style: AAVEC.styles(m.style),
          });
      } else if (m.action === "importBook") {
        await this.backup(b, true);
        const next = book(m.book);
        if (!m.merge) {
          b.profiles = [];
          b.defaultProfile = next.defaultProfile;
          b.settings = next.settings;
          b.presets = next.presets;
        }
        for (const p of next.profiles) {
          p.profile = await this.externalize(p.profile);
          const old = b.profiles.find((q) => q.id === p.id);
          if (old) {
            if (m.merge) {
              const result = apply(old.profile, diff(AAVEC.fresh(), p.profile));
              old.profile = result.profile;
              old.name = p.name;
              b.conflicts += result.conflicts;
            } else Object.assign(old, p);
          } else b.profiles.push(p);
        }
      } else throw Error("Ação desconhecida.");
      b.revision++;
      if (m.opId) b.recent.push(m.opId);
      const checked = book(b);
      await chrome.storage.local.set({ [KEY]: checked });
      try {
        for (const backup of await this.assets.all("backups"))
          if (!checked.backups.some((x) => x.id === backup.id))
            await this.assets.delete(backup.id, "backups");
      } catch {}
      return checked;
    }
  }
  async function request(action, values = {}) {
    const response = await chrome.runtime.sendMessage({
      app: APP,
      action,
      ...values,
    });
    if (!response?.ok)
      throw Error(
        response?.error ||
          "O serviço local não respondeu. Recarregue a página.",
      );
    return response.value;
  }
  globalThis.AAVEStore = Object.freeze({
    KEY,
    APP,
    blank,
    book,
    diff,
    apply,
    inverse,
    Backend,
    request,
  });
})();
