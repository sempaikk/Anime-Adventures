"use strict";
importScripts("core.js", "images.js", "storage.js");
const backend = new AAVEStore.Backend();
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || message?.app !== AAVEStore.APP) return;
  backend.request(message, sender).then(
    (value) => respond({ ok: true, value }),
    (error) => respond({ ok: false, error: error.message }),
  );
  return true;
});
