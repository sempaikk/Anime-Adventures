/* Reapply only the chosen local fields; preserve the site's nodes and controls. */
(() => {
  "use strict";
  if (globalThis.AAVEEngine) return;
  const blocked =
    "html,head,body,script,style,noscript,iframe,object,embed,input,textarea,select,option,meta,link";
  const clean = (s) =>
    String(s || "")
      .replace(/\s+/g, " ")
      .trim();
  function editable(el) {
    return (
      el instanceof Element &&
      !el.matches(blocked) &&
      !el.closest("[data-aave-root],script,style,textarea,select")
    );
  }
  function path(el) {
    const parts = [];
    for (
      let at = el;
      at && at !== document.body && parts.length < 24;
      at = at.parentElement
    ) {
      if (at.id) {
        const id = "#" + CSS.escape(at.id);
        if (document.querySelectorAll(id).length === 1) {
          parts.unshift(id);
          break;
        }
      }
      let s = at.localName;
      const testid = at.getAttribute("data-testid");
      if (testid && testid.length < 100) {
        s += `[data-testid=${JSON.stringify(testid)}]`;
        if (document.querySelectorAll(s).length === 1) {
          parts.unshift(s);
          break;
        }
      }
      const peers = at.parentElement
        ? [...at.parentElement.children].filter(
            (x) => x.localName === at.localName,
          )
        : [at];
      parts.unshift(
        s + (peers.length > 1 ? `:nth-of-type(${peers.indexOf(at) + 1})` : ""),
      );
    }
    return parts.join(" > ");
  }
  function anchor(el) {
    const container =
      el.closest(
        "li,article,section,[data-testid],.game-stat,.game-statistic",
      ) || el.parentElement;
    if (!container) return "";
    const labels = container.querySelectorAll(
      "label,dt,th,h1,h2,h3,h4,.text-label,.game-stat-header,[data-label]",
    );
    return clean(
      [...labels]
        .slice(0, 8)
        .map((x) => x.textContent)
        .join(" | "),
    ).slice(0, 160);
  }
  function statName(value) {
    const label = clean(value).replace(/:$/, "").trim().toLowerCase();
    if (/^(active|playing|players|jogadores(?: ativos)?|jogando|ativos)$/.test(label))
      return "active";
    if (/^(visits|visitas)$/.test(label)) return "visits";
    if (/^(server size|tamanho do servidor)$/.test(label)) return "server-size";
    if (/^(favorites|favourites|favorited|favoritos)$/.test(label))
      return "favorites";
    return "";
  }
  function statistic(el, scopes = new WeakMap()) {
    let branch = el;
    for (let depth = 0; branch?.parentElement && depth < 6; depth++) {
      const container = branch.parentElement;
      if (container === document.body) break;
      let labels = scopes.get(container);
      if (!labels) {
        const descendants = container.getElementsByTagName("*");
        if (descendants.length > 160) return "";
        labels = [container, ...descendants]
          .filter((node) => editable(node) && !node.closest("svg,[aria-hidden=true]"))
          .map((node) => ({
            node,
            name: statName(textNodes(node).map((n) => n.nodeValue).join(" ")),
          }))
          .filter((label) => label.name);
        scopes.set(container, labels);
      }
      if (new Set(labels.map((label) => label.name)).size > 1) return "";
      const outside = labels.find((label) => !branch.contains(label.node));
      if (outside) return outside.name;
      branch = container;
    }
    return "";
  }
  function describe(el, node = null, image = "") {
    const stable =
      el.id && document.querySelectorAll("#" + CSS.escape(el.id)).length === 1
        ? "#" + CSS.escape(el.id)
        : ["data-testid", "data-test", "aria-label"]
            .map((k) =>
              el.getAttribute(k)
                ? `${el.localName}[${k}=${JSON.stringify(el.getAttribute(k))}]`
                : "",
            )
            .find((q) => q && document.querySelectorAll(q).length === 1) || "";
    const context = el.parentElement
      ? clean(
          [...el.parentElement.childNodes]
            .filter((n) => n !== el)
            .map((n) => n.textContent)
            .join("|"),
        ).slice(0, 2048)
      : "";
    const stat = statistic(el);
    return {
      stable,
      context,
      textBefore: node
        ? clean(node.previousSibling?.textContent).slice(0, 300)
        : "",
      textAfter: node ? clean(node.nextSibling?.textContent).slice(0, 300) : "",
      selector: path(el),
      tag: el.localName,
      sample: clean(
        node?.nodeValue ?? el.getAttribute("alt") ?? el.textContent,
      ).slice(0, 300),
      anchor: anchor(el),
      index: node ? [...el.childNodes].indexOf(node) : -1,
      attr: image,
      ...(stat ? { stat } : {}),
    };
  }
  function textNodes(el) {
    return [...el.childNodes].filter(
      (n) => n.nodeType === Node.TEXT_NODE && n.nodeValue.trim(),
    );
  }
  function selectAt(event) {
    let el = event.target;
    if (!(el instanceof Element)) return null;
    if (el instanceof SVGElement)
      el = el.closest("button,a,div,span") || el.parentElement;
    if (!editable(el)) return null;
    if (el instanceof HTMLImageElement) return { el, node: null, image: "src" };
    const bg = getComputedStyle(el).backgroundImage;
    if (bg !== "none" && !clean(el.textContent))
      return { el, node: null, image: "background" };
    let node = null;
    const range = document.caretRangeFromPoint?.(event.clientX, event.clientY);
    if (
      range?.startContainer.nodeType === Node.TEXT_NODE &&
      el.contains(range.startContainer) &&
      range.startContainer.nodeValue.trim()
    )
      node = range.startContainer;
    if (!node) node = textNodes(el)[0];
    if (!node) {
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
        acceptNode: (n) =>
          n.nodeValue.trim() &&
          editable(n.parentElement) &&
          !n.parentElement.closest("svg,[aria-hidden=true]")
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_SKIP,
      });
      node = walker.nextNode();
    }
    if (node) return { el: node.parentElement, node, image: "" };
    const image = el.querySelector("img");
    if (image) return { el: image, node: null, image: "src" };
    return { el, node: null, image: bg !== "none" ? "background" : "" };
  }
  class Engine {
    constructor() {
      this.index = null;
      this.tagIndexes = new Map();
      this.statScopes = new WeakMap();
      this.pendingCache = new Map();
      this.bindings = new Map();
      this.footerTargets = new Set();
      this.footerIDs = new WeakMap();
      this.serial = 0;
    }
    invalidate() {
      this.index = null;
      this.tagIndexes = new Map();
      this.statScopes = new WeakMap();
      this.pendingCache.clear();
      this.footerScanned = false;
    }
    candidates(tag) {
      if (!this.index) {
        this.index = new Map();
        const walker = document.createTreeWalker(
          document.body,
          NodeFilter.SHOW_ELEMENT,
        );
        let el,
          count = 0;
        while ((el = walker.nextNode()) && count++ < 20000) {
          if (!editable(el)) continue;
          let list = this.index.get(el.localName);
          if (!list) this.index.set(el.localName, (list = []));
          list.push(el);
        }
      }
      return this.index.get(tag) || [];
    }
    semantic(d) {
      let index = this.tagIndexes.get(d.tag);
      if (!index) {
        index = { sample: new Map(), anchor: new Map() };
        for (const el of this.candidates(d.tag)) {
          const values = [
            clean(el.getAttribute("alt") ?? el.textContent),
            ...textNodes(el).map((n) => clean(n.nodeValue)),
          ];
          for (const value of new Set(values)) {
            if (!index.sample.has(value)) index.sample.set(value, []);
            index.sample.get(value).push(el);
          }
          const label = anchor(el);
          if (label) {
            if (!index.anchor.has(label)) index.anchor.set(label, []);
            index.anchor.get(label).push(el);
          }
        }
        this.tagIndexes.set(d.tag, index);
      }
      if (d.stat) {
        if (!index.stat) {
          index.stat = new Map();
          for (const el of this.candidates(d.tag)) {
            const name = statistic(el, this.statScopes);
            if (!name) continue;
            if (!index.stat.has(name)) index.stat.set(name, []);
            index.stat.get(name).push(el);
          }
        }
        return index.stat.get(d.stat) || [];
      }
      return d.anchor
        ? index.anchor.get(d.anchor) || []
        : index.sample.get(d.sample) || [];
    }
    findStatistic(stat) {
      const matches = ["span", "div", "p", "strong", "b"]
        .flatMap((tag) => this.semantic({ tag, stat }))
        .filter((el) => el.isConnected && textNodes(el).length);
      return matches.length === 1 ? matches[0] : null;
    }
    resolve(d, discover = true) {
      const key = JSON.stringify(d);
      if (this.pendingCache.has(key)) return this.pendingCache.get(key);
      let found = null;
      try {
        if (d.stable) {
          const list = document.querySelectorAll(d.stable);
          if (
            list.length === 1 &&
            editable(list[0]) &&
            list[0].localName === d.tag
          )
            return list[0];
          if (list.length > 1) return null;
        }
      } catch {
        return null;
      }
      if (!discover && !d.stat) return null;
      const matches = this.semantic(d).filter((el) => {
        if (d.stat)
          return (
            statistic(el, this.statScopes) === d.stat &&
            (d.index < 0 || textNodes(el).length > 0)
          );
        const n = d.index >= 0 ? el.childNodes[d.index] : null,
          sample = clean(
            n?.nodeValue ?? el.getAttribute("alt") ?? el.textContent,
          );
        const context = el.parentElement
          ? clean(
              [...el.parentElement.childNodes]
                .filter((n) => n !== el)
                .map((n) => n.textContent)
                .join("|"),
            ).slice(0, 2048)
          : "";
        return (
          (d.anchor
            ? anchor(el) === d.anchor
            : !!d.sample && sample === d.sample) &&
          (!d.context || context === d.context)
        );
      });
      if (matches.length === 1) found = matches[0];
      // Positional paths alone are never proof of identity. Ambiguous edits wait.
      this.pendingCache.set(key, found);
      return found;
    }
    write(fn) {
      const records = this.observer?.takeRecords();
      if (records?.length) this.external(records);
      fn();
      this.observer?.takeRecords();
    }
    external(records) {
      let structure = false;
      for (const r of records) {
        if (r.target.nodeType === 1 && r.target.closest?.("[data-aave-root]"))
          continue;
        if (
          r.type === "childList" ||
          ["id", "class", "data-testid", "aria-label"].includes(r.attributeName)
        )
          structure = true;
        if (r.type === "characterData") {
          if (statName(r.oldValue) || statName(r.target.nodeValue))
            structure = true;
          let el = r.target.parentElement;
          for (let i = 0; el && i < 4; i++, el = el.parentElement)
            this.tagIndexes.delete(el.localName);
          this.pendingCache.clear();
        }
        for (const b of this.bindings.values())
          for (const f of b.fields.values()) {
            if (r.type === "characterData" && f.node === r.target)
              f.original = f.get();
            if (
              r.type === "attributes" &&
              f.node === r.target &&
              f.attr === r.attributeName
            ) {
              if (f.css) {
                const old = document.createElement("span");
                old.style.cssText = r.oldValue || "";
                if (
                  old.style.getPropertyValue(f.css) !==
                  r.target.style.getPropertyValue(f.css)
                )
                  f.original = f.get();
              } else f.original = f.get();
            }
          }
      }
      if (structure) this.invalidate();
    }
    field(b, key, get, set, value, metadata = {}) {
      const current = get();
      let f = b.fields.get(key);
      if (!f) {
        f = {
          original: current,
          applied: undefined,
          desired: undefined,
          get,
          set,
          ...metadata,
        };
        b.fields.set(key, f);
      } else {
        if (
          (metadata.node && f.node !== metadata.node) ||
          current !== f.applied
        )
          f.original = current; // A fresh Roblox value became the new original.
        f.get = get;
        f.set = set;
        Object.assign(f, metadata);
      }
      if (f.desired !== value || current !== f.applied) {
        if (current !== value) this.write(() => set(value));
        f.desired = value;
        // CSSOM canonicalizes e.g. hex colors to rgb(). Compare against the
        // actual applied value, avoiding observer loops and lost originals.
        f.applied = get();
      }
    }
    style(b, el, name, value) {
      this.field(
        b,
        "style:" + name,
        () =>
          JSON.stringify([
            el.style.getPropertyValue(name),
            el.style.getPropertyPriority(name),
          ]),
        (raw) => {
          const [v, priority] = JSON.parse(raw);
          v
            ? el.style.setProperty(name, v, priority)
            : el.style.removeProperty(name);
        },
        JSON.stringify([value, "important"]),
        { node: el, attr: "style", css: name },
      );
    }
    attr(b, el, name, value, prefix = "") {
      this.field(
        b,
        prefix + name,
        () => el.getAttribute(name),
        (v) =>
          v === null ? el.removeAttribute(name) : el.setAttribute(name, v),
        value,
        { node: el, attr: name },
      );
    }
    restore(b) {
      for (const f of [...b.fields.values()].reverse())
        if (f.get() === f.applied) this.write(() => f.set(f.original));
      b.fields.clear();
    }
    clear() {
      for (const b of this.bindings.values()) this.restore(b);
      this.bindings.clear();
    }
    rebase(profile) {
      const wanted = new Map(profile.patches.map((p) => [p.id, p])),
        held = [...this.bindings].filter(
          ([id, b]) =>
            b.el.isConnected &&
            wanted.has(id) &&
            JSON.stringify(b.target) === JSON.stringify(wanted.get(id).target),
        );
      this.clear();
      for (const [id, b] of held) this.bindings.set(id, b);
    }
    bind(key, el) {
      let b = this.bindings.get(key);
      if (b && b.el !== el) {
        this.restore(b);
        this.bindings.delete(key);
        b = null;
      }
      if (!b) {
        b = { el, fields: new Map() };
        this.bindings.set(key, b);
      }
      return b;
    }
    findFooters() {
      for (const el of this.footerTargets)
        if (!el.isConnected) this.footerTargets.delete(el);
      if (this.footerScanned) return this.footerTargets;
      this.footerScanned = true;
      const brandNodes = document.querySelectorAll(
        'a,button,[data-testid*="betterblox" i],img[alt*="betterblox" i]',
      );
      for (const node of [...brandNodes].slice(0, 1600)) {
        const title = clean(node.textContent || node.getAttribute("alt"));
        const href = node.getAttribute("href") || "";
        if (
          !/^better\s*blox$/i.test(title) &&
          !/lplhnhhlblehjmmkcpjbojiaanbpgnpd/i.test(href)
        )
          continue;
        let best = null;
        for (let el = node; el && editable(el); el = el.parentElement) {
          const rect = el.getBoundingClientRect(),
            text = clean(el.textContent);
          if (
            rect.width > 430 ||
            rect.height > 250 ||
            text.length > 900 ||
            el.matches("nav,aside")
          )
            break;
          if (
            rect.width > 0 &&
            rect.left < 340 &&
            rect.top > innerHeight * 0.4 &&
            /better\s*blox/i.test(text) &&
            (/\bv\d+\.\d+/i.test(text) ||
              /send feedback|enviar feedback/i.test(text)) &&
            el.querySelectorAll("a").length <= 12
          )
            best = el;
        }
        if (best) this.footerTargets.add(best);
      }
      return this.footerTargets;
    }
    apply(profile, assets = new Map(), discover = true) {
      if (!profile.enabled || !AAVEC.inScope(location.href)) {
        this.clear();
        return {
          matched: 0,
          total: profile.patches.filter((p) => p.enabled !== false).length,
          footer: 0,
        };
      }
      const keep = new Set();
      let matched = 0;
      for (const p of profile.patches) {
        if (p.enabled === false) continue;
        const previous = this.bindings.get(p.id);
        const el = previous?.el.isConnected
          ? previous.el
          : this.resolve(p.target, discover);
        if (!el) continue;
        let node = null;
        if (p.kind === "text") {
          if (previous?.node?.isConnected && previous.node.parentElement === el)
            node = previous.node;
          else {
            const nodes = textNodes(el);
            if (nodes.length === 1) node = nodes[0];
            else {
              const matches = nodes.filter(
                (n) =>
                  clean(n.nodeValue) === p.target.sample &&
                  (!p.target.textBefore ||
                    clean(n.previousSibling?.textContent) ===
                      p.target.textBefore) &&
                  (!p.target.textAfter ||
                    clean(n.nextSibling?.textContent) === p.target.textAfter),
              );
              if (matches.length === 1) node = matches[0];
            }
          }
        }
        if (p.kind === "text" && (!node || node.nodeType !== Node.TEXT_NODE))
          continue;
        keep.add(p.id);
        matched++;
        const b = this.bind(p.id, el);
        b.target = p.target;
        if (p.kind === "text") {
          if (b.node && b.node !== node) this.restore(b);
          b.node = node;
          this.field(
            b,
            "text",
            () => node.nodeValue,
            (v) => {
              node.nodeValue = v;
            },
            p.value,
            { node, attr: "text" },
          );
        } else if (p.kind === "hide") this.style(b, el, "display", "none");
        else if (p.kind === "style")
          for (const [key, value] of Object.entries(p.value))
            this.style(b, el, key, value);
        else if (p.kind === "image") {
          const image = assets.get(p.value) || p.value;
          if (image.startsWith("aave-asset:")) continue;
          if (el instanceof HTMLImageElement && p.target.attr === "src") {
            this.attr(b, el, "srcset", null);
            this.attr(b, el, "sizes", null);
            this.attr(b, el, "referrerpolicy", "no-referrer");
            const sources =
              el.parentElement?.localName === "picture"
                ? el.parentElement.querySelectorAll("source")
                : [];
            [...sources].forEach((s, i) =>
              this.attr(b, s, "srcset", null, "picture:" + i + ":"),
            );
            this.attr(b, el, "src", image);
          } else if (p.target.attr === "background")
            this.style(
              b,
              el,
              "background-image",
              `url(${JSON.stringify(image)})`,
            );
        }
      }
      let footer = 0;
      if (profile.hideBetterBlox)
        for (const el of this.findFooters()) {
          let key = this.footerIDs.get(el);
          if (!key) {
            key = "footer:" + ++this.serial;
            this.footerIDs.set(el, key);
          }
          keep.add(key);
          this.style(this.bind(key, el), el, "display", "none");
          footer++;
        }
      for (const [key, binding] of this.bindings)
        if (!keep.has(key)) {
          this.restore(binding);
          this.bindings.delete(key);
        }
      return {
        matched,
        total: profile.patches.filter((p) => p.enabled !== false).length,
        footer,
      };
    }
    originalStyle(el, key) {
      const field = [...this.bindings.values()]
        .filter((b) => b.el === el)
        .map((b) => b.fields.get("style:" + key))
        .find(Boolean);
      if (!field) return getComputedStyle(el).getPropertyValue(key);
      this.write(() => field.set(field.original));
      const value = getComputedStyle(el).getPropertyValue(key);
      this.write(() => field.set(field.applied));
      return value;
    }
    removeBindings() {
      this.clear();
      this.footerTargets.clear();
      this.invalidate();
    }
  }
  globalThis.AAVEEngine = Object.freeze({
    Engine,
    editable,
    describe,
    selectAt,
    clean,
    path,
    textNodes,
  });
})();
