/* Bounded local image decoding; never reads cookies or a Roblox API. */
(() => {
  "use strict";
  if (globalThis.AAVEImages) return;
  const MAX = 4 * 1024 * 1024,
    PIXELS = 16000000;
  function dimensions(raw) {
    const v = new DataView(raw.buffer, raw.byteOffset, raw.byteLength),
      ascii = (start, len) =>
        String.fromCharCode(...raw.slice(start, start + len));
    let width = 0,
      height = 0;
    if (raw.length >= 24 && raw[0] === 137 && ascii(1, 3) === "PNG") {
      width = v.getUint32(16);
      height = v.getUint32(20);
    } else if (raw.length >= 10 && ascii(0, 4) === "GIF8") {
      width = v.getUint16(6, true);
      height = v.getUint16(8, true);
    } else if (
      raw.length >= 30 &&
      ascii(0, 4) === "RIFF" &&
      ascii(8, 4) === "WEBP"
    ) {
      const type = ascii(12, 4);
      if (type === "VP8X") {
        width = 1 + (raw[24] | (raw[25] << 8) | (raw[26] << 16));
        height = 1 + (raw[27] | (raw[28] << 8) | (raw[29] << 16));
      } else if (type === "VP8 ") {
        width = v.getUint16(26, true) & 16383;
        height = v.getUint16(28, true) & 16383;
      } else if (type === "VP8L" && raw[20] === 47) {
        const bits = v.getUint32(21, true);
        width = (bits & 16383) + 1;
        height = ((bits >>> 14) & 16383) + 1;
      }
    } else if (raw.length >= 10 && raw[0] === 255 && raw[1] === 216) {
      let at = 2;
      while (at + 4 < raw.length) {
        if (raw[at++] !== 255) break;
        while (raw[at] === 255) at++;
        const marker = raw[at++];
        if (marker === 217 || marker === 218) break;
        if (marker === 1 || (marker >= 208 && marker <= 215)) continue;
        const size = v.getUint16(at);
        if (size < 2 || at + size > raw.length) break;
        if (
          [
            192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207,
          ].includes(marker)
        ) {
          if (size < 8) break;
          height = v.getUint16(at + 3);
          width = v.getUint16(at + 5);
          break;
        }
        at += size;
      }
    }
    if (
      !width ||
      !height ||
      width > 16384 ||
      height > 16384 ||
      width * height > PIXELS
    )
      throw Error(
        "Imagem inválida ou acima de 16 milhões de pixels. Reduza a resolução antes de importar.",
      );
    return { width, height };
  }
  async function decode(url, { maxBytes = MAX, cors = false } = {}) {
    if (url.startsWith("data:")) {
      if (url.length > (maxBytes * 4) / 3 + 128)
        throw Error("A imagem ultrapassa 4 MB.");
      let raw;
      try {
        raw = Uint8Array.from(atob(url.split(",")[1]), (c) => c.charCodeAt(0));
      } catch {
        throw Error("Imagem codificada inválida.");
      }
      dimensions(raw);
    }
    return new Promise((resolve, reject) => {
      const im = new Image();
      im.referrerPolicy = "no-referrer";
      if (cors && !url.startsWith("data:")) im.crossOrigin = "anonymous";
      const timer = setTimeout(() => {
        im.src = "";
        reject(Error("A imagem demorou demais para carregar."));
      }, 12000);
      im.onload = () => {
        clearTimeout(timer);
        if (!im.naturalWidth || im.naturalWidth * im.naturalHeight > PIXELS) {
          reject(Error("Use uma imagem com até 16 milhões de pixels."));
          return;
        }
        resolve(im);
      };
      im.onerror = () => {
        clearTimeout(timer);
        reject(
          Error(
            "O link ou arquivo não contém uma imagem que o navegador consiga abrir.",
          ),
        );
      };
      im.src = url;
    });
  }
  async function file(file) {
    if (!file || file.size > MAX)
      throw Error("Escolha uma imagem de até 4 MB.");
    const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
    let mime;
    if (head[0] === 137 && head[1] === 80 && head[2] === 78 && head[3] === 71)
      mime = "image/png";
    else if (head[0] === 255 && head[1] === 216 && head[2] === 255)
      mime = "image/jpeg";
    else if (String.fromCharCode(...head.slice(0, 6)).startsWith("GIF8"))
      mime = "image/gif";
    else if (
      String.fromCharCode(...head.slice(0, 4)) === "RIFF" &&
      String.fromCharCode(...head.slice(8, 12)) === "WEBP"
    )
      mime = "image/webp";
    else
      throw Error(
        "O conteúdo deve ser PNG, JPG, WebP ou GIF. Renomear outro arquivo não o transforma em imagem.",
      );
    const buffer = await file.arrayBuffer();
    dimensions(new Uint8Array(buffer));
    const data =
      "data:" +
      mime +
      ";base64," +
      (await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result.split(",")[1]);
        r.onerror = () => reject(Error("Falha ao ler a imagem."));
        r.readAsDataURL(new Blob([buffer]));
      }));
    const image = await decode(data);
    return {
      data,
      name: file.name || "Imagem local",
      width: image.naturalWidth,
      height: image.naturalHeight,
      mime,
    };
  }
  async function transform(
    data,
    {
      width,
      height,
      quality = 0.9,
      crop = false,
      x = 50,
      y = 50,
      format = "image/png",
    } = {},
  ) {
    const im = await decode(data, { cors: true });
    width = Math.round(Number(width) || im.naturalWidth);
    height = Math.round(Number(height) || im.naturalHeight);
    if (
      width < 1 ||
      height < 1 ||
      width > 8192 ||
      height > 8192 ||
      width * height > PIXELS
    )
      throw Error("Dimensões fora do limite de 16 milhões de pixels.");
    if (!["image/png", "image/jpeg", "image/webp"].includes(format))
      throw Error("Formato inválido.");
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (crop) {
      const scale = Math.max(
          width / im.naturalWidth,
          height / im.naturalHeight,
        ),
        sw = width / scale,
        sh = height / scale,
        sx = (im.naturalWidth - sw) * Math.min(1, Math.max(0, Number(x) / 100)),
        sy =
          (im.naturalHeight - sh) * Math.min(1, Math.max(0, Number(y) / 100));
      ctx.drawImage(im, sx, sy, sw, sh, 0, 0, width, height);
    } else ctx.drawImage(im, 0, 0, width, height);
    try {
      const out = canvas.toDataURL(
        format,
        Math.max(0.1, Math.min(1, Number(quality) || 0.9)),
      );
      if (out.length > (MAX * 4) / 3 + 128)
        throw Error(
          "O resultado ultrapassa 4 MB. Reduza a resolução ou qualidade.",
        );
      return out;
    } catch (error) {
      if (error.name === "SecurityError")
        throw Error(
          "O servidor desta imagem não permite editar seus pixels. Escolha um arquivo local.",
        );
      throw error;
    } finally {
      canvas.width = canvas.height = 1;
    }
  }
  globalThis.AAVEImages = Object.freeze({
    decode,
    file,
    transform,
    dimensions,
    PIXELS,
  });
})();
