"""Stage the signed update feed. Never publish the private signing key."""
import argparse,base64,hashlib,json,shutil,zipfile
from pathlib import Path
from cryptography.hazmat.primitives.serialization import load_pem_private_key,Encoding,PublicFormat

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--extension-project',type=Path,default=ROOT.parent/'aa-visual-editor')
parser.add_argument('--distribution',type=Path,default=ROOT.parent/'aa-visual-editor-distribution')
args=parser.parse_args()
meta=json.loads((args.extension_project/'delivery.json').read_text())
archive=Path(meta['zip']);raw=archive.read_bytes()
assert len(raw)==meta['zip_bytes'] and hashlib.sha256(raw).hexdigest()==meta['zip_sha256']
assert len(raw)<=8*1024*1024
files={}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())<=256
 for name in z.namelist():
  assert name.startswith('AA-Visual-Editor/') and '..' not in Path(name).parts
  relative=name.removeprefix('AA-Visual-Editor/')
  assert relative and not any(x in relative.lower() for x in ('.pem','.env','.signing','state/','token','secret'))
  files[relative]=hashlib.sha256(z.read(name)).hexdigest()
 manifest=json.loads(z.read('AA-Visual-Editor/manifest.json'))
 assert manifest['name']=='AA Visual Editor' and manifest['version']==meta['version']
 assert set(manifest['permissions'])=={'storage','activeTab','scripting'}
 assert not manifest.get('host_permissions') and not manifest.get('key')
 for name,digest in meta['source_files_sha256'].items():assert files[name]==digest
payload={'schema':1,'app':'aa-visual-editor','version':meta['version'],'url':'https://raw.githubusercontent.com/sempaikk/Anime-Adventures/refs/heads/aa-visual-editor-downloads/'+archive.name,'size':len(raw),'sha256':meta['zip_sha256'],'files':files}
keyfile=ROOT/'.signing/release-key.pem'
if not keyfile.exists():raise SystemExit('A chave privada de publicação não está disponível. Não gere outra chave para um atualizador já instalado.')
key=load_pem_private_key(keyfile.read_bytes(),password=None)
public=key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()
assert public in (ROOT/'release_key.go').read_text(), 'A chave de publicação não corresponde ao aplicativo.'
feed=args.distribution/'aa-editor-stable.json'
if feed.exists():
 old=json.loads(feed.read_text());old_raw=base64.b64decode(old['payload']);key.public_key().verify(base64.b64decode(old['signature']),old_raw);old_payload=json.loads(old_raw)
 parse=lambda s:tuple([int(x) for x in s.split('.')]+[0]*(4-len(s.split('.'))))
 assert parse(payload['version'])>=parse(old_payload['version']), 'Publicação recusada: downgrade.'
 if payload['version']==old_payload['version']:assert payload==old_payload, 'Uma versão publicada é imutável. Incremente a versão antes de alterar o ZIP.'
encoded=json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
envelope={'payload':base64.b64encode(encoded).decode(),'signature':base64.b64encode(key.sign(encoded)).decode()}
args.distribution.mkdir(exist_ok=True,parents=True)
destination=args.distribution/archive.name
if destination.exists():assert destination.read_bytes()==raw, 'O ZIP desta versão já existe com conteúdo diferente.'
else:shutil.copy2(archive,destination)
feed.write_text(json.dumps(envelope,indent=2)+'\n')
(args.distribution/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(args.distribution.glob('*.zip'))))
print(json.dumps({'staged':True,'extension_version':meta['version'],'zip_sha256':meta['zip_sha256'],'files':len(files),'feed':str(feed),'private_key_published':False},indent=2))
