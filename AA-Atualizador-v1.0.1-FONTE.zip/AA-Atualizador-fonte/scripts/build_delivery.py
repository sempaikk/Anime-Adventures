"""Build and inspect the Windows GUI app, then stage public-only delivery files."""
import argparse,hashlib,json,os,re,struct,subprocess,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT.parent
parser=argparse.ArgumentParser();parser.add_argument('--go',default='go');args=parser.parse_args()
compiler=subprocess.check_output([args.go,'version'],text=True).strip()
assert compiler.startswith('go version go'), 'Use o compilador da linguagem Go.'
env={**os.environ,'GOOS':'windows','GOARCH':'amd64','CGO_ENABLED':'0','GOTOOLCHAIN':'local'}
exe=OUT/'AA-Atualizador.exe'
command=[args.go,'build','-buildvcs=false','-trimpath','-ldflags=-s -w -H=windowsgui','-o',str(exe),'.']
subprocess.run(command,cwd=ROOT,env=env,check=True)
binary=exe.read_bytes();assert binary.startswith(b'MZ')
pe=struct.unpack_from('<I',binary,0x3c)[0]
assert binary[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',binary,pe+4)[0]==0x8664
assert struct.unpack_from('<H',binary,pe+24)[0]==0x20b
assert struct.unpack_from('<H',binary,pe+24+68)[0]==2, 'O aplicativo deve usar o subsistema GUI.'
assert b'requestedExecutionLevel level="asInvoker"' in binary
assert b'BEGIN PRIVATE KEY' not in binary and b'BEGIN OPENSSH PRIVATE KEY' not in binary
version=re.search(r'updaterVersion\s*=\s*"([^"]+)"',(ROOT/'release.go').read_text()).group(1)
display_version=re.search(r'displayVersion\s*=\s*"([^"]+)"',(ROOT/'release.go').read_text()).group(1)
guide=(ROOT/'COMECE-AQUI.txt').read_text().encode('utf-8-sig')
client_files={'AA-Atualizador.exe':binary,'COMECE-AQUI.txt':guide}
client_files['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(client_files.items())).encode()
client_zip=OUT/f'AA-Atualizador-v{version}-Windows-x64.zip'
def archive(destination,files,prefix):
 with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in sorted(files.items()):
   info=zipfile.ZipInfo(prefix+name,(2026,11,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compresslevel=9)
archive(client_zip,client_files,'AA-Atualizador/')
source_files={}
for name in ['go.mod','.gitignore','README.md','MAINTAINERS.md','COMECE-AQUI.txt','AA-Atualizador.ico','AA-Atualizador.manifest','winres.json','resource_windows_amd64.syso']:
 source_files[name]=(ROOT/name).read_bytes()
for p in sorted(ROOT.glob('*.go')):source_files[p.name]=p.read_bytes()
for p in sorted((ROOT/'scripts').glob('*.py')):source_files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
for name,data in source_files.items():
 assert '.signing' not in name and not name.endswith('.pem')
 assert not re.search(rb'(?m)^-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----\r?$',data)
source_zip=OUT/f'AA-Atualizador-v{version}-FONTE.zip';archive(source_zip,source_files,'AA-Atualizador-fonte/')
result={'updater_version':version,'display_version':display_version,'compiler':compiler,'exe':str(exe),'exe_bytes':len(binary),'exe_sha256':hashlib.sha256(binary).hexdigest(),'client_zip':str(client_zip),'client_zip_bytes':client_zip.stat().st_size,'client_zip_sha256':hashlib.sha256(client_zip.read_bytes()).hexdigest(),'source_zip':str(source_zip),'source_zip_sha256':hashlib.sha256(source_zip.read_bytes()).hexdigest(),'gui_subsystem':True,'x64':True,'requested_execution_level':'asInvoker','authenticode_signed':False,'windows_gui_executed':False,'private_key_distributed':False}
(ROOT/'delivery.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
