module aave-updater

go 1.24.0
