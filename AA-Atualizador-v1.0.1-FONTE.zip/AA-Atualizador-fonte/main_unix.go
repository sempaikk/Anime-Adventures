//go:build !windows

package main

import "fmt"

func main() { fmt.Println("AA Visual Editor: execute o aplicativo Windows fornecido no pacote.") }
