package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const ioModeType = os.ModeType

var errBusy = errors.New("uma verificação já está em andamento; aguarde alguns segundos")

type Config struct {
	Schema    int    `json:"schema"`
	Target    string `json:"target"`
	Automatic bool   `json:"automatic"`
}
type Result struct {
	Version        string `json:"version"`
	DisplayVersion string `json:"display_version,omitempty"`
	Updated        bool   `json:"updated"`
	Message        string `json:"message"`
	Checked        string `json:"checked"`
}
type Manager struct {
	Root, Target string
	Key          ed25519.PublicKey
	fetch        func(context.Context, string, int64) ([]byte, error)
	write        func(string, []byte) error
}
type Record struct {
	Path    string `json:"path"`
	Existed bool   `json:"existed"`
	Old     string `json:"old_sha256"`
	New     string `json:"new_sha256"`
}
type Journal struct {
	Schema int      `json:"schema"`
	Target string   `json:"target"`
	Backup string   `json:"backup"`
	Files  []Record `json:"files"`
}

func newManager(root, target string) *Manager {
	key, _ := hex.DecodeString(releasePublicKeyHex)
	return &Manager{Root: root, Target: target, Key: ed25519.PublicKey(key), fetch: networkFetch, write: writeAtomic}
}
func readSmall(name string, limit int64) ([]byte, error) {
	info, e := os.Lstat(name)
	if e != nil {
		return nil, e
	}
	if !info.Mode().IsRegular() || info.Size() > limit {
		return nil, errors.New("arquivo inesperado ou grande demais")
	}
	return os.ReadFile(name)
}
func targetManifest(target string) (Manifest, error) {
	if !filepath.IsAbs(target) {
		return Manifest{}, errors.New("escolha uma pasta existente da extensão")
	}
	info, e := os.Stat(target)
	if e != nil || !info.IsDir() {
		return Manifest{}, errors.New("a pasta da extensão não está disponível; nenhum arquivo foi alterado")
	}
	name, e := safeDestination(target, "manifest.json", false)
	if e != nil {
		return Manifest{}, e
	}
	b, e := readSmall(name, 128<<10)
	if e != nil {
		return Manifest{}, errors.New("essa pasta não contém manifest.json; escolha a pasta AA-Visual-Editor já instalada")
	}
	return validateManifest(b)
}
func safeDestination(root, relative string, create bool) (string, error) {
	if !validPath(relative) {
		return "", errors.New("caminho de arquivo inválido")
	}
	segments := strings.Split(relative, "/")
	at := root
	for i, s := range segments {
		at = filepath.Join(at, s)
		info, e := os.Lstat(at)
		if errors.Is(e, fs.ErrNotExist) {
			if create && i < len(segments)-1 {
				if e = os.Mkdir(at, 0700); e != nil {
					return "", e
				}
			}
			continue
		}
		if e != nil {
			return "", e
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return "", errors.New("o destino contém um link; atualização interrompida")
		}
		if i < len(segments)-1 && !info.IsDir() {
			return "", errors.New("uma pasta do pacote foi substituída por arquivo")
		}
		if i == len(segments)-1 && !info.Mode().IsRegular() {
			return "", errors.New("o destino não é um arquivo comum")
		}
	}
	return at, nil
}
func writeAtomic(name string, b []byte) error {
	temp, e := os.CreateTemp(filepath.Dir(name), ".aa-update-*")
	if e != nil {
		return e
	}
	defer os.Remove(temp.Name())
	if _, e = temp.Write(b); e != nil {
		temp.Close()
		return e
	}
	if e = temp.Sync(); e != nil {
		temp.Close()
		return e
	}
	if e = temp.Close(); e != nil {
		return e
	}
	return replaceFile(temp.Name(), name)
}
func saveJSON(name string, value any) error {
	b, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return e
	}
	return writeAtomic(name, append(b, '\n'))
}
func loadConfig(root string) (Config, error) {
	var c Config
	b, e := readSmall(filepath.Join(root, "config.json"), 16384)
	if e != nil {
		return c, e
	}
	if strictJSON(b, &c) != nil || c.Schema != 1 || !filepath.IsAbs(c.Target) {
		return c, errors.New("configuração inválida; selecione novamente a pasta atual da extensão")
	}
	return c, nil
}
func orderedNames(files map[string][]byte) []string {
	names := make([]string, 0, len(files))
	for name := range files {
		if name != "manifest.json" {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	if _, ok := files["manifest.json"]; ok {
		names = append(names, "manifest.json")
	}
	return names
}
func (m *Manager) Check(ctx context.Context) (result Result, err error) {
	if e := os.MkdirAll(m.Root, 0700); e != nil {
		return result, e
	}
	unlock, e := lockFile(filepath.Join(m.Root, "update.lock"))
	if e != nil {
		return result, e
	}
	defer unlock()
	if e = m.recover(); e != nil {
		return result, e
	}
	current, e := targetManifest(m.Target)
	if e != nil {
		return result, e
	}
	result.Version = current.Version
	result.DisplayVersion = manifestLabel(current)
	result.Checked = time.Now().UTC().Format(time.RFC3339)
	defer func() {
		state := result
		if err != nil {
			state.Message = err.Error()
		}
		_ = saveJSON(filepath.Join(m.Root, "last-status.json"), state)
	}()
	envelope, e := m.fetch(ctx, feedURL, 128<<10)
	if e != nil {
		return result, e
	}
	release, e := verifyRelease(envelope, m.Key)
	if e != nil {
		return result, e
	}
	comparison, e := compareVersion(release.Version, current.Version)
	if e != nil {
		return result, e
	}
	if comparison <= 0 {
		result.Message = productName + " " + result.DisplayVersion + ": a extensão já está atualizada."
		return result, nil
	}
	raw, e := m.fetch(ctx, release.URL, maxArchive)
	if e != nil {
		return result, e
	}
	files, e := unpack(release, raw)
	if e != nil {
		return result, e
	}
	next, e := validateManifest(files["manifest.json"])
	if e != nil {
		return result, e
	}
	if next.Key != current.Key {
		return result, errors.New("a versão mudaria a identidade da extensão; atualização interrompida para preservar seus dados")
	}
	if e = ctx.Err(); e != nil {
		return result, e
	}
	// Revalidate after downloading: do not overwrite a directory changed meanwhile.
	now, e := targetManifest(m.Target)
	if e != nil {
		return result, e
	}
	if now.Version != current.Version || now.Key != current.Key {
		return result, errors.New("a pasta mudou durante o download; repita a verificação")
	}
	if e = m.apply(files); e != nil {
		return result, e
	}
	result.Version = release.Version
	result.DisplayVersion = manifestLabel(next)
	result.Updated = true
	result.Message = productName + " " + result.DisplayVersion + ": arquivos atualizados. No Chrome, clique em Recarregar na extensão e dê F5 no site."
	return result, nil
}
func (m *Manager) apply(files map[string][]byte) error {
	token := make([]byte, 6)
	if _, e := rand.Read(token); e != nil {
		return e
	}
	id := time.Now().UTC().Format("20060102T150405Z") + "-" + hex.EncodeToString(token)
	backup := filepath.Join(m.Root, "backups", id)
	if e := os.MkdirAll(backup, 0700); e != nil {
		return e
	}
	journal := Journal{Schema: 1, Target: m.Target, Backup: id}
	for _, name := range orderedNames(files) {
		destination, e := safeDestination(m.Target, name, false)
		if e != nil {
			return e
		}
		record := Record{Path: name, New: digest(files[name])}
		old, e := readSmall(destination, maxFile)
		if e == nil {
			record.Existed = true
			record.Old = digest(old)
			saved, e := safeDestination(backup, name, true)
			if e != nil {
				return e
			}
			if e = writeAtomic(saved, old); e != nil {
				return fmt.Errorf("não foi possível guardar a cópia anterior: %w", e)
			}
		} else if !errors.Is(e, fs.ErrNotExist) {
			return e
		}
		journal.Files = append(journal.Files, record)
	}
	if e := saveJSON(filepath.Join(backup, "journal.json"), journal); e != nil {
		return e
	}
	if e := saveJSON(filepath.Join(m.Root, "pending.json"), journal); e != nil {
		return e
	}
	for _, name := range orderedNames(files) {
		destination, e := safeDestination(m.Target, name, true)
		if e == nil {
			e = m.write(destination, files[name])
		}
		if e != nil {
			restore := m.rollback(journal)
			if restore != nil {
				return fmt.Errorf("atualização interrompida; a cópia do código anterior está guardada em %s. Recuperação: %v", backup, restore)
			}
			return fmt.Errorf("não foi possível substituir os arquivos; a versão anterior foi restaurada: %w", e)
		}
	}
	if e := os.Remove(filepath.Join(m.Root, "pending.json")); e != nil {
		return e
	}
	m.pruneBackups()
	return nil
}
func (m *Manager) readJournal() (Journal, error) {
	var j Journal
	b, e := readSmall(filepath.Join(m.Root, "pending.json"), 128<<10)
	if e != nil {
		return j, e
	}
	if strictJSON(b, &j) != nil || j.Schema != 1 || j.Target != m.Target || len(j.Files) < 1 || len(j.Files) > maxFiles || len(j.Backup) != 29 {
		return j, errors.New("recuperação pendente inválida; arquivos atuais preservados")
	}
	for _, r := range j.Backup {
		if !(r >= '0' && r <= '9' || r >= 'a' && r <= 'f' || r == 'T' || r == 'Z' || r == '-') {
			return j, errors.New("pasta de recuperação inválida")
		}
	}
	seen := map[string]bool{}
	for _, r := range j.Files {
		if !validPath(r.Path) || !validHash(r.New) || r.Existed && !validHash(r.Old) || seen[strings.ToLower(r.Path)] {
			return j, errors.New("lista de recuperação inválida")
		}
		seen[strings.ToLower(r.Path)] = true
	}
	return j, nil
}
func (m *Manager) recover() error {
	journal, e := m.readJournal()
	if errors.Is(e, fs.ErrNotExist) {
		return nil
	}
	if e != nil {
		return e
	}
	complete := true
	for _, r := range journal.Files {
		file, e := safeDestination(m.Target, r.Path, false)
		if e != nil {
			return e
		}
		b, e := readSmall(file, maxFile)
		if e != nil || digest(b) != r.New {
			complete = false
			break
		}
	}
	if complete {
		return os.Remove(filepath.Join(m.Root, "pending.json"))
	}
	return m.rollback(journal)
}
func (m *Manager) rollback(j Journal) error {
	// Preflight every file before restoring anything. Unknown user changes survive.
	for _, r := range j.Files {
		destination, e := safeDestination(m.Target, r.Path, false)
		if e != nil {
			return e
		}
		current, e := readSmall(destination, maxFile)
		if e != nil && !errors.Is(e, fs.ErrNotExist) {
			return e
		}
		if e == nil {
			hash := digest(current)
			if hash != r.New && (!r.Existed || hash != r.Old) {
				return fmt.Errorf("%s mudou fora do atualizador; preserve esse arquivo e a cópia anterior", r.Path)
			}
		}
		if r.Existed {
			saved, e := safeDestination(filepath.Join(m.Root, "backups", j.Backup), r.Path, false)
			if e != nil {
				return e
			}
			b, e := readSmall(saved, maxFile)
			if e != nil || digest(b) != r.Old {
				return errors.New("a cópia anterior não pôde ser verificada; nada será apagado")
			}
		}
	}
	for _, r := range j.Files {
		destination, e := safeDestination(m.Target, r.Path, true)
		if e != nil {
			return e
		}
		if r.Existed {
			saved := filepath.Join(m.Root, "backups", j.Backup, filepath.FromSlash(r.Path))
			b, e := readSmall(saved, maxFile)
			if e != nil {
				return e
			}
			if e = writeAtomic(destination, b); e != nil {
				return e
			}
		} else if e = os.Remove(destination); e != nil && !errors.Is(e, fs.ErrNotExist) {
			return e
		}
	}
	return os.Remove(filepath.Join(m.Root, "pending.json"))
}
func (m *Manager) pruneBackups() {
	base := filepath.Join(m.Root, "backups")
	entries, e := os.ReadDir(base)
	if e != nil {
		return
	}
	names := []string{}
	for _, entry := range entries {
		if !entry.IsDir() || entry.Type()&os.ModeSymlink != 0 {
			continue
		}
		name := entry.Name()
		if len(name) != 29 {
			continue
		}
		b, e := readSmall(filepath.Join(base, name, "journal.json"), 128<<10)
		var j Journal
		if e == nil && strictJSON(b, &j) == nil && j.Schema == 1 && j.Backup == name && j.Target == m.Target {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	for len(names) > 3 {
		_ = os.RemoveAll(filepath.Join(base, names[0]))
		names = names[1:]
	}
}
