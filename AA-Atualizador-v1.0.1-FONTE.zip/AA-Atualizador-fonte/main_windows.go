//go:build windows

package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"time"
	"unsafe"
)

var user = syscall.NewLazyDLL("user32.dll")
var shell = syscall.NewLazyDLL("shell32.dll")
var ole = syscall.NewLazyDLL("ole32.dll")
var messageBox = user.NewProc("MessageBoxW")
var postMessage = user.NewProc("PostMessageW")
var setText = user.NewProc("SetWindowTextW")
var enableWindow = user.NewProc("EnableWindow")
var createWindow = user.NewProc("CreateWindowExW")
var sendMessage = user.NewProc("SendMessageW")
var uiRoot string
var hwnd, folderLabel, statusLabel, brandSubtitle uintptr
var selectedTarget string
var buttons []uintptr
var posted = make(chan func(), 16)
var uiBusy bool
var uiFont uintptr

const (
	wmCommand = 0x0111
	wmDestroy = 0x0002
	wmClose   = 0x0010
	wmPosted  = 0x8001
)
const (
	chooseID  = 101
	installID = 102
	checkID   = 103
	pauseID   = 104
	chromeID  = 105
	folderID  = 106
)

func showError(message string) {
	messageBox.Call(hwnd, uintptr(unsafe.Pointer(wide(message))), uintptr(unsafe.Pointer(wide("AA Visual Editor"))), 0x10)
}
func text(handle uintptr, value string) { setText.Call(handle, uintptr(unsafe.Pointer(wide(value)))) }
func refreshBranding() {
	label := displayVersion
	if manifest, e := targetManifest(selectedTarget); e == nil {
		label = manifestLabel(manifest)
	}
	text(hwnd, productName+" — Atualizador · "+label)
	if brandSubtitle != 0 {
		text(brandSubtitle, "Atualizador · Versão "+label)
	}
}
func onUI(fn func()) { posted <- fn; postMessage.Call(hwnd, wmPosted, 0, 0) }
func task(fn func() error) {
	if uiBusy {
		return
	}
	uiBusy = true
	for _, b := range buttons {
		enableWindow.Call(b, 0)
	}
	go func() {
		e := fn()
		onUI(func() {
			uiBusy = false
			for _, b := range buttons {
				enableWindow.Call(b, 1)
			}
			if e != nil {
				text(statusLabel, e.Error())
				showError(e.Error())
			}
		})
	}()
}
func configure() error {
	if _, e := targetManifest(selectedTarget); e != nil {
		return e
	}
	if old, e := loadConfig(uiRoot); e == nil && old.Target != selectedTarget {
		if e = stopWatcher(uiRoot); e != nil {
			return e
		}
		manager := newManager(uiRoot, old.Target)
		unlock, e := lockFile(filepath.Join(uiRoot, "update.lock"))
		if e != nil {
			return e
		}
		e = manager.recover()
		unlock()
		if e != nil {
			return e
		}
	}
	executable, e := installBinary(uiRoot)
	if e != nil {
		return e
	}
	if e = createStartShortcut(executable); e != nil {
		return e
	}
	config := Config{Schema: 1, Target: selectedTarget, Automatic: true}
	if e = saveJSON(filepath.Join(uiRoot, "config.json"), config); e != nil {
		return e
	}
	if e = setAutostart(executable, true); e != nil {
		config.Automatic = false
		_ = saveJSON(filepath.Join(uiRoot, "config.json"), config)
		return e
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	result, checkErr := newManager(uiRoot, selectedTarget).Check(ctx)
	if e = startWatcher(executable); e != nil {
		return e
	}
	message := "Atualização automática ativada. O programa inicia com o Windows e verifica novas versões a cada minuto.\r\n\r\n"
	if checkErr != nil {
		message += "A primeira consulta não terminou: " + checkErr.Error() + "\r\nO programa tentará novamente automaticamente."
	} else {
		message += result.Message
	}
	onUI(func() {
		refreshBranding()
		text(statusLabel, message)
		text(buttons[1], "Ativar / configurar automático")
	})
	return nil
}
func checkNow() error {
	config, e := loadConfig(uiRoot)
	if e != nil {
		return errors.New("primeiro escolha a pasta e clique em Ativar atualização automática")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	result, e := newManager(uiRoot, config.Target).Check(ctx)
	if e != nil {
		return e
	}
	onUI(func() {
		refreshBranding()
		text(statusLabel, result.Message+"\r\n\r\nÚltima consulta: "+time.Now().Format("02/01/2006 15:04:05"))
	})
	return nil
}
func pause() error {
	c, e := loadConfig(uiRoot)
	if e != nil {
		return errors.New("o atualizador ainda não está configurado")
	}
	c.Automatic = false
	if e = saveJSON(filepath.Join(uiRoot, "config.json"), c); e != nil {
		return e
	}
	executable := filepath.Join(uiRoot, "AA-Atualizador.exe")
	if e = setAutostart(executable, false); e != nil {
		return e
	}
	if e = stopWatcher(uiRoot); e != nil {
		return e
	}
	onUI(func() {
		text(statusLabel, "Atualização automática desativada. A extensão e seus dados continuam no mesmo lugar. Use Verificar agora para uma consulta manual.")
	})
	return nil
}
func openChrome() {
	result, _, _ := shell.NewProc("ShellExecuteW").Call(hwnd, uintptr(unsafe.Pointer(wide("open"))), uintptr(unsafe.Pointer(wide("chrome.exe"))), uintptr(unsafe.Pointer(wide("chrome://extensions"))), 0, 1)
	if result <= 32 {
		showError("Abra o Chrome e digite chrome://extensions na barra de endereço.")
	}
}

type BrowseInfo struct {
	Owner    uintptr
	Root     uintptr
	Display  *uint16
	Title    *uint16
	Flags    uint32
	Callback uintptr
	Param    uintptr
	Image    int32
}

func browseFolder() string {
	display := make([]uint16, 260)
	info := BrowseInfo{Owner: hwnd, Display: &display[0], Title: wide("Escolha a pasta AA-Visual-Editor já instalada, que contém manifest.json"), Flags: 0x1 | 0x40}
	pidl, _, _ := shell.NewProc("SHBrowseForFolderW").Call(uintptr(unsafe.Pointer(&info)))
	if pidl == 0 {
		return ""
	}
	defer ole.NewProc("CoTaskMemFree").Call(pidl)
	buffer := make([]uint16, 32768)
	ok, _, _ := shell.NewProc("SHGetPathFromIDListEx").Call(pidl, uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)), 0)
	if ok == 0 {
		return ""
	}
	return syscall.UTF16ToString(buffer)
}
func wndProc(window uintptr, msg uint32, w, l uintptr) uintptr {
	switch msg {
	case wmCommand:
		if uiBusy {
			return 0
		}
		switch int(w & 0xffff) {
		case chooseID:
			chosen := browseFolder()
			if chosen == "" {
				return 0
			}
			manifest, e := targetManifest(chosen)
			if e != nil {
				showError(e.Error())
				return 0
			}
			selectedTarget = chosen
			text(folderLabel, chosen)
			refreshBranding()
			text(statusLabel, "Pasta reconhecida: "+productName+" "+manifestLabel(manifest)+". Clique em Ativar atualização automática.")
		case installID:
			task(configure)
		case checkID:
			task(checkNow)
		case pauseID:
			task(pause)
		case chromeID:
			openChrome()
		case folderID:
			shell.NewProc("ShellExecuteW").Call(hwnd, uintptr(unsafe.Pointer(wide("open"))), uintptr(unsafe.Pointer(wide(uiRoot))), 0, 0, 1)
		}
		return 0
	case wmPosted:
		select {
		case fn := <-posted:
			fn()
		default:
		}
		return 0
	case wmClose:
		if uiBusy {
			text(statusLabel, "Aguarde a operação terminar antes de fechar. Seus arquivos estão sendo conferidos.")
			return 0
		}
		user.NewProc("DestroyWindow").Call(window)
		return 0
	case wmDestroy:
		user.NewProc("PostQuitMessage").Call(0)
		return 0
	}
	result, _, _ := user.NewProc("DefWindowProcW").Call(window, uintptr(msg), w, l)
	return result
}

type WindowClass struct {
	Size                               uint32
	Style                              uint32
	Proc                               uintptr
	ClassExtra, WindowExtra            int32
	Instance, Icon, Cursor, Background uintptr
	MenuName, ClassName                *uint16
	SmallIcon                          uintptr
}
type Point struct{ X, Y int32 }
type Message struct {
	Window         uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Point          Point
	Private        uint32
}

func makeControl(class, value string, x, y, width, height int, id int, style uintptr) uintptr {
	handle, _, _ := createWindow.Call(0, uintptr(unsafe.Pointer(wide(class))), uintptr(unsafe.Pointer(wide(value))), 0x40000000|0x10000000|style, uintptr(x), uintptr(y), uintptr(width), uintptr(height), hwnd, uintptr(id), 0, 0)
	font, _, _ := syscall.NewLazyDLL("gdi32.dll").NewProc("GetStockObject").Call(17)
	if uiFont != 0 {
		font = uiFont
	}
	sendMessage.Call(handle, 0x30, font, 1)
	return handle
}
func window(root string) error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	ole.NewProc("OleInitialize").Call(0)
	defer ole.NewProc("OleUninitialize").Call()
	uiRoot = root
	height := int32(-16)
	uiFont, _, _ = syscall.NewLazyDLL("gdi32.dll").NewProc("CreateFontW").Call(uintptr(height), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(wide("Segoe UI"))))
	if uiFont != 0 {
		defer syscall.NewLazyDLL("gdi32.dll").NewProc("DeleteObject").Call(uiFont)
	}
	className := wide("AAVisualEditorUpdaterWindow")
	instance, _, _ := kernel.NewProc("GetModuleHandleW").Call(0)
	cursor, _, _ := user.NewProc("LoadCursorW").Call(0, 32512)
	icon, _, _ := user.NewProc("LoadIconW").Call(instance, 1)
	if icon == 0 {
		icon, _, _ = user.NewProc("LoadIconW").Call(0, 32516)
	}
	wc := WindowClass{Size: uint32(unsafe.Sizeof(WindowClass{})), Proc: syscall.NewCallback(wndProc), Instance: instance, Cursor: cursor, Background: 6, ClassName: className, Icon: icon, SmallIcon: icon}
	atom, _, e := user.NewProc("RegisterClassExW").Call(uintptr(unsafe.Pointer(&wc)))
	if atom == 0 {
		return e
	}
	hwnd, _, e = createWindow.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(wide(productName+" — Atualizador · "+displayVersion))), 0x00CA0000, 180, 120, 720, 590, 0, 0, instance, 0)
	if hwnd == 0 {
		return e
	}
	art := makeControl("STATIC", "", 22, 14, 56, 56, 0, 0x0003)
	large, _, _ := user.NewProc("LoadImageW").Call(instance, 1, 1, 56, 56, 0)
	if large != 0 {
		sendMessage.Call(art, 0x0170, large, 0)
	}
	makeControl("STATIC", productName, 92, 17, 580, 25, 0, 0x80)
	brandSubtitle = makeControl("STATIC", "Atualizador · Versão "+displayVersion, 92, 43, 580, 24, 0, 0x80)
	makeControl("STATIC", "1. Escolha a pasta da extensão que já está instalada (contém manifest.json).", 22, 90, 665, 32, 0, 0x80)
	folderLabel = makeControl("EDIT", "Nenhuma pasta escolhida", 22, 129, 500, 30, 0, 0x0800|0x0080|0x800000)
	buttons = append(buttons, makeControl("BUTTON", "Escolher pasta…", 534, 128, 150, 32, chooseID, 0x10000))
	makeControl("STATIC", "2. Ative uma vez. O programa inicia com o Windows e consulta novas versões a cada minuto.", 22, 173, 665, 42, 0, 0x80)
	buttons = append(buttons, makeControl("BUTTON", "Ativar atualização automática", 22, 224, 290, 38, installID, 0x10000))
	buttons = append(buttons, makeControl("BUTTON", "Verificar agora", 326, 224, 174, 38, checkID, 0x10000))
	buttons = append(buttons, makeControl("BUTTON", "Desativar automático", 512, 224, 174, 38, pauseID, 0x10000))
	makeControl("STATIC", "3. Depois de uma atualização: Recarregar na extensão e F5 no site.", 22, 277, 665, 32, 0, 0x80)
	buttons = append(buttons, makeControl("BUTTON", "Abrir extensões do Chrome", 22, 316, 290, 34, chromeID, 0x10000))
	buttons = append(buttons, makeControl("BUTTON", "Abrir pasta do atualizador", 326, 316, 252, 34, folderID, 0x10000))
	statusLabel = makeControl("EDIT", "As versões são conferidas antes da instalação. São mantidas três cópias anteriores dos arquivos. Seus perfis e imagens continuam no navegador.", 22, 368, 665, 135, 0, 0x0800|0x0004|0x0040|0x00200000|0x800000)
	if c, e := loadConfig(root); e == nil {
		selectedTarget = c.Target
		text(folderLabel, c.Target)
		message := "Atualizador configurado. "
		if c.Automatic {
			message += "Busca automática ativada."
		} else {
			message += "Busca automática desativada."
		}
		if b, e := readSmall(filepath.Join(root, "last-status.json"), 32768); e == nil {
			var r Result
			if json.Unmarshal(b, &r) == nil && r.DisplayVersion != "" {
				message += "\r\n" + r.Message
			}
		}
		text(statusLabel, message)
		text(buttons[1], "Ativar / configurar automático")
	}
	refreshBranding()
	user.NewProc("ShowWindow").Call(hwnd, 1)
	user.NewProc("UpdateWindow").Call(hwnd)
	var msg Message
	for {
		r, _, _ := user.NewProc("GetMessageW").Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if r == 0 {
			break
		}
		if int32(r) == -1 {
			return errors.New("falha na janela do Windows")
		}
		handled, _, _ := user.NewProc("IsDialogMessageW").Call(hwnd, uintptr(unsafe.Pointer(&msg)))
		if handled == 0 {
			user.NewProc("TranslateMessage").Call(uintptr(unsafe.Pointer(&msg)))
			user.NewProc("DispatchMessageW").Call(uintptr(unsafe.Pointer(&msg)))
		}
	}
	return nil
}
func watch(root string) error {
	mutexName, eventName := watchNames(root)
	mutex, _, e := createMutex.Call(0, 1, uintptr(unsafe.Pointer(wide(mutexName))))
	if mutex == 0 {
		return e
	}
	defer syscall.CloseHandle(syscall.Handle(mutex))
	if errors.Is(e, syscall.Errno(183)) {
		return nil
	}
	defer kernel.NewProc("ReleaseMutex").Call(mutex)
	event, _, e := createEvent.Call(0, 1, 0, uintptr(unsafe.Pointer(wide(eventName))))
	if event == 0 {
		return e
	}
	defer syscall.CloseHandle(syscall.Handle(event))
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	exited := make(chan struct{})
	defer func() { close(done); <-exited }()
	go func() {
		defer close(exited)
		for {
			select {
			case <-done:
				return
			default:
			}
			if untilEvent(event, 250*time.Millisecond) {
				cancel()
				return
			}
		}
	}()
	for {
		if ctx.Err() != nil {
			return nil
		}
		config, e := loadConfig(root)
		if e != nil || !config.Automatic {
			return nil
		}
		checkCtx, finish := context.WithTimeout(ctx, 45*time.Second)
		_, _ = newManager(root, config.Target).Check(checkCtx)
		finish()
		if untilEvent(event, time.Minute) {
			return nil
		}
	}
}
func main() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	root, e := appRoot()
	if e != nil {
		showError(e.Error())
		return
	}
	if e = os.MkdirAll(root, 0700); e != nil {
		showError("Não foi possível criar a pasta do atualizador: " + e.Error())
		return
	}
	if len(os.Args) > 1 && os.Args[1] == "--watch" {
		_ = watch(root)
		return
	}
	if len(os.Args) > 1 && os.Args[1] == "--check" {
		c, e := loadConfig(root)
		if e == nil {
			_, e = newManager(root, c.Target).Check(context.Background())
		}
		if e != nil {
			showError(e.Error())
		}
		return
	}
	mutex, _, e := createMutex.Call(0, 1, uintptr(unsafe.Pointer(wide(`Local\AAVisualEditorUpdaterUI-`+digest([]byte(root))[:20]))))
	if mutex == 0 {
		showError("Não foi possível iniciar o atualizador nesta conta do Windows.")
		return
	}
	if mutex != 0 {
		defer syscall.CloseHandle(syscall.Handle(mutex))
	}
	if errors.Is(e, syscall.Errno(183)) {
		showError("O atualizador já está aberto. Use a janela existente.")
		return
	}
	if e = window(root); e != nil {
		showError(fmt.Sprintf("Não foi possível abrir a janela: %v", e))
	}
}
