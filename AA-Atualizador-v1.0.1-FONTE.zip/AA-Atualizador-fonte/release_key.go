package main

// Public verification key; the private signing key is never distributed.
const releasePublicKeyHex = "eae836d1d974ed1eeaa72355facfabaee164685df9bc424a5a506884780b7f7c"
