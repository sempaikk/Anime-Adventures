# AA Visual Editor — Atualizador 0.1

Usa a mesma arte de Madara e a mesma versão visível **0.1** da extensão. Esse número só muda quando o usuário solicitar. As mensagens de atualização conservam o rótulo visível enquanto as compilações técnicas continuam sendo comparadas corretamente.

Aplicativo nativo para Windows x64, sem instalação de Go, Python, PowerShell ou ferramentas no computador do usuário. Configuração por janela: selecionar a pasta da extensão já instalada e ativar a atualização automática.

O aplicativo é copiado para `%LOCALAPPDATA%\AAVisualEditorUpdater`, cria um atalho no menu Iniciar e uma entrada de inicialização na chave `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` chamada `AAVisualEditorUpdater`. Ele consulta o canal a cada minuto enquanto a conta está conectada. O botão **Desativar automático** remove essa entrada e encerra o processo de verificação. A consulta manual continua disponível.

O canal HTTPS é fixo na ramificação independente `aa-visual-editor-downloads` de `sempaikk/Anime-Adventures`. O aplicativo verifica a assinatura Ed25519 do manifesto, o SHA-256 do ZIP e de todos os arquivos antes de substituir o código. Não executa conteúdo obtido da rede nem instala ou recarrega extensões por políticas administrativas. Os arquivos da extensão continuam sendo executados pelo Chrome quando o usuário clica em **Recarregar**.

São mantidos a pasta original, a chave do manifesto e o armazenamento do Chrome. O programa não acessa os perfis do navegador. Permissões ampliadas, outros sites, caminhos inválidos, links simbólicos, arquivos duplicados, mudanças de identidade e pacotes incompletos são recusados. Operações concorrentes usam um bloqueio do sistema operacional. O código anterior é guardado antes da escrita; uma operação incompleta é recuperada na próxima execução. Arquivos que não pertencem ao pacote não são apagados. Três cópias anteriores do código são conservadas.

O executável não possui assinatura Authenticode. A assinatura Ed25519 autentica os pacotes de atualização e tem outra finalidade. O recurso de execução do aplicativo declara `asInvoker`; ele não solicita elevação e não modifica políticas de segurança do Windows.

## Compilar e validar

Ferramentas utilizadas: Go 1.27.3, Python com cryptography/Pillow e o gerador de recursos `github.com/tc-hib/go-winres@v0.3.3` apenas na preparação do recurso Windows. O aplicativo não tem dependências Go externas de execução.

```sh
go test -buildvcs=false -race ./...
AAVE_TEST_DISTRIBUTION=../aa-visual-editor-distribution go test -buildvcs=false -race ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet -buildvcs=false ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -buildvcs=false -trimpath -ldflags='-s -w -H=windowsgui' -o AA-Atualizador.exe .
```

O recurso `resource_windows_amd64.syso` inclui o ícone, o manifesto `asInvoker` e as informações de produto e versão visível do Windows. Para regenerá-lo: `go run github.com/tc-hib/go-winres@v0.3.3 make --in winres.json --out resource --arch amd64`.

Os testes do núcleo usam o sistema de arquivos, ZIP e criptografia reais e incluem o pacote da extensão distribuído. A janela Win32, o atalho COM, o registro da inicialização e as operações específicas do Windows foram compilados/conferidos estaticamente; não foram executados neste ambiente Linux. Não foi contornada a política administrativa que bloqueia instalar extensões neste ambiente.
