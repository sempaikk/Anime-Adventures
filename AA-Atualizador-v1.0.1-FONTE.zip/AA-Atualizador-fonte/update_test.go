package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func sampleFiles(ver string) map[string][]byte {
	m := map[string]any{"manifest_version": 3, "name": "AA Visual Editor", "version": ver, "permissions": []string{"storage", "activeTab", "scripting"}, "content_scripts": []any{map[string]any{"matches": []string{"https://www.roblox.com/games/8304191830*"}, "js": []string{"content.js"}}}, "background": map[string]any{"service_worker": "background.js"}}
	b, _ := json.Marshal(m)
	return map[string][]byte{"manifest.json": b, "content.js": []byte("// editor " + ver), "background.js": []byte("// worker " + ver), "icons/icon16.png": []byte("fixture icon")}
}
func packageFor(files map[string][]byte, ver string) (Release, []byte) {
	var b bytes.Buffer
	z := zip.NewWriter(&b)
	hashes := map[string]string{}
	for _, name := range orderedNames(files) {
		w, _ := z.Create("AA-Visual-Editor/" + name)
		_, _ = w.Write(files[name])
		hashes[name] = digest(files[name])
	}
	z.Close()
	raw := b.Bytes()
	return Release{Schema: 1, App: "aa-visual-editor", Version: ver, URL: downloadBase + "AA-Visual-Editor-v" + ver + ".zip", Size: int64(len(raw)), SHA256: digest(raw), Files: hashes}, raw
}
func signed(r Release, key ed25519.PrivateKey) []byte {
	b, _ := json.Marshal(r)
	env := Envelope{Payload: base64.StdEncoding.EncodeToString(b), Signature: base64.StdEncoding.EncodeToString(ed25519.Sign(key, b))}
	out, _ := json.Marshal(env)
	return out
}
func prepare(t *testing.T) (*Manager, map[string][]byte, Release, []byte) {
	t.Helper()
	root := t.TempDir()
	target := filepath.Join(t.TempDir(), "AA-Visual-Editor")
	os.Mkdir(target, 0700)
	before := sampleFiles("2.0.1")
	for name, b := range before {
		destination, e := safeDestination(target, name, true)
		if e != nil {
			t.Fatal(e)
		}
		if e = writeAtomic(destination, b); e != nil {
			t.Fatal(e)
		}
	}
	public, private, e := ed25519.GenerateKey(rand.Reader)
	if e != nil {
		t.Fatal(e)
	}
	r, raw := packageFor(sampleFiles("2.0.2"), "2.0.2")
	env := signed(r, private)
	m := &Manager{Root: root, Target: target, Key: public, write: writeAtomic, fetch: func(ctx context.Context, address string, limit int64) ([]byte, error) {
		if e := ctx.Err(); e != nil {
			return nil, e
		}
		if address == feedURL {
			return env, nil
		}
		if address == r.URL {
			return raw, nil
		}
		return nil, errors.New("unexpected URL")
	}}
	return m, before, r, raw
}
func assertFiles(t *testing.T, target string, files map[string][]byte) {
	t.Helper()
	for name, want := range files {
		got, e := os.ReadFile(filepath.Join(target, filepath.FromSlash(name)))
		if e != nil || !bytes.Equal(got, want) {
			t.Fatalf("%s: got %q (%v), want %q", name, got, e, want)
		}
	}
}

func TestSignedUpdatePreservesDirectoryIdentityAndUnrelatedUserFiles(t *testing.T) {
	m, _, _, _ := prepare(t)
	before, _ := os.Stat(m.Target)
	personal := filepath.Join(m.Target, "meu-backup.json")
	os.WriteFile(personal, []byte("personal data"), 0600)
	browser := filepath.Join(filepath.Dir(m.Target), "Chrome Profile")
	os.Mkdir(browser, 0700)
	os.WriteFile(filepath.Join(browser, "Preferences"), []byte("keep browser preferences"), 0600)
	result, e := m.Check(context.Background())
	if e != nil || !result.Updated || result.Version != "2.0.2" {
		t.Fatalf("%+v %v", result, e)
	}
	assertFiles(t, m.Target, sampleFiles("2.0.2"))
	after, _ := os.Stat(m.Target)
	if !os.SameFile(before, after) {
		t.Fatal("extension directory identity changed")
	}
	b, _ := os.ReadFile(personal)
	if string(b) != "personal data" {
		t.Fatal("unrelated file changed")
	}
	b, _ = os.ReadFile(filepath.Join(browser, "Preferences"))
	if string(b) != "keep browser preferences" {
		t.Fatal("browser profile changed")
	}
	entries, _ := os.ReadDir(filepath.Join(m.Root, "backups"))
	if len(entries) != 1 {
		t.Fatal("previous source was not backed up")
	}
}
func TestSameVersionDoesNotOverwriteLocalChanges(t *testing.T) {
	m, _, _, _ := prepare(t)
	_, e := m.Check(context.Background())
	if e != nil {
		t.Fatal(e)
	}
	custom := []byte("user local customization")
	os.WriteFile(filepath.Join(m.Target, "content.js"), custom, 0600)
	result, e := m.Check(context.Background())
	if e != nil || result.Updated {
		t.Fatalf("%+v %v", result, e)
	}
	b, _ := os.ReadFile(filepath.Join(m.Target, "content.js"))
	if !bytes.Equal(b, custom) {
		t.Fatal("same-version local customization overwritten")
	}
}
func TestNetworkFailureAndCancelledRequestKeepCurrentFiles(t *testing.T) {
	for _, kind := range []string{"network", "cancelled"} {
		t.Run(kind, func(t *testing.T) {
			m, before, _, _ := prepare(t)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if kind == "network" {
				m.fetch = func(context.Context, string, int64) ([]byte, error) { return nil, errors.New("offline") }
			} else {
				cancel()
			}
			if _, e := m.Check(ctx); e == nil {
				t.Fatal("expected failure")
			}
			assertFiles(t, m.Target, before)
		})
	}
}
func TestInvalidSignatureNeverDownloadsOrWritesPackage(t *testing.T) {
	m, before, r, _ := prepare(t)
	_, untrusted, _ := ed25519.GenerateKey(rand.Reader)
	calls := 0
	m.fetch = func(context.Context, string, int64) ([]byte, error) { calls++; return signed(r, untrusted), nil }
	if _, e := m.Check(context.Background()); e == nil {
		t.Fatal("accepted untrusted signature")
	}
	if calls != 1 {
		t.Fatal("downloaded package before checking signature")
	}
	assertFiles(t, m.Target, before)
}
func TestTruncatedOrChangedArchiveIsRejected(t *testing.T) {
	_, _, r, raw := prepare(t)
	for _, b := range [][]byte{raw[:len(raw)-2], append(append([]byte{}, raw...), 0), []byte("not a zip")} {
		if _, e := unpack(r, b); e == nil {
			t.Fatal("accepted changed archive")
		}
	}
}
func TestRollbackAfterWriteFailureRestoresEveryOldFile(t *testing.T) {
	m, before, _, _ := prepare(t)
	writes := 0
	m.write = func(name string, b []byte) error {
		writes++
		if writes == 3 {
			return errors.New("simulated locked file")
		}
		return writeAtomic(name, b)
	}
	if _, e := m.Check(context.Background()); e == nil {
		t.Fatal("expected write failure")
	}
	assertFiles(t, m.Target, before)
	if _, e := os.Stat(filepath.Join(m.Root, "pending.json")); !os.IsNotExist(e) {
		t.Fatal("rollback left pending journal")
	}
}
func TestInterruptedUpdateIsRecoveredBeforeNetworkIsUsed(t *testing.T) {
	m, before, _, _ := prepare(t)
	interrupted := errors.New("simulated process interruption")
	m.write = func(name string, b []byte) error {
		if strings.HasSuffix(name, "content.js") {
			panic(interrupted)
		}
		return writeAtomic(name, b)
	}
	func() {
		defer func() {
			if recover() != interrupted {
				t.Fatal("expected interruption")
			}
		}()
		_, _ = m.Check(context.Background())
	}()
	if _, e := os.Stat(filepath.Join(m.Root, "pending.json")); e != nil {
		t.Fatal("missing recovery journal")
	}
	m.fetch = func(context.Context, string, int64) ([]byte, error) {
		assertFiles(t, m.Target, before)
		return nil, errors.New("offline after recovery")
	}
	if _, e := m.Check(context.Background()); e == nil {
		t.Fatal("expected offline result")
	}
	assertFiles(t, m.Target, before)
}
func TestRecoveryDoesNotOverwriteFilesChangedByTheUser(t *testing.T) {
	m, _, _, _ := prepare(t)
	m.write = func(name string, b []byte) error { panic("interruption") }
	func() { defer func() { _ = recover() }(); _, _ = m.Check(context.Background()) }()
	file := filepath.Join(m.Target, "content.js")
	os.WriteFile(file, []byte("manual edit after crash"), 0600)
	if e := m.recover(); e == nil {
		t.Fatal("expected conflict")
	}
	b, _ := os.ReadFile(file)
	if string(b) != "manual edit after crash" {
		t.Fatal("manual changes lost")
	}
}
func TestCompletedTransactionIsFinalizedAfterInterruptedCleanup(t *testing.T) {
	m, _, _, _ := prepare(t)
	if _, e := m.Check(context.Background()); e != nil {
		t.Fatal(e)
	}
	entries, _ := os.ReadDir(filepath.Join(m.Root, "backups"))
	j, _ := os.ReadFile(filepath.Join(m.Root, "backups", entries[0].Name(), "journal.json"))
	os.WriteFile(filepath.Join(m.Root, "pending.json"), j, 0600)
	if e := m.recover(); e != nil {
		t.Fatal(e)
	}
	assertFiles(t, m.Target, sampleFiles("2.0.2"))
}
func TestOnlyThreeOwnedBackupsArePruned(t *testing.T) {
	m, _, _, _ := prepare(t)
	unrelated := filepath.Join(m.Root, "backups", "my-personal-folder")
	os.MkdirAll(unrelated, 0700)
	os.WriteFile(filepath.Join(unrelated, "backup.json"), []byte("mine"), 0600)
	for i := 0; i < 5; i++ {
		if e := m.apply(sampleFiles("2.0.2")); e != nil {
			t.Fatal(e)
		}
	}
	entries, _ := os.ReadDir(filepath.Join(m.Root, "backups"))
	if len(entries) != 4 {
		t.Fatalf("got %d directories", len(entries))
	}
	b, _ := os.ReadFile(filepath.Join(unrelated, "backup.json"))
	if string(b) != "mine" {
		t.Fatal("unrelated backup pruned")
	}
}
func TestDirectoryAndLockValidation(t *testing.T) {
	m, before, _, _ := prepare(t)
	unlock, e := lockFile(filepath.Join(m.Root, "update.lock"))
	if e != nil {
		t.Fatal(e)
	}
	if _, e = m.Check(context.Background()); !errors.Is(e, errBusy) {
		t.Fatalf("expected busy: %v", e)
	}
	unlock()
	assertFiles(t, m.Target, before)
	if _, e = targetManifest(t.TempDir()); e == nil {
		t.Fatal("accepted non-extension directory")
	}
}
func TestPathValidationRejectsWindowsTricks(t *testing.T) {
	bad := []string{"../outside.js", "a/../../x.js", "/absolute.js", "C:/x.js", "a\\x.js", "content.js:extra", "CON.js", "x/LPT1.json", "AUX.md", "file. /a.js", "a./b.js", "a/../b.js", "a//b.js", "a\x00.js", "x.exe", "x.ps1", "x.cmd", "x.lnk", "a\n.js"}
	for _, p := range bad {
		if validPath(p) {
			t.Errorf("accepted %q", p)
		}
	}
	for _, p := range []string{"manifest.json", "icons/icon128.png", "content.js", "LEIA-ME.md"} {
		if !validPath(p) {
			t.Errorf("rejected %q", p)
		}
	}
}
func TestArchiveRejectsTraversalDuplicatesAndMissingFiles(t *testing.T) {
	_, _, r, _ := prepare(t)
	for _, name := range []string{"AA-Visual-Editor/../outside.js", "AA-Visual-Editor/C:/x.js", "outside/content.js"} {
		var b bytes.Buffer
		z := zip.NewWriter(&b)
		w, _ := z.Create(name)
		w.Write([]byte("evil"))
		z.Close()
		bad := r
		bad.Size = int64(b.Len())
		bad.SHA256 = digest(b.Bytes())
		if _, e := unpack(bad, b.Bytes()); e == nil {
			t.Fatalf("accepted %s", name)
		}
	}
	files := sampleFiles("2.0.2")
	delete(files, "background.js")
	bad, raw := packageFor(files, "2.0.2")
	if _, e := unpack(bad, raw); e == nil {
		t.Fatal("accepted missing worker")
	}
}
func TestManifestCannotExpandPermissionsSitesOrChangeIdentity(t *testing.T) {
	for _, kind := range []string{"permission", "site", "key"} {
		t.Run(kind, func(t *testing.T) {
			m, before, _, _ := prepare(t)
			files := sampleFiles("2.0.2")
			var raw map[string]any
			json.Unmarshal(files["manifest.json"], &raw)
			switch kind {
			case "permission":
				raw["permissions"] = []string{"storage", "activeTab", "scripting", "cookies"}
			case "site":
				raw["content_scripts"].([]any)[0].(map[string]any)["matches"] = []string{"<all_urls>"}
			case "key":
				raw["key"] = "would-change-extension-id"
			}
			files["manifest.json"], _ = json.Marshal(raw)
			r, archive := packageFor(files, "2.0.2")
			pub, key, _ := ed25519.GenerateKey(rand.Reader)
			m.Key = pub
			m.fetch = func(_ context.Context, address string, _ int64) ([]byte, error) {
				if address == feedURL {
					return signed(r, key), nil
				}
				return archive, nil
			}
			if _, e := m.Check(context.Background()); e == nil {
				t.Fatal("accepted incompatible manifest")
			}
			assertFiles(t, m.Target, before)
		})
	}
}
func TestVersionsAndHTTPSOrigin(t *testing.T) {
	for _, c := range []struct {
		A, B string
		Want int
	}{{"2.0.2", "2.0.1", 1}, {"2.0.1", "2.0.1.0", 0}, {"2.9", "2.10", -1}} {
		got, e := compareVersion(c.A, c.B)
		if e != nil || got != c.Want {
			t.Fatal(c, got, e)
		}
	}
	for _, s := range []string{"2.00.1", "2.-1", "v2.0", "2.0.65536", "2.0.1.0.0"} {
		if _, e := version(s); e == nil {
			t.Errorf("accepted %q", s)
		}
	}
	for _, s := range []string{"http://raw.githubusercontent.com/sempaikk/Anime-Adventures/refs/heads/aa-visual-editor-downloads/x", "https://raw.githubusercontent.com.evil.example/a", "https://user@raw.githubusercontent.com/sempaikk/Anime-Adventures/refs/heads/aa-visual-editor-downloads/x", downloadBase + "x?override=yes"} {
		if allowedURL(s) {
			t.Errorf("accepted %q", s)
		}
	}
}
