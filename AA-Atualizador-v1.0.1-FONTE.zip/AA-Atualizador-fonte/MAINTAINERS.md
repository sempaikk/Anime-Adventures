# Publicação das próximas versões

A atualização automática depende de publicar também o manifesto assinado. Publicar só um ZIP não anuncia a nova versão ao aplicativo.

1. Modifique o projeto `../aa-visual-editor`, preserve seus formatos de dados e as migrações, incremente somente o campo técnico `version` de `extension/manifest.json`, mantendo o rótulo visível `version_name: "0.1"` até o usuário pedir outro número e execute os testes apropriados.
2. Execute `python scripts/build_delivery.py` e `python scripts/verify_delivery.py` no projeto da extensão.
3. Execute `python scripts/prepare_release.py` neste projeto do atualizador. Ele valida o pacote, copia o ZIP e atualiza `../aa-visual-editor-distribution/aa-editor-stable.json` com assinatura Ed25519. Recusa um downgrade e a substituição de uma versão já publicada por bytes diferentes.
4. Confira a verificação com `AAVE_TEST_DISTRIBUTION=../aa-visual-editor-distribution go test -buildvcs=false -race ./...` e os hashes.
5. Faça commit e push somente dos arquivos de distribuição necessários na ramificação `aa-visual-editor-downloads`. Preserve os ZIPs versionados anteriores. O branch principal do bot e a wiki são independentes.

A chave privada fica exclusivamente em `.signing/release-key.pem` no workspace do mantenedor, com acesso restrito. Ela não faz parte dos ZIPs, do executável nem do repositório público. Preserve-a em armazenamento privado do mantenedor; sem ela não é possível assinar novos pacotes para os aplicativos já instalados. Não gere outra chave para contornar essa falta, não a publique e não a inclua em mensagens ou logs. A chave pública fixa está em `release_key.go`.

O script apenas prepara os arquivos; ele não faz commit ou push. Uma nova versão da extensão deve passar pelos testes antes da publicação. Mudanças nas permissões, sites acessados ou identidade da extensão precisam de uma migração explícita, pois são bloqueadas pelo atualizador atual.
