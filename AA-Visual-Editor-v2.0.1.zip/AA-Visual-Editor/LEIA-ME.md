# AA Visual Editor 2.0.1

Editor local da página do Anime Adventures (jogo 8304191830) para Chrome e Edge no computador. Textos, números, imagens e aparência mudam somente neste navegador. Contas, estatísticas reais, bot e site continuam independentes.

## Instalar ou atualizar

Antes de atualizar, use **Perfis e cenas → Exportar todos os perfis** e guarde o JSON. A atualização conserva os dados quando os arquivos são substituídos na mesma pasta instalada e a extensão existente é recarregada.

1. Baixe **AA-Visual-Editor-v2.0.1.zip**, clique com o botão direito no arquivo e escolha **Extrair Tudo**. O download direto está na [página da extensão](https://github.com/sempaikk/Anime-Adventures/tree/aa-visual-editor-downloads).
2. Escolha uma pasta fixa **AA-Visual-Editor**. Se já usa a versão anterior, **mantenha exatamente o caminho instalado**. Exporte seu perfil antes de trocar de computador ou de pasta: outra pasta pode gerar outro ID de extensão.
3. Abra `chrome://extensions` (ou `edge://extensions`), ative **Modo do desenvolvedor** e use **Carregar sem compactação**, apontando para essa pasta. Para uma instalação existente, substitua os arquivos na mesma pasta e clique em **Recarregar** na extensão existente.
4. Atualize a página https://www.roblox.com/games/8304191830 e fixe o ícone AA na barra do navegador.

Não remova a extensão antiga para atualizar. A migração conserva uma cópia do perfil v1 original e cria a biblioteca v2. Se as duas cópias juntas excederem a cota do Chrome, o original só sai da chave antiga depois de gravado e verificado em IndexedDB da própria extensão; a migração pode retomar dessa cópia após uma falha. Erro de leitura não apaga essa cópia. Em Perfis e cenas, **Exportar cópia v1 da migração** entrega o original; **Recuperar cópia anterior** pode restaurar uma biblioteca válida mesmo se a atual não puder ser lida. A biblioteca anterior à recuperação fica preservada em armazenamento separado. Arquivos legíveis estão em **AA-Visual-Editor-FONTE.md** e na pasta `extension` do projeto.

## Começar em três passos

1. Clique em **AA Editor**, depois em **Ativar seleção por clique** e no campo da página que deseja mudar. Também é possível usar **Campos rápidos**.
2. Escreva, confira e **aplique**. Arquivos e links de imagem carregam uma prévia; **Confirmar imagem** aplica e salva. **Prévia do rascunho** de texto não grava.
3. Aguarde **salvo neste navegador** e use **Página real / Personalizada** para comparar. **Abrir comparação em duas abas**, na ajuda, abre outra aba no original.

Se um elemento não puder ser identificado com segurança, ele fica pendente. Clique na alteração da lista, selecione o elemento correto e use **Reparar destino**. A extensão prefere deixar uma edição pendente a colocá-la em um campo ambíguo.

## Correções da versão 2.0.1

Contadores usam o rótulo do campo para reencontrar o valor após atualizações da página. Aplicar texto novamente recupera uma alteração pendente; aplicar em uma alteração pausada a reativa. A seleção acompanha a substituição de um nó de texto enquanto o painel está aberto. A aplicação de aparência em grupo mantém os elementos escolhidos, inclusive em uma repetição sem mudar o valor. Os botões Jogadores e Visitas também reconhecem campos sem ID pelo rótulo.

As prévias de texto se mantêm durante atualizações sem substituir o valor salvo nem perder o original. A prévia por link de imagem aguarda confirmação; descartar também cancela um arquivo ainda carregando. Recortes de imagens remotas usam a autorização CORS do servidor. A aparência simples conserva os valores avançados e as unidades já salvas; copiar e restaurar acompanham o campo quando os contadores mudam de posição. O rodapé do BetterBLOX é reconhecido também quando carrega depois do editor.

O backup de todos os perfis inclui as alterações atuais, mesmo se uma gravação falhou. Imagens mantidas nas cópias de recuperação ficam protegidas contra exclusão. Avisos de salvamento consideram operações ainda na fila, e concluir uma importação anterior não apaga o aviso ou a prévia de um arquivo escolhido depois.

Se uma alteração antiga continuar pendente, selecione novamente o campo correspondente e clique em **Aplicar texto**. Seu perfil continua salvo. Campos com correspondência ambígua aguardam uma seleção explícita.

## Ferramentas

- Campos rápidos: título, descrição, jogadores, visitas e imagem, quando reconhecidos. Seleção por clique, Tab/Shift+Tab e Enter; navegação por pai, filho e irmãos. Durante a seleção, Play e links não são acionados.
- Busca por nome, grupo, texto, tipo e pendência. Renomear, agrupar e pausar alterações/grupos. Shift+clique ou **Adicionar à seleção** reúne até 50 elementos por aplicação de aparência/visibilidade; a aplicação em grupo pede confirmação no próprio controle.
- Texto simples multilinha, formatador opcional de números, cores com seletor/HEX, estilos calculados atuais e originais, dimensões com unidade, proporção, fontes locais, espaços, bordas e sombras. Aparências podem ser copiadas, coladas e guardadas como predefinições nomeadas.
- Restaurar propriedade, elemento, alteração ou perfil. Desfazer/refazer usa operações e referências de imagens, com orçamento combinado de 4 MB; respeita mudanças posteriores em outras abas. O histórico da aba termina ao recarregar.
- Rascunhos de texto/link ficam temporariamente nesta aba. Trocar de elemento ou esconder o editor guarda o rascunho. Arraste o painel pelo cabeçalho, redimensione pelo canto ou acople à esquerda/direita.
- Imagens: arquivo, link HTTPS, arrastar/soltar ou colar na área explícita. Validação do conteúdo e dos cabeçalhos de arquivos locais antes do decode; preview/dimensões, biblioteca por hash, nomes e uso por perfil, recorte, resolução, formato e qualidade. GIF local pode ter um quadro fixado durante a captura. Links remotos dependem do servidor e não são incorporados ao export como arquivo quando o servidor impede ler seus pixels.
- Perfis/cenas nomeados: criar, duplicar, renomear, excluir, escolher o padrão e alternar o perfil da aba. Outra aba mantém sua própria escolha. Importação mostra resumo e conflitos, com combinar/substituir. Três backups automáticos anteriores ficam separados dos arquivos de imagens.

## Atalhos e foco

| Atalho padrão | Ação |
|---|---|
| Alt+Shift+E | Seleção por clique/teclado |
| Alt+Shift+H | Esconder/recuperar o editor |
| Alt+Shift+O | Página real/personalizada nesta aba |
| Ctrl+Enter | Aplicar texto no campo do editor |
| Ctrl+Z / Ctrl+Shift+Z | Desfazer/refazer fora de campos de texto |
| Ctrl+Shift+K | Buscar uma ação |
| Esc | Fechar fora de campos de texto |

As três letras com Alt+Shift podem ser alteradas na ajuda. O ícone do navegador sempre oferece outra forma de abrir. Esses atalhos não interceptam a digitação nos campos normais da página.

## Capturas

**Modo captura** esconde painel, botão, realce e avisos, inclusive avisos que terminam de carregar depois. Recupere pelo ícone ou pelo atalho. Esconder o botão flutuante é uma preferência persistente.

Pelo ícone AA, **Capturar PNG visível** usa somente a permissão temporária `activeTab`. A imagem aparece no painel para conferir, nomear, repetir e baixar. Se o navegador negar a captura, a interface volta e o motivo é mostrado.

**Capturar página inteira** rola e monta partes, até 16 milhões de pixels, 16.000 px de altura e 20 partes. Preserva a rolagem e restaura os elementos fixos ao terminar, mesmo após erro. Interrompe se o conteúdo crescer durante o processo ou houver rolagem horizontal. Role até carregar as imagens antes de usar. Não equivale à captura nativa do navegador em toda página dinâmica; elementos fixos aparecem somente na primeira parte. Capturas e imagens transformadas são geradas no computador.

O rodapé do BetterBLOX continua sendo reconhecido apenas pelo bloco pequeno de marca/versão/feedback. A navegação não é ocultada em conjunto. Se não houver correspondência segura, selecione manualmente o bloco que deseja ocultar.

## Espaço, backups e recuperação

- Até 20 perfis, 200 alterações por perfil, 20 predefinições de aparência e três backups automáticos.
- Metadados: até 9 MB no armazenamento da extensão. Imagens: até 500 arquivos únicos e 64 MB de bytes originais em IndexedDB da extensão. Cada imagem local tem até 4 MB e 16 milhões de pixels; transformações limitadas a 8.192 px por dimensão.
- A biblioteca mostra tamanho e perfis que usam cada imagem. Imagens referenciadas por perfis, backups ou histórico ativo de abas não são excluídas. Sessões inativas expiram seus bloqueios temporários; exporte o perfil antes de remover arquivos.
- **Ver espaço e backups** mostra o uso. Quotas reais do navegador ainda se aplicam; uma gravação rejeitada nunca é apresentada como salva. **Tentar salvar** repete sem exigir mudar o valor. Exporte um backup antes de fechar uma aba com alterações não salvas.
- **Exportar backup** cria um perfil portátil com imagens locais. Perfis maiores usam um conjunto v2 com arquivos por hash. **Exportar todos os perfis** inclui o conjunto e suas imagens uma única vez. Importação aceita v1/v2 até 96 MB; o JSON v1 mantém o limite de 8 MB.
- Duas abas combinam mudanças em campos diferentes. No mesmo campo, a última gravação explícita prevalece e registra conflito; desfazer condicional preserva mudanças posteriores de outras abas. Use os backups e o resumo de importação para recuperar a versão anterior.
- Trocar de pasta/ID ou remover a extensão pode separar ou apagar seu armazenamento. Atualize no mesmo caminho, sem desinstalar. A cópia v1 conservada registra a migração; ela não é atualizada continuamente.

## Validação e limites observados

A entrega possui testes de formato/armazenamento e de navegador, incluindo persistência após reiniciar, falha de quota, duas abas, importação com imagens, correspondência ambígua, zero CSS, valor real igual ao personalizado, cancelamento de captura e captura por partes com rolagem/restauração. O ensaio continuado exercita contadores e filas sem reter um histórico artificial de DOM.

Os testes de interface usam Chromium, DOM real, IndexedDB e uma página sintética do Roblox. As APIs Chrome da extensão são simuladas: a instalação de extensão descompactada é bloqueada pela administração do ambiente de desenvolvimento. A captura PNG real pelo Chrome e a versão instalada do BetterBLOX 3.6.2 precisam de conferência no navegador do usuário; o teste do rodapé usa a reprodução do print fornecido. Nenhum teste acessa a conta ou altera dados reais do Roblox.

Permissões continuam somente `storage`, `activeTab`, `scripting`, com execução automática restrita à página do jogo. Não há cookies, tokens, senhas, telemetria, código remoto, permissões para todos os sites ou instalação de outro software.
